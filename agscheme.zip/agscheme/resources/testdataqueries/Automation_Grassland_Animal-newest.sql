

--NULL VALUES.

with herd_detail as ( select client_bus_id from table (cast(pkas_ext_ccs.ftab_clients_per_agent(3109861, 'BPS') as tab_agent_hr_list)) 
                    )
SELECT herd_no
FROM VWAH_HERD_SPECIES_BREAKDOWN Animals, herd_detail
WHERE  herd_no = herd_detail.client_bus_id 
AND ( NVL(bovine_count,0) = 0 AND NVL(ovine_count,0) = 0 AND NVL(cervine_count,0) = 0 AND NVL(caprine_count,0) = 0 AND NVL(equine_count,0) = 0 )
AND NOT EXISTS (               

            SELECT  LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Holding_Area
                                                FROM    VWDP_CROP_ACREAGE ca 
                                                WHERE ca.HERD = Animals.herd_no
                                                AND       ca.YEAR  = 2021
                                                AND ca.CROP_CODE IN (
                                                393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172,
                                                333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407,
                                                410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359,
                                                491,492,361,498,499,493,317,500,408,409,380
                                                 ) 
            UNION 
            SELECT  LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Holding_Area
                                                FROM    VWDP_CROP_ACREAGE ca 
                                                WHERE ca.HERD = Animals.herd_no
                                                AND       ca.YEAR  = 2020
                                                AND ca.CROP_CODE IN (
                                                393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172,
                                                333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407,
                                                410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359,
                                                491,492,361,498,499,493,317,500,408,409,380
                                                 ) 
			) 
AND NOT EXISTS (                                            
            SELECT  LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Grassland_Area
            FROM        VWDP_CROP_ACREAGE ca
            WHERE     ca.HERD  = Animals.herd_no
            AND           ca.YEAR  = 2021  
            AND     ca.CROP_CODE IN (
                                                                393,     --               Alfalfa
                                                                187,    --                Arable Silage
                                                                391,    --                Clover
                                                                --332,    --             Grass Seed
                                                                --329,    --             Grass Silage
                                                                396,    --                Grass Year 1
                                                                397,    --                Grass Year 2
                                                                398,    --                Grass Year 3
                                                                399,    --                Grass Year 4
                                                                401,    --                Grass Year 5
                                                                311,    --                Grassmeal
                                                                505,    --                Low Input Permanent Pasture
                                                                392,    --                Lucerne
                                                                --382,    --             Mixed Grazing
                                                                342,    --                Permanent Pasture
                                                                478,    --                Red Clover
                                                                --360,    --             Species Rich Grassland
                                                                --378     --             Trad. Sustainable Grazing
                                                                333, -- Forage Rape (added to eligible grassland list as of 2020) 
                                                                361 -- Traditional Hay Meadow (added to eligible grassland list as of 2020)
                                    ) 
            AND       ca.COMMONAGE_IND = 'N'            
            UNION
            SELECT  LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Grassland_Area
            FROM        VWDP_CROP_ACREAGE ca
            WHERE     ca.HERD  = Animals.herd_no
            AND           ca.YEAR  = 2020  
            AND     ca.CROP_CODE IN (
                                                                393,     --               Alfalfa
                                                                187,    --                Arable Silage
                                                                391,    --                Clover
                                                                --332,    --             Grass Seed
                                                                --329,    --             Grass Silage
                                                                396,    --                Grass Year 1
                                                                397,    --                Grass Year 2
                                                                398,    --                Grass Year 3
                                                                399,    --                Grass Year 4
                                                                401,    --                Grass Year 5
                                                                311,    --                Grassmeal
                                                                505,    --                Low Input Permanent Pasture
                                                                392,    --                Lucerne
                                                                --382,    --             Mixed Grazing
                                                                342,    --                Permanent Pasture
                                                                478,    --                Red Clover
                                                                --360,    --             Species Rich Grassland
                                                                --378     --             Trad. Sustainable Grazing
                                                                333, -- Forage Rape (added to eligible grassland list as of 2020) 
                                                                361 -- Traditional Hay Meadow (added to eligible grassland list as of 2020)
                                    ) 
            AND       ca.COMMONAGE_IND = 'N'                                                      
			) 
AND NOT EXISTS (
                    SELECT * FROM tdas_applications 
                    WHERE app_current_business_id = Animals.herd_no 
                    AND app_Scheme_year = 2021 
                    AND app_current_status_code != 100008 -- Application Deleted
                    
            )
FETCH FIRST 1 ROWS ONLY;            




--NOT NULL Values.

SELECT herd_no,bovine_count, ovine_count, cervine_count, caprine_count, equine_count, Holding_Area, Grassland_Area 
FROM
(
SELECT herd_no,bovine_count, ovine_count, cervine_count, caprine_count, equine_count 
FROM VWAH_HERD_SPECIES_BREAKDOWN, 
( select client_bus_id from table (cast(pkas_ext_ccs.ftab_clients_per_agent(3109861, 'BPS') as tab_agent_hr_list)) 
) 
where ( bovine_count > 0 OR ovine_count > 0 OR cervine_count > 0 OR caprine_count > 0 OR equine_count > 0 )
AND herd_no = client_bus_id
) Animals,
LATERAL (   
		SELECT  Holding_Area 
		FROM
        (
        
            SELECT ca.YEAR, SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Holding_Area
            FROM    VWDP_CROP_ACREAGE ca 
            WHERE 
            ca.YEAR in (2021, 2020)
            AND HERD = Animals.herd_no 
            AND ca.CROP_CODE IN (
                                    393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172,
                                    333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407,
                                    410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359,
                                    491,492,361,498,499,493,317,500,408,409,380
                                )
            GROUP BY ca.YEAR
            order by year desc fetch first 1 row only
                               
          )  WHERE Holding_Area > 0
		  
) ,
LATERAL (
		
		SELECT  Grassland_Area 
		FROM
        (
            SELECT ca.YEAR, SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Grassland_Area
            FROM    VWDP_CROP_ACREAGE ca 
            WHERE 
            ca.YEAR in (2021, 2020)
            AND HERD = 'A121412X'
            AND     ca.CROP_CODE IN (
                                                                393,     --               Alfalfa
                                                                187,    --                Arable Silage
                                                                391,    --                Clover
                                                                --332,    --             Grass Seed
                                                                --329,    --             Grass Silage
                                                                396,    --                Grass Year 1
                                                                397,    --                Grass Year 2
                                                                398,    --                Grass Year 3
                                                                399,    --                Grass Year 4
                                                                401,    --                Grass Year 5
                                                                311,    --                Grassmeal
                                                                505,    --                Low Input Permanent Pasture
                                                                392,    --                Lucerne
                                                                --382,    --             Mixed Grazing
                                                                342,    --                Permanent Pasture
                                                                478,    --                Red Clover
                                                                --360,    --             Species Rich Grassland
                                                                --378     --             Trad. Sustainable Grazing
                                                                333, -- Forage Rape (added to eligible grassland list as of 2020) 
                                                                361 -- Traditional Hay Meadow (added to eligible grassland list as of 2020)
                                    ) 
            AND       ca.COMMONAGE_IND = 'N' 
            GROUP BY ca.YEAR
            order by year desc fetch first 1 row only
                               
          )  WHERE Grassland_Area > 0
)  
--WHERE Animals.herd_no = Holdings.HERD 
--AND Holdings.HERD = Grassland.HERD 
FETCH FIRST 1 ROWS ONLY;





**************************************

--Here is another Option for Doing the checks for NOT NULL which is much quicker.

-- Query to check the Anumals & Grassland & Holding 
-- This Query will return you the Numbers for the Animals and also check that there's values for Grass Land & Holding but you would need to
-- Query them seperatley. This will speed up the wole process.

SELECT herd_no,bovine_count, ovine_count, cervine_count, caprine_count, equine_count   
FROM
(
SELECT herd_no,bovine_count, ovine_count, cervine_count, caprine_count, equine_count 
FROM VWAH_HERD_SPECIES_BREAKDOWN, 
( select client_bus_id from table (cast(pkas_ext_ccs.ftab_clients_per_agent(3109861, 'BPS') as tab_agent_hr_list)) 
) 
where ( bovine_count > 0 OR ovine_count > 0 OR cervine_count > 0 OR caprine_count > 0 OR equine_count > 0 )
AND herd_no = client_bus_id
) Animals
WHERE EXISTS (   
        SELECT Holding_Area FROM
        (
            SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Holding_Area
            FROM    VWDP_CROP_ACREAGE ca 
            WHERE 
            ca.YEAR in ( 2020, 2021)
            AND HERD = Animals.herd_no
            AND ca.CROP_CODE IN (
                                    393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172,
                                    333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407,
                                    410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359,
                                    491,492,361,498,499,493,317,500,408,409,380
                                )
                     
          )  WHERE Holding_Area > 0
) 
AND EXISTS (
        SELECT Grassland_Area FROM
        (
            SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Grassland_Area
            FROM    VWDP_CROP_ACREAGE ca
            WHERE   ca.YEAR IN (2020  ,2021)
            AND HERD = Animals.herd_no
            AND     ca.CROP_CODE IN (
                                                                393,     --               Alfalfa
                                                                187,    --                Arable Silage
                                                                391,    --                Clover
                                                                --332,    --             Grass Seed
                                                                --329,    --             Grass Silage
                                                                396,    --                Grass Year 1
                                                                397,    --                Grass Year 2
                                                                398,    --                Grass Year 3
                                                                399,    --                Grass Year 4
                                                                401,    --                Grass Year 5
                                                                311,    --                Grassmeal
                                                                505,    --                Low Input Permanent Pasture
                                                                392,    --                Lucerne
                                                                --382,    --             Mixed Grazing
                                                                342,    --                Permanent Pasture
                                                                478,    --                Red Clover
                                                                --360,    --             Species Rich Grassland
                                                                --378     --             Trad. Sustainable Grazing
                                                                333, -- Forage Rape (added to eligible grassland list as of 2020) 
                                                                361 -- Traditional Hay Meadow (added to eligible grassland list as of 2020)
                                    ) 
            AND       ca.COMMONAGE_IND = 'N'  
        ) WHERE Grassland_Area > 0 
)  
--WHERE Animals.herd_no = Holdings.HERD 
--AND Holdings.HERD = Grassland.HERD 
FETCH FIRST 1 ROWS ONLY;


--Query for Holding Area
SELECT SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Holding_Area
            FROM    VWDP_CROP_ACREAGE ca 
            WHERE 
            ca.YEAR = 2020 
            AND HERD = 'E1010178'
            AND ca.CROP_CODE IN (
                                    393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172,
                                    333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407,
                                    410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359,
                                    491,492,361,498,499,493,317,500,408,409,380
                                );
                     

--Query for Grassland Area
SELECT SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Grassland_Area
            FROM    VWDP_CROP_ACREAGE ca
            WHERE   ca.YEAR = 2020 
            AND HERD = 'E1010178'
            AND     ca.CROP_CODE IN (
                                                                393,     --               Alfalfa
                                                                187,    --                Arable Silage
                                                                391,    --                Clover
                                                                --332,    --             Grass Seed
                                                                --329,    --             Grass Silage
                                                                396,    --                Grass Year 1
                                                                397,    --                Grass Year 2
                                                                398,    --                Grass Year 3
                                                                399,    --                Grass Year 4
                                                                401,    --                Grass Year 5
                                                                311,    --                Grassmeal
                                                                505,    --                Low Input Permanent Pasture
                                                                392,    --                Lucerne
                                                                --382,    --             Mixed Grazing
                                                                342,    --                Permanent Pasture
                                                                478,    --                Red Clover
                                                                --360,    --             Species Rich Grassland
                                                                --378     --             Trad. Sustainable Grazing
                                                                333, -- Forage Rape (added to eligible grassland list as of 2020) 
                                                                361 -- Traditional Hay Meadow (added to eligible grassland list as of 2020)
                                    ) 
            AND       ca.COMMONAGE_IND = 'N'  ;
            
			

--Query for Holding Area
-- Returning Values for the latest year else for the previous year.
-- Returning NULL if no case found.

SELECT  Holding_Area 
FROM
        (
        
            SELECT ca.YEAR, SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Holding_Area
            FROM    VWDP_CROP_ACREAGE ca 
            WHERE 
            ca.YEAR in (2021, 2020)
            AND HERD = 'A121412X'
            AND ca.CROP_CODE IN (
                                    393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172,
                                    333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407,
                                    410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359,
                                    491,492,361,498,499,493,317,500,408,409,380
                                )
            GROUP BY ca.YEAR
            order by year desc fetch first 1 row only
                               
          )  WHERE Holding_Area > 0;
		  

--Query for Grassland Area
-- Returning Values for the latest year else for the previous year.
-- Returning NULL if no case found.

SELECT  Grassland_Area 
FROM
        (
        
            SELECT ca.YEAR, SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Grassland_Area
            FROM    VWDP_CROP_ACREAGE ca 
            WHERE 
            ca.YEAR in (2021, 2020)
            AND HERD = 'A121412X'
            AND     ca.CROP_CODE IN (
                                                                393,     --               Alfalfa
                                                                187,    --                Arable Silage
                                                                391,    --                Clover
                                                                --332,    --             Grass Seed
                                                                --329,    --             Grass Silage
                                                                396,    --                Grass Year 1
                                                                397,    --                Grass Year 2
                                                                398,    --                Grass Year 3
                                                                399,    --                Grass Year 4
                                                                401,    --                Grass Year 5
                                                                311,    --                Grassmeal
                                                                505,    --                Low Input Permanent Pasture
                                                                392,    --                Lucerne
                                                                --382,    --             Mixed Grazing
                                                                342,    --                Permanent Pasture
                                                                478,    --                Red Clover
                                                                --360,    --             Species Rich Grassland
                                                                --378     --             Trad. Sustainable Grazing
                                                                333, -- Forage Rape (added to eligible grassland list as of 2020) 
                                                                361 -- Traditional Hay Meadow (added to eligible grassland list as of 2020)
                                    ) 
            AND       ca.COMMONAGE_IND = 'N' 
            GROUP BY ca.YEAR
            order by year desc fetch first 1 row only
                               
          )  WHERE Grassland_Area > 0;
		  
		              
		  
