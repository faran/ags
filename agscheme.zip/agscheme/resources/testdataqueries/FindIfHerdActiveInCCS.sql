 select business_id, start_date, end_date  
 from vwco_agsch_business_customers  
 where business_id = i_business_id;
 