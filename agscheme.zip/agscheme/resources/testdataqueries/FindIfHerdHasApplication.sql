SELECT *
FROM tdas_applications
LEFT JOIN tsas_status
ON tdas_applications.app_current_status_code = tsas_status.st_status_code
where tdas_applications.app_current_business_id = 'E1280205';


