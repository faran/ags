package ie.gov.agriculture.agschemes.commons;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.junit.Assume;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;

/**
 * Constants as from the properties file.
 *
 * @author youssef.abdalla
 */
@Log4j2
public class ConstantsProvider {

    static {
        Properties initProperties = new Properties();
        try (InputStream propertyFileInputStream = new FileInputStream(ConstantsNames.CONSTANTS_FILE_NAME)) {
            initProperties.load(propertyFileInputStream);
            allProperties = initProperties;
            log.warn("this is the read properties file " + initProperties.toString());
        } catch (final IOException e) {
            log.fatal("failed to load the constants file from: " + ConstantsNames.CONSTANTS_FILE_NAME);
            Assume.assumeNoException(e);
        }

    }

    public static final String EXECUTION_STATUS_PASS = "1";
    public static final String EXECUTION_STATUS_FAIL = "2";
    public static final String EXECUTION_STATUS_WIP = "3";
    public static final String EXECUTION_STATUS_UNEXECUTED = "-1";
    public static final String EXECUTION_STATUS_BLOCKED = "4";
    @Getter
    private static final String MYBATIS_CONFIG_FILE_PATH = "mybatis-config.xml";
    private static Properties allProperties;

    // EDMS

    @Getter
    private static final String URL = allProperties.getProperty(ConstantsNames.URL);

    @Getter
    private static final String SSOSTAFFLOGINUSERNAMEDEV = allProperties
        .getProperty(ConstantsNames.SSO_STAFF_LOGIN_USER_NAME_DEV);

    @Getter
    private static final String HERDNO1STAFF = allProperties.getProperty(ConstantsNames.HERDNO1STAFF);
    @Getter
    private static final String HERD_NOT_IN_BPS = allProperties.getProperty(ConstantsNames.HERD_NOT_IN_BPS);
    @Getter
    private static final String HERD_NO_DATA_STAFF = allProperties.getProperty(ConstantsNames.HERD_NO_DATA_STAFF);
    @Getter
    private static final String HERD_WITH_SOME_DATA_STAFF = allProperties
        .getProperty(ConstantsNames.HERD_WITH_SOME_DATA_STAFF);
    @Getter
    private static final String CUSTOMER_ID = allProperties
            .getProperty(ConstantsNames.CUSTOMER_ID);
    @Getter
    private static final String CUSTOMER_ID_AGENT = allProperties
            .getProperty(ConstantsNames.CUSTOMER_ID_AGENT);
    @Getter
    private static final String HERD_WITH_N_AND_P_DETAILS_STAFF = allProperties
        .getProperty(ConstantsNames.HERD_WITH_N_AND_P_DETAILS_STAFF);
    @Getter
    private static final String HERD_WITH_APPLICATION_APPROVED = allProperties
            .getProperty(ConstantsNames.HERD_WITH_APPLICATION_APPROVED);
    @Getter
    private static final String NTR_NITRATES_YEAR_STAFF = allProperties
        .getProperty(ConstantsNames.NTR_NITRATES_YEAR_STAFF);
    @Getter
    private static final String HERDNO1AGENT = allProperties.getProperty(ConstantsNames.HERDNO1AGENT);
    @Getter
    private static final String NONCLIENT1 = allProperties.getProperty(ConstantsNames.NONCLIENT1);
    @Getter
    private static final String HERD_NO_DATA_AGENT = allProperties.getProperty(ConstantsNames.HERD_NO_DATA_AGENT);
    @Getter
    private static final String HERDNO3AGENT = allProperties.getProperty(ConstantsNames.HERDNO3AGENT);
    @Getter
    private static final String HERDNO1AGENTSAMPLE = allProperties.getProperty(ConstantsNames.HERDNO1AGENTSAMPLE);
    @Getter
    private static final String HERDYEAR = allProperties.getProperty(ConstantsNames.HERDYEAR);

    @Getter
    private static final String ESTIMATEDNITROGENSPREAD = allProperties
        .getProperty(ConstantsNames.ESTIMATEDNITROGENSPREAD);

    @Getter
    private static final String ANIMALCOUNT = allProperties.getProperty(ConstantsNames.ANIMALCOUNT);

    @Getter
    private static final String ELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT = allProperties
        .getProperty(ConstantsNames.ELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT);

    @Getter
    private static final String ELIGIBLEAREAOFGRASSLANDSTAFFINPUT = allProperties
        .getProperty(ConstantsNames.ELIGIBLEAREAOFGRASSLANDSTAFFINPUT);

    @Getter
    private static final String INVALIDESTIMATEDNITROGENSPREAD = allProperties
        .getProperty(ConstantsNames.INVALIDESTIMATEDNITROGENSPREAD);

    @Getter
    private static final String INVALIDELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT = allProperties
        .getProperty(ConstantsNames.INVALIDELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT);

    @Getter
    private static final String INVALIDELIGIBLEAREAOFGRASSLANDSTAFFINPUT = allProperties
        .getProperty(ConstantsNames.INVALIDELIGIBLEAREAOFGRASSLANDSTAFFINPUT);

    @Getter
    private static final String SSOAGENTLOGINUSERNAMEDEV = allProperties
        .getProperty(ConstantsNames.SSO_AGENT_LOGIN_USER_NAME_DEV);

    @Getter
    private static final String SSOINDIVIDUALLOGINUSERNAMEDEV = allProperties
        .getProperty(ConstantsNames.SSO_INDIVIDUAL_LOGIN_USER_NAME_DEV);

    @Getter
    private static final String SSOSTAFFLOGINUSERNAMECENTEST = allProperties
        .getProperty(ConstantsNames.SSOSTAFFLOGINUSERNAMECENTEST);

    @Getter
    private static final String SSOAGENTLOGINUSERNAMECENTEST = allProperties
        .getProperty(ConstantsNames.SSOAGENTLOGINUSERNAMECENTEST);

    @Getter
    private static final String SSOINDIVIDUALLOGINUSERNAMECENTEST = allProperties
        .getProperty(ConstantsNames.SSOINDIVIDUALLOGINUSERNAMECENTEST);

    @Getter
    private static final String DEVSTAFFURL = allProperties.getProperty(ConstantsNames.DEVSTAFFURL);

    @Getter
    private static final String DEVAGENTURL = allProperties.getProperty(ConstantsNames.DEVAGENTURL);

    @Getter
    private static final String DEVINDIVIDUALURL = allProperties.getProperty(ConstantsNames.DEVINDIVIDUALURL);

    @Getter
    private static final String CENTESTSTAFFURL = allProperties.getProperty(ConstantsNames.CENTESTSTAFFURL);

    @Getter
    private static final String CENTESTAGENTURL = allProperties.getProperty(ConstantsNames.CENTESTAGENTURL);

    @Getter
    private static final String CENTESTINDIVIDUALURL = allProperties.getProperty(ConstantsNames.CENTESTINDIVIDUALURL);

    @Getter
    private static final String EIRCODE = allProperties.getProperty(ConstantsNames.EIRCODE);

    @Getter
    private static final String ADDRESS = allProperties.getProperty(ConstantsNames.ADDRESS);

    @Getter
    private static final String CONTACTNUMBER = allProperties.getProperty(ConstantsNames.CONTACTNUMBER);

    @Getter
    private static final String USERNAME = allProperties.getProperty(ConstantsNames.USERNAME);

    @Getter
    private static final String PASSWORD = allProperties.getProperty(ConstantsNames.PASSWORD);

    @Getter
    private static final String CLIENTID = allProperties.getProperty(ConstantsNames.CLIENTID);

    @Getter
    private static final String GRANT_TYPE = allProperties.getProperty(ConstantsNames.GRANT_TYPE);

    @Getter
    private static final String ACCESS_TOKEN_URL = allProperties.getProperty(ConstantsNames.ACCESS_TOKEN_URL);

    @Getter
    private static final String SUSPECT_REPORT_SERVICE_URL = allProperties
        .getProperty(ConstantsNames.SUSPECT_REPORT_SERVICE_URL);

    @Getter
    private static final String ENVIRONMENT_DEFAULT = allProperties.getProperty(ConstantsNames.ENVIRONMENT_DEFAULT);

    @Getter
    private static final String REST_ASSURED_BASE_URLS_START = allProperties
        .getProperty(ConstantsNames.REST_ASSURED_BASE_URLS_START);

    @Getter
    private static final String REST_ASSURED_INET_BASE_URLS_START = allProperties
        .getProperty(ConstantsNames.REST_ASSURED_INET_BASE_URLS_START);

    @Getter
    private static final String REST_ASSURED_BASE_URLS_END = allProperties
        .getProperty(ConstantsNames.REST_ASSURED_BASE_URLS_END);

    @Getter
    private static final String BASE_PATH = allProperties.getProperty(ConstantsNames.BASE_PATH);

    @Getter
    private static final String BASE_URL_AG_APPS = allProperties.getProperty(ConstantsNames.BASE_URL_AG_APPS);

    @Getter
    private static final String BASE_URL_AG_FOODS = allProperties.getProperty(ConstantsNames.BASE_URL_AG_FOODS);

    @Getter
    private static final long GLOBAL_TIMEOUT = Long
        .parseLong(allProperties.getProperty(ConstantsNames.GLOBAL_TIMEOUT_IN_SECONDS));
    @Getter
    private static final String JIRA_URL = allProperties.getProperty(ConstantsNames.JIRA_URL);
    @Getter
    private static final String ZAPI_PATH = allProperties.getProperty(ConstantsNames.ZAPI_PATH);
    @Getter
    private static final String TEST_CYCLE_NAME = allProperties.getProperty(ConstantsNames.TEST_CYCLE_NAME);

    @Getter
    private static final boolean SELENIUM_GRID_ON = Boolean
        .parseBoolean(allProperties.getProperty(ConstantsNames.SELENIUM_GRID_ON));
    @Getter
    private static final String SELENIUM_HUB_URL = "http://" +
        allProperties.getProperty(ConstantsNames.SELENIUM_VM_IP)
        + ":4444/wd/hub";

    @Getter
    private static final String SELENIUM_VM_IP = allProperties.getProperty(ConstantsNames.SELENIUM_VM_IP);
    @Getter
    private static final int SELENIUM_HUB_PORT = Integer
        .parseInt(allProperties.getProperty(ConstantsNames.SELENIUM_HUB_PORT));
    @Getter
    private static final String SELENIUM_WEB_BROWSER_NAME = allProperties.getProperty(ConstantsNames.WEB_BROWSER);
    /**
     * This is browser name after the folder of the driver (eg. resources/webdriver/chrome in case of chrome)
     */
    @Getter
    private static final String SELENIUM_DRIVER_PATH = allProperties.getProperty(ConstantsNames.SELENIUM_DRIVER_PATH);

    @Getter
    private static final String SSO_LOGIN_PASSWORD_DEV = allProperties
        .getProperty(ConstantsNames.SSO_LOGIN_PASSWORD_DEV);
    @Getter
    private static final String SSO_LOGIN_PASSWORD_UAT = allProperties
        .getProperty(ConstantsNames.SSO_LOGIN_PASSWORD_UAT);
    @Getter
    private static final String SSO_LOGIN_PASSWORD_CENTEST = allProperties
        .getProperty(ConstantsNames.SSO_LOGIN_PASSWORD_CENTEST);

    @Getter
    private static final String JIRA_USER_NAME = allProperties.getProperty(ConstantsNames.JIRA_USER_NAME);
    @Getter
    private static final String JIRA_PASSWORD = allProperties.getProperty(ConstantsNames.JIRA_PASSWORD);

    /**
     * @param environment
     *            {@link AllowedEnvironments#ENVIRONMENT_DEV} or {@link AllowedEnvironments#ENVIRONMENT_CENTEST}
     * @return the time frame of the Jira creation batch job to be triggered on the given environment
     */
    public static long getJiraCreationTimeFrame(String environment) {
        return Long.parseLong(allProperties.getProperty("jiraCreationTimeFrame_" + environment));
    }
}
