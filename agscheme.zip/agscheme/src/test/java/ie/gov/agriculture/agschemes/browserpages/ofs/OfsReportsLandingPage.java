package ie.gov.agriculture.agschemes.browserpages.ofs;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class OfsReportsLandingPage {

    private final WebDriver webDriver;

    @FindBy(id = "genericHolder:layoutBody:reportSearchScheme")
    private WebElement schemeSelect;

    @FindBy(id = "genericHolder:layoutBody:reportSearchGroup")
    private WebElement reportGroupDrop;

    @FindBy(id = "genericHolder:layoutBody:reportSearch")
    private WebElement reportDrop;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:0:reportParameterDropDown")
    private WebElement scheme2;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:1:reportParameterDropDown")
    private WebElement applicationTypeDrop;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:2:reportParameterDropDown")
    private WebElement schemeYearDrop;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:3:reportParameterDropDown")
    private WebElement applicationStatusDrop;

    @FindBy(id = "genericHolder:layoutBody:validateButton")
    private WebElement validateButton;

    @FindBy(id = "genericHolder:layoutBody:showReportButton")
    private WebElement showReportButton;

    public void selectScheme(String scheme) {
        Select select = new Select(schemeSelect);
        select.selectByVisibleText(scheme);
    }

    public void selectSchemeAgain(String scheme) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, scheme2);
        Select select = new Select(scheme2);
        select.selectByVisibleText(scheme);
    }

    public void selectReportGroup(String group) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, reportGroupDrop);
        Select select = new Select(reportGroupDrop);
        select.selectByVisibleText(group);
    }

    public void selectReport(String report) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, reportDrop);
        Select select = new Select(reportDrop);
        select.selectByVisibleText(report);
    }

    public void selectApplicationType(String type) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, applicationTypeDrop);
        Select select = new Select(applicationTypeDrop);
        select.selectByVisibleText(type);
    }

    public void selectSchemeYear(String year) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, schemeYearDrop);
        Select select = new Select(schemeYearDrop);
        select.selectByVisibleText(year);
    }

    public void selectApplicationStatus(String status) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, applicationStatusDrop);
        Select select = new Select(applicationStatusDrop);
        select.selectByVisibleText(status);
    }

    public void clickValidateButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, validateButton);

    }

    public void clickShowReportButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, showReportButton);
    }
}
