package ie.gov.agriculture.agschemes.browserpages.nitrates;

import static org.assertj.core.api.Assertions.assertThat;

import java.awt.*;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Screen;

@RequiredArgsConstructor
@Log4j2
public class NitratesDocumentManagerPage {

    protected final WebDriver webDriver;
    private String projectDir = System.getProperty("user.dir");
    private String resourcesDir = projectDir + File.separator + "src" + File.separator + "main" + File.separator
            + "resources";
    private String textFile = resourcesDir + File.separator + "uploadfile.text";
    private String images = resourcesDir + File.separator + "images" + File.separator;


    @FindBy(id = "agent-view-documents-action-data-cell-button2")
    private WebElement moreActionsSoilSampleButton;

    @FindBy(xpath = "//*[@class='documentTypeDescription'][text()=' Farm Sketch ']")
    private WebElement farmSketchLabel;

    @FindBy(xpath = "//*[@class='documentTypeDescription'][text()=' Map ']")
    private WebElement mapLabel;

    @FindBy(xpath = "//*[@class='documentTypeDescription'][text()=' Soil Sample ']")
    private WebElement soilSampleLabel;

    @FindBy(xpath = "//*[@class='documentTypeDescription'][text()=' eNMP ']")
    private WebElement enmpLabel;

    @FindBy(xpath = "//*[@class='mat-datepicker-toggle-default-icon ng-star-inserted']")
    private WebElement datePickerButton;

    @FindBy(xpath = "//*[@class='mat-calendar-body-cell-content mat-calendar-body-today']")
    private WebElement todaysDate;

    @FindBy(id = "agent-upload-document-selected-document-type-2")
    private WebElement uploadDocumentButtonSoilSampleAgent;

    @FindBy(id = "agent-view-documents-selected-document-type-2")
    private WebElement viewDocumentButtonSoilSampleAgent;

    @FindBy(xpath = "//td[@class='mat-cell cdk-column-documentFileName mat-column-documentFileName ng-star-inserted']")
    private WebElement documentFileNameLabel;

    @FindBy(id = "agent-upload-document-upload-button")
    private WebElement uploadButton;

    @FindBy(id = "confimation-modal-confirm-button")
    private WebElement confirmButton;

    @FindBy(id = "confimation-modal-cancel-button")
    private WebElement cancelButton;

    @FindBy(id = "agent-view-document-close-button")
    private WebElement closeViewButton;

    @FindBy(id = "confimation-modal-success-close-button")
    private WebElement closeButton;

    @FindBy(xpath = "//div[text()=' Document successfully deleted ']")
    private WebElement documentSuccessfullydeletedPopUpText;

    @FindBy(xpath = "//button[text()=' Upload Document ']")
    private WebElement uploadDocumentButton;

    @FindBy(xpath = "//button[text()=' View Documents ']")
    private WebElement viewDocumentButton;

    @FindBy(xpath = "//mat-icon[text()='more_horiz']")
    protected WebElement moreActionsButtonStaff;

    @FindBy(id = "STAFF-edit-selected-document-button-0")
    private WebElement staffEditDocumentButton;

    @FindBy(id = "agent-upload-document-selected-document-type-1")
    private WebElement agentUploadDocumentButton;

    @FindBy(xpath = "//div[text()=' This document cannot be edited ']")
    protected WebElement editDocumentString;

    @FindBy(xpath = "//div[text()=' This Document cannot be deleted ']")
    protected WebElement deleteDocumentString;

    @FindBy(id = "STAFF-delete-selected-document-button-0")
    private WebElement staffDeleteDocumentButton;

    @FindBy(id = "query-application-query-reasons")
    private WebElement staffDeleteDocumentReasonDropDown;

    @FindBy(id = "query-reason-option- -1")
    private WebElement staffDeleteDocumentReasonGDPRDropDown;

    @FindBy(id = "query-reason-option- -2")
    private WebElement staffDeleteDocumentReasonOtherDropDown;

    @FindBy(id = "//textarea[@data-placeholder='Ex. Delete document due to ...']")
    private WebElement staffDeleteDocumentReasonOtherComment;

    @FindBy(xpath = "//mat-card-title[text()=' Upload Document -  Fertiliser Accounts ']")
    private WebElement uploadPopupTitleFertliserAccount;

    @FindBy(xpath = "//mat-card-title[text()=' Upload Document -  Farm Sketch ']")
    private WebElement uploadPopupTitleFarmSketch;

    @FindBy(xpath = "//span[@class='mat-color-warn']")
    private WebElement pleaseSelectDateWarning;

    @FindBy(xpath = "//mat-card-title[normalize-space(text()='Upload Document -  Soil Sample')]")
    private WebElement uploadPopupTitleSoilSample;

    @FindBy(xpath = "//mat-select[@formcontrolname='yearDocumentCreated']")
    private WebElement farmSketchDropDown;

    @FindBy(xpath = "//mat-card-title[text()=' Farm Sketch Documents ']")
    private WebElement viewDocumentFarmSketchTitle;

    @FindBy(xpath = "//mat-card-title[text()=' Soil Sample Documents ']")
    private WebElement viewDocumentSoilSampleTitle;

    @FindBy(xpath = "//mat-card-title[text()=' Upload Document -  Soil Sample ']")
    private WebElement uploadDocumentSoilSampleTitle;

    @FindBy(xpath = "//div[text()=' This document may be associated with other Approved Applications. Please ensure that you check and move any affected applications to Under Query before continuing. ']")
    private WebElement soilSampleDeletePopupText;

    @FindBy(xpath = "//button[@class='mat-focus-indicator mat-icon-button mat-button-base']")
    private WebElement selectSoilSampleDate;

    @FindBy(xpath = "//div[@class='mat-calendar-body-cell-content mat-focus-indicator mat-calendar-body-today']")
    private WebElement soilSampleTodaysDate;

    @FindBy(id = "agent-upload-document-year-document-created-option-0")
    private WebElement farmSketchDropDownFirstOption;

    @FindBy(xpath = "//mat-card-title[text()=' Fertiliser Accounts Documents ']")
    private WebElement viewDocumentTitle;

    @FindBy(xpath = "//mat-card-title[text()=' Edit Document ']")
    private WebElement editDocumentTitle;

    @FindBy(xpath = "//textarea[@data-placeholder='Ex. Edit document due to ...']")
    private WebElement editDocumentComment;

    @FindBy(xpath = "//mat-card-title[text()=' Upload Document -  Farm Sketch ']")
    private WebElement uploadPopupTitleFaramSletch;

    @FindBy(xpath = "//mat-option[@id='agent-upload-document-year-document-created-option-0']")
    private WebElement selectYear2021;

    @FindBy(xpath = "//mat-select[@formcontrolname='yearDocumentCreated']")
    private WebElement selectDropDown;

    @FindBy(xpath = "//button[@id='agent-upload-document-file-select-button']")
    private WebElement selectButton;

    @FindBy(xpath = "//div[text()='Status']")
    private WebElement statusText;

    @FindBy(xpath = "(//span[contains(text(),'Retrieving Applications')]")
    protected WebElement retrievingApplications;

    public void validateSoilSampleIsDisplayed() {
        Assert.assertTrue(soilSampleLabel.isDisplayed());
        Assert.assertTrue(moreActionsSoilSampleButton.isDisplayed());
    }

    public void validateAllDocumentsIsDisplayed() {
        Assert.assertTrue(farmSketchLabel.isDisplayed());
        Assert.assertTrue(mapLabel.isDisplayed());
        Assert.assertTrue(soilSampleLabel.isDisplayed());
        Assert.assertTrue(enmpLabel.isDisplayed());
    }

    public void uploadFile() {

        BrowserUtils.waitAndClickElement(webDriver, moreActionsSoilSampleButton);
        BrowserUtils.waitAndClickElement(webDriver, uploadDocumentButtonSoilSampleAgent);
        BrowserUtils.waitAndClickElement(webDriver, datePickerButton);
        BrowserUtils.waitAndClickElement(webDriver, todaysDate);

        /*
         * if (System.getenv("BROWSER") == null) {
         *
         * String filePath = System.getProperty("user.dir") + "\\sample.pdf"; log.warn("filepath " + filePath);
         * webDriver.findElement(By.id("agent-upload-document-file-input")).sendKeys(filePath); } else {
         */
        String filePath = "http://www.africau.edu/images/default/sample.pdf";
        log.warn("filepath " + filePath);
        webDriver.findElement(By.id("agent-upload-document-file-input")).sendKeys(filePath);
        // }

        BrowserUtils.waitAndClickElement(webDriver, uploadButton);
        BrowserUtils.waitAndClickElement(webDriver, confirmButton);
        BrowserUtils.waitAndClickElement(webDriver, closeButton);
    }

    public void assertFileUploaded() {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsSoilSampleButton);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButtonSoilSampleAgent);
        String documentName = BrowserUtils.getText(webDriver, documentFileNameLabel);
        log.warn("documentName " + documentName);
        assertThat(documentName).contains("sample");

    }

    private void uploadFileUsingSikuliX() {
        Screen screen = new Screen();
        try {
            screen.type(images + "filename.PNG", textFile);
            screen.click(images + "open.PNG");
        } catch (FindFailed findFailed) {
            findFailed.printStackTrace();
        } finally {
            if (screen.has(images + "ok.PNG")) {
                try {
                    screen.click(images + "ok.PNG");
                    screen.click(images + "cancel.PNG");
                } catch (FindFailed findFailed) {
                    findFailed.printStackTrace();
                }
            }
        }
    }

    private void uploadFileUsingRobot() {
        setClipboard();

        Robot robot = null;
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }

        if (robot != null) {
            robot.setAutoDelay(1000);
            robot.keyPress(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_V);
            robot.keyRelease(KeyEvent.VK_CONTROL);
            robot.keyPress(KeyEvent.VK_ENTER);
            robot.keyRelease(KeyEvent.VK_ENTER);
        }
    }

    public void setClipboard() {
        createFile();
        String tempFile = "C:\\temp\\temp.txt";
        StringSelection ss = new StringSelection(tempFile);
        Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);
    }

    private void creatDirectory() {
        File file = new File("C:\\temp");
        if (file.mkdir()) {
            System.out.println("Dir is created!");
        } else {
            System.out.println("Dir already exist!");
        }
    }

    private void createFile() {
        creatDirectory();
        File file = new File("C:\\temp\\temp.txt");
        try {
            if (file.createNewFile()) {
                System.out.println("File is created!");
            } else {
                System.out.println("File already exist!");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileWriter writer;
        try {
            writer = new FileWriter(file);
            writer.write("First line of the test file");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void clickOnAccountType(String acctype) {
        BrowserUtils.waitForAngular5Load(webDriver);
        WebElement accType = webDriver
                .findElement(By.xpath("//td/span[normalize-space(text())='" + acctype + "']/../following-sibling::td[2]"));
        BrowserUtils.waitAndClickElement(webDriver, accType);
    }

    public void uploadDocumentToAccount(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, uploadDocumentButton);
        if (accountType.equals("Fertiliser Accounts")) {
            BrowserUtils.waitVisibility(webDriver, uploadPopupTitleFertliserAccount);
        }
        if (accountType.equals("Farm Sketch")) {
            BrowserUtils.waitVisibility(webDriver, uploadPopupTitleFarmSketch);
            BrowserUtils.waitAndClickElement(webDriver, farmSketchDropDown);
            BrowserUtils.waitAndClickElement(webDriver, farmSketchDropDownFirstOption);
        }
        if(accountType.equals("Soil Sample")){
            BrowserUtils.waitVisibility(webDriver, uploadDocumentSoilSampleTitle);
            BrowserUtils.waitAndClickElement(webDriver, selectSoilSampleDate);
            BrowserUtils.waitAndClickElement(webDriver, soilSampleTodaysDate);
        }
        BrowserUtils.waitAndClickElement(webDriver, selectButton);
        uploadFileUsingRobot();
        BrowserUtils.waitAndClickElement(webDriver, uploadButton);
        BrowserUtils.waitAndClickElement(webDriver, confirmButton);
        BrowserUtils.waitAndClickElement(webDriver, closeButton);
    }

    public void tryUploadDocument(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, uploadDocumentButton);
        if (accountType.equals("Fertiliser Accounts")) {
            BrowserUtils.waitVisibility(webDriver, uploadPopupTitleFertliserAccount);
        }
        if (accountType.equals("Farm Sketch")) {
            BrowserUtils.waitVisibility(webDriver, uploadPopupTitleFarmSketch);
        }
        if (accountType.equals("Soil Sample")) {
            BrowserUtils.waitVisibility(webDriver, uploadPopupTitleSoilSample);
        }
        BrowserUtils.waitAndClickElement(webDriver, selectButton);
    }

    public void verifyDateWarning(String accountType) {
        if (accountType.equals("Soil Sample")) {
            Assert.assertTrue(BrowserUtils.getText(webDriver, pleaseSelectDateWarning).contains("Please select Date."));
        }
    }

    public void viewDocumentFromDocumentManager(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        BrowserUtils.waitVisibility(webDriver, viewDocumentFarmSketchTitle);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffEditDocumentButton);
        BrowserUtils.waitVisibility(webDriver, editDocumentTitle);
        BrowserUtils.sendKeysToWebElement(webDriver, editDocumentComment, "test comment");
        BrowserUtils.waitAndClickElement(webDriver, confirmButton);
        BrowserUtils.waitAndClickElement(webDriver, closeButton);
    }

    public boolean assertEditDocumentNotAvailable(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        BrowserUtils.waitVisibility(webDriver, viewDocumentFarmSketchTitle);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        try {
            return agentUploadDocumentButton.isDisplayed();
        } catch (NoSuchElementException e) {
            log.error("Element not found");
        }
        return false;
    }

    public String assertEditDocumentNotPossible(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        BrowserUtils.waitVisibility(webDriver, viewDocumentFarmSketchTitle);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffEditDocumentButton);
        return BrowserUtils.getText(webDriver, editDocumentString);
    }

    public String assertDeleteDocumentNotPossible(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        BrowserUtils.waitVisibility(webDriver, viewDocumentFarmSketchTitle);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffDeleteDocumentButton);
        System.out.println(BrowserUtils.getText(webDriver, deleteDocumentString));
        return BrowserUtils.getText(webDriver, deleteDocumentString);
    }

    public void deleteDocument(String accountType, String reason) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        if(accountType.equals("Farm Sketch")){
            BrowserUtils.waitVisibility(webDriver, viewDocumentFarmSketchTitle);
        }
        if(accountType.equals("Soil Sample")){
            BrowserUtils.waitVisibility(webDriver, viewDocumentSoilSampleTitle);
        }
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffDeleteDocumentButton);
        if(accountType.equals("Soil Sample")){
            BrowserUtils.waitVisibility(webDriver, soilSampleDeletePopupText);
            BrowserUtils.waitAndClickElement(webDriver,confirmButton);
        }
        BrowserUtils.waitAndClickElement(webDriver, staffDeleteDocumentReasonDropDown);
        if(reason.equals("GDPR")){
            BrowserUtils.waitAndClickElement(webDriver, staffDeleteDocumentReasonGDPRDropDown);
        }
        if(reason.equals("Other")){
            BrowserUtils.waitAndClickElement(webDriver, staffDeleteDocumentReasonOtherDropDown);
            BrowserUtils.sendKeysToWebElement(webDriver, staffDeleteDocumentReasonOtherComment, "Test comment");
        }
        BrowserUtils.waitAndClickElement(webDriver, confirmButton);
        BrowserUtils.waitVisibility(webDriver, documentSuccessfullydeletedPopUpText);
        BrowserUtils.waitAndClickElement(webDriver, closeButton);
    }

    public void cancelDeleteDocument(String accountType) {
        clickOnAccountType(accountType);
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffDeleteDocumentButton);
        BrowserUtils.waitVisibility(webDriver, soilSampleDeletePopupText);
        BrowserUtils.waitAndClickElement(webDriver,cancelButton);
        BrowserUtils.waitVisibility(webDriver,soilSampleDeletePopupText);
        BrowserUtils.waitAndClickElement(webDriver,closeViewButton);
    }

    public void assertFileUploadFertiliserAccount() {
        BrowserUtils.waitUntilWebElementIsInvisible(webDriver, retrievingApplications);
        clickOnAccountType("Fertiliser Accounts");
        BrowserUtils.waitAndClickElement(webDriver, viewDocumentButton);
        BrowserUtils.waitVisibility(webDriver, viewDocumentTitle);
        String headingTitle = BrowserUtils.getText(webDriver, viewDocumentTitle);
        Assert.assertTrue((headingTitle).contains("Fertiliser Accounts Documents"));
    }
}
