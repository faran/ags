package ie.gov.agriculture.agschemes.utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import lombok.NonNull;

//import edu.emory.mathcs.backport.java.util.Arrays;

/**
 * connects to Bamboo get build information
 */
public class BambooBuildIdReader {

    public static final String RESULT_PROJECT_NAME_KEY = "projectName";
    public static final String RESULT_ENVIRONMENT_NAME_KEY = "environmentName";
    public static final String RESULT_LAST_DEPLOYED_VERSION_KEY = "lastDeployedVersion";
    public static final String RESULT_DEPLOYMENT_DATE_KEY = "deploymentDate";
    private static final String BAMBOO_REST_API_BASE_URI = "https://bamboo.agriculture.gov.ie/bamboo/rest/api/latest/";
    private static final String PROJECT_ENVS_PATH = "deploy/project/all";
    private static final String ENVIRONMENTS_DEPLOY_PATH = "deploy/environment/";
    private static final List<String> relevantKeys = Arrays
        .asList(new String[] { "id", "name", "environments" });

    public static List<Map<String, String>> getLastBuildId(@NonNull String partialExpectedProjectName,
        @NonNull String environment) throws IOException {
        List<Map<String, String>> projectsMapList = getListOfProjectsEnvironmentMaps(
            partialExpectedProjectName, environment);
        List<Map<String, String>> resultsMapsList = new ArrayList<>();
        for (Map<String, String> projectMap : projectsMapList) {
            String projectId = projectMap.get("id");
            String projectName = projectMap.get("name");
            Set<String> envKeys = projectMap.keySet().stream().filter(k -> k.contains("environment"))
                .collect(Collectors.toSet());
            for (String envKey : envKeys) {
                String envId = projectMap.get(envKey);
                Response response = RestAssured.with().auth().preemptive()
                    .basic(ConstantsProvider.getJIRA_USER_NAME(), ConstantsProvider.getJIRA_PASSWORD())
                    .get(ENVIRONMENTS_DEPLOY_PATH + envId + "/results");
                JSONArray deploymentProjectsOnEnvJsonArray = new JSONObject(response.prettyPrint())
                    .getJSONArray("results");
                List<Map<String, Object>> filteredDeploymentProjectsOnEnvList = deploymentProjectsOnEnvJsonArray
                    .toList().stream().map(o -> (Map<String, Object>) o).collect(Collectors.toList())
                    .stream().filter(m -> m.get("key").toString().contains(projectId)).collect(
                        Collectors.toList());
                Optional<Map<String, Object>> lastDeploymentoptional = filteredDeploymentProjectsOnEnvList
                    .stream()
                    .max(Comparator.comparing(m -> Long.parseLong(m.get("finishedDate").toString())));
                if (lastDeploymentoptional.isPresent()) {
                    Map<String, Object> deploymentProjectOnEnvMap = lastDeploymentoptional.get();
                    String deployedVersion = deploymentProjectOnEnvMap.get("deploymentVersionName")
                        .toString();
                    String finishedDate = deploymentProjectOnEnvMap.get("finishedDate")
                        .toString();
                    HashMap<String, String> resultMap = new HashMap<>();
                    resultMap.put(RESULT_PROJECT_NAME_KEY, projectName);
                    resultMap.put(RESULT_ENVIRONMENT_NAME_KEY, envKey);
                    resultMap.put(RESULT_LAST_DEPLOYED_VERSION_KEY, deployedVersion);
                    resultMap
                        .put(RESULT_DEPLOYMENT_DATE_KEY, new Date(Long.parseLong(finishedDate)).toString());
                    resultsMapsList.add(resultMap);
                } else {
                    // TODO do something about Bamboo. may be debug!
                }
            }
        }
        return resultsMapsList;
    }

    private static List<Map<String, String>> getListOfProjectsEnvironmentMaps(
        @NonNull String partialExpectedProjectName, @NonNull String environment) throws IOException {
        // get response from server and convert response List of maps for easier processing
        List<Map<String, Object>> projectsMapList = getProjectsEnvironmentsMapsListFromBamboo();
        // get only relevant projects and reduce keys for easier processing
        projectsMapList = getRelevantProjectsListAndRemoveIrrelevantKeysFromMaps(
            partialExpectedProjectName,
            projectsMapList);
        // get only relevant environment and reduce keys for easier processing
        List<Map<String, String>> modifiedProjectsMapList = getRelevantEnvironmentInEachProjectAndReduceKeysInMaps(
            environment,
            projectsMapList);
        return modifiedProjectsMapList;
    }

    private static List<Map<String, Object>> getProjectsEnvironmentsMapsListFromBamboo()
        throws IOException {
        RestAssured.baseURI = BAMBOO_REST_API_BASE_URI;
        Response response = RestAssured.with().auth().preemptive()
            .basic(ConstantsProvider.getJIRA_USER_NAME(), ConstantsProvider.getJIRA_PASSWORD())
            .get(PROJECT_ENVS_PATH);
        ObjectMapper mapper = new ObjectMapper();
        // convert server response to List of maps for easier processing
        return mapper
            .readValue(response.getBody().prettyPrint(), List.class);
    }

    private static List<Map<String, Object>> getRelevantProjectsListAndRemoveIrrelevantKeysFromMaps(
        @NonNull String partialExpectedProjectName, List<Map<String, Object>> projectsMapList) {
        List<Map<String, Object>> irrelevantProjectsMapList = new ArrayList<>();
        // REDUCE THE KEYS IN EACH MAP OF PROJECTS TO ONLY IMPORTANT ENTRIES
        for (Map<String, Object> projectMap : projectsMapList) {
            if (!StringUtils
                .containsIgnoreCase(projectMap.get("name").toString(), partialExpectedProjectName)) {
                irrelevantProjectsMapList.add(projectMap);
            } else {
                Set<String> unneededProjectKeys = projectMap.keySet().stream()
                    .filter(k -> !relevantKeys.contains(k)).collect(
                        Collectors.toSet());
                unneededProjectKeys.forEach(k -> projectMap.remove(k));
            }
        }
        projectsMapList.removeAll(irrelevantProjectsMapList);
        return projectsMapList;
    }

    private static List<Map<String, String>> getRelevantEnvironmentInEachProjectAndReduceKeysInMaps(
        @NonNull String environment, List<Map<String, Object>> projectsMapList) {
        List<Map<String, String>> modifiedProjectsMapList = new ArrayList<>();
        List<Map<String, Object>> irrelevantEnvsMapList = new ArrayList<>();
        // REDUCE THE KEYS IN EACH ENVIRONMENTS MAP TO ONLY IMPORTANT ENTRIES
        for (Map<String, Object> projectMap : projectsMapList) {
            HashMap<String, String> modifiedProjectMap = new HashMap<>();
            modifiedProjectMap.put("id", projectMap.get("id").toString());
            modifiedProjectMap.put("name", projectMap.get("name").toString());

            List<Map<String, Object>> environmentsForEachProj = (List<Map<String, Object>>) projectMap
                .get("environments");
            for (Map<String, Object> environmentForEachProj : environmentsForEachProj) {
                if (!StringUtils
                    .containsIgnoreCase(environmentForEachProj.get("name").toString(), environment)) {
                    irrelevantEnvsMapList.add(environmentForEachProj);
                } else {
                    Set<String> unneededProjectKeys = environmentForEachProj.keySet().stream()
                        .filter(k -> !relevantKeys.contains(k)).collect(
                            Collectors.toSet());
                    unneededProjectKeys.forEach(k -> environmentForEachProj.remove(k));
                    modifiedProjectMap.put("environment-" + environmentForEachProj.get("name"),
                        environmentForEachProj.get("id").toString());
                }
            }
            environmentsForEachProj.removeAll(irrelevantEnvsMapList);
            modifiedProjectsMapList.add(modifiedProjectMap);
        }
        return modifiedProjectsMapList;
    }
}
