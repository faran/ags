package ie.gov.agriculture.agschemes.browserpages.nitrates;

import java.io.IOException;

public interface INitratesApplicationFormPage {

    void clickCreateApplicationNoUserInputAndClickSaveAsDraft() throws Exception;

    void createApplicationAndClickCancel(String herdno) throws Exception;

    void createApplicationEnterValidUserInputAndClickSaveAsDraft(String herdno) throws Exception;

    void createApplicationWithNoDataEnterValidUserInputAndClickSaveAsDraft(String herdno) throws Exception;

    void createApplicationEnterValidUserInputForSubmit(String herdno) throws Exception;

    void createApplicationWithNoDataEnterValidUserInputForSubmit(String herdno) throws Exception;

    void createApplicationEnterIncorrectUserInputForSubmit(String herdno) throws Exception;

    void getCustomerDetails() throws InterruptedException, IOException;

}