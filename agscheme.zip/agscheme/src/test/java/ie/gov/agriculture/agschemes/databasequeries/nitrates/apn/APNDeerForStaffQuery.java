package ie.gov.agriculture.agschemes.databasequeries.nitrates.apn;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLException;

import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.databasequeries.IQuery;
import ie.gov.agriculture.agschemes.databasequeries.QueryBase;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class APNDeerForStaffQuery extends QueryBase implements IQuery {

    public APNDeerForStaffQuery(String herdNo, String year, String applicationStatus) {
        super(herdNo, year, applicationStatus);
        buildQuery();
    }

    @Override
    public void buildQuery() {
        query = "select APN_DEER from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";
        log.warn("the APN_DEER_query value is " + query);
    }

    @Override
    public String runQuery() throws SQLException {
        stringResult = db.executeQueryReturningString(query);
        log.warn("the APN_DEER_result value is " + stringResult);

        assertThat(stringResult).isNotEmpty();
        log.warn("animalsOnHoldingCheckValue " + TestDataHolder.getTestDataRecord("animalsOnHoldingCheckValue"));
        assertThat(stringResult).isEqualTo(TestDataHolder.getTestDataRecord("animalsOnHoldingCheckValue"));
        return stringResult;
    }

}
