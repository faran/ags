package ie.gov.agriculture.agschemes.pojo;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class APIDataBuild {

    String currentYear = ConstantsProvider.getHERDYEAR();
    String year2020 = "2020";

    public CreateApplication agentSubmitApplication(){
        CreateApplication asa = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        asa.setDataB("FE4E659B50A5ADD946D9A7A9E9FCE2EE");
        asa.setBpsManualRecordingInd(0);
        asa.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(32.15);
        ea.setEligibleGrasslandArea(32.15);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        asa.setEligibleArea(ea);
        asa.setDataA(null);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        asa.setLiveStockDetails(lsdl);

        asa.setStoragePeriod("16");
        asa.setOrganicManure("99");
        asa.setBdMeasureWbThornTrLftId(true);
        asa.setBdMeasureMaintainHrowId(true);
        asa.setBdMeasureCutHedgrowId(true);
        asa.setEnvironmentalTraining("true");
        asa.setGrasslandTraining("true");
        asa.setTermsConditionsInd(true);
        asa.setSchemeYear(currentYear);

    return asa;
    }

    public CreateApplication staffSubmitApplication(){
        CreateApplication ssa = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        ssa.setDataB("5096AC7BF1F631DDD36834A440EF6BD6");
        ssa.setBpsManualRecordingInd(0);
        ssa.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        ssa.setEligibleArea(ea);
        ssa.setDataA(null);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(98);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        ssa.setLiveStockDetails(lsdl);

        ssa.setStoragePeriod("16");
        ssa.setOrganicManure("99");
        ssa.setBdMeasureWbThornTrLftId(true);
        ssa.setBdMeasureMaintainHrowId(true);
        ssa.setBdMeasureCutHedgrowId(true);
        ssa.setEnvironmentalTraining("true");
        ssa.setGrasslandTraining("true");
        ssa.setTermsConditionsInd(true);
        ssa.setSchemeYear(currentYear);

        return ssa;
    }

    public CreateApplication staffSaveDraftApplication(){
        CreateApplication ssda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        ssda.setDataB("5096AC7BF1F631DDD36834A440EF6BD6");
        ssda.setBpsManualRecordingInd(0);
        ssda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        ssda.setEligibleArea(ea);
        ssda.setDataA(null);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(98);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        ssda.setLiveStockDetails(lsdl);

        ssda.setStoragePeriod("16");
        ssda.setOrganicManure("99");
        ssda.setBdMeasureWbThornTrLftId(true);
        ssda.setBdMeasureMaintainHrowId(true);
        ssda.setBdMeasureCutHedgrowId(true);
        ssda.setEnvironmentalTraining("true");
        ssda.setGrasslandTraining("true");
        ssda.setTermsConditionsInd(true);
        ssda.setSchemeYear(currentYear);

        return ssda;
    }

    public CreateApplication staffUpdateDraftApplication(){
        CreateApplication suda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        suda.setDataB("5096AC7BF1F631DDD36834A440EF6BD6");
        suda.setBpsManualRecordingInd(0);
        suda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("");
        suda.setEligibleArea(ea);
        suda.setDataA(TestDataHolder.getRecord(TestDataHolder.DATA_A));

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(98);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        suda.setLiveStockDetails(lsdl);

        suda.setStoragePeriod("16");
        suda.setOrganicManure("33");
        suda.setBdMeasureWbThornTrLftId(true);
        suda.setBdMeasureMaintainHrowId(true);
        suda.setBdMeasureCutHedgrowId(true);
        suda.setEnvironmentalTraining("true");
        suda.setGrasslandTraining("true");
        suda.setTermsConditionsInd(true);
        suda.setSchemeYear(currentYear);

        return suda;
    }

    public CreateApplication agentSaveDraftApplication(){
        CreateApplication ssda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        ssda.setDataB("FE4E659B50A5ADD946D9A7A9E9FCE2EE");
        ssda.setBpsManualRecordingInd(0);
        ssda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(32.15);
        ea.setEligibleGrasslandArea(32.15);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        ssda.setEligibleArea(ea);
        ssda.setDataA(null);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        ssda.setLiveStockDetails(lsdl);

        ssda.setStoragePeriod("16");
        ssda.setOrganicManure("99");
        ssda.setBdMeasureWbThornTrLftId(true);
        ssda.setBdMeasureMaintainHrowId(true);
        ssda.setBdMeasureCutHedgrowId(true);
        ssda.setEnvironmentalTraining("true");
        ssda.setGrasslandTraining("true");
        ssda.setTermsConditionsInd(true);
        ssda.setSchemeYear(currentYear);

        return ssda;
    }

    public CreateApplication agentUpdateDraftApplication(){
        CreateApplication auda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        auda.setDataB("FE4E659B50A5ADD946D9A7A9E9FCE2EE");
        auda.setBpsManualRecordingInd(0);
        auda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("");
        auda.setEligibleArea(ea);
        auda.setDataA(TestDataHolder.getRecord(TestDataHolder.DATA_A));

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        auda.setLiveStockDetails(lsdl);

        auda.setStoragePeriod("16");
        auda.setOrganicManure("33");
        auda.setBdMeasureWbThornTrLftId(true);
        auda.setBdMeasureMaintainHrowId(true);
        auda.setBdMeasureCutHedgrowId(true);
        auda.setEnvironmentalTraining("false");
        auda.setGrasslandTraining("true");
        auda.setTermsConditionsInd(true);
        auda.setSchemeYear(currentYear);

        return auda;
    }

    public CreateApplication agentSubmitDraftApplication(){
        CreateApplication asda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        asda.setDataB("FE4E659B50A5ADD946D9A7A9E9FCE2EE");
        asda.setBpsManualRecordingInd(0);
        asda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("");
        asda.setEligibleArea(ea);
        asda.setDataA(TestDataHolder.getRecord(TestDataHolder.DATA_A));

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        asda.setLiveStockDetails(lsdl);

        asda.setStoragePeriod("16");
        asda.setOrganicManure("33");
        asda.setBdMeasureWbThornTrLftId(true);
        asda.setBdMeasureMaintainHrowId(true);
        asda.setBdMeasureCutHedgrowId(true);
        asda.setEnvironmentalTraining("false");
        asda.setGrasslandTraining("true");
        asda.setTermsConditionsInd(true);
        asda.setSchemeYear(currentYear);

        return asda;
    }

    public String agentDeleteApplication() {
        return TestDataHolder.getRecord(TestDataHolder.DATA_A);
    }

    public CreateApplication agentSubmitApplicationForNonClient(){
        CreateApplication asda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        asda.setDataB("881C10F8697E3CE696F413FE24869747");
        asda.setBpsManualRecordingInd(0);
        asda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        asda.setEligibleArea(ea);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        asda.setLiveStockDetails(lsdl);

        asda.setStoragePeriod("16");
        asda.setOrganicManure("33");
        asda.setBdMeasureWbThornTrLftId(true);
        asda.setBdMeasureMaintainHrowId(true);
        asda.setBdMeasureCutHedgrowId(true);
        asda.setEnvironmentalTraining("false");
        asda.setGrasslandTraining("true");
        asda.setTermsConditionsInd(true);
        asda.setSchemeYear(currentYear);

        return asda;
    }

    public CreateApplication agentSaveDraftApplicationForNonClient(){
        CreateApplication asda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        asda.setDataB("881C10F8697E3CE696F413FE24869747");
        asda.setBpsManualRecordingInd(0);
        asda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        asda.setEligibleArea(ea);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        asda.setLiveStockDetails(lsdl);

        asda.setStoragePeriod("16");
        asda.setOrganicManure("33");
        asda.setBdMeasureWbThornTrLftId(true);
        asda.setBdMeasureMaintainHrowId(true);
        asda.setBdMeasureCutHedgrowId(true);
        asda.setEnvironmentalTraining("false");
        asda.setGrasslandTraining("true");
        asda.setTermsConditionsInd(true);
        asda.setSchemeYear(currentYear);

        return asda;
    }

    public CreateApplication agentUpdateDraftApplicationForNonClient(){
        CreateApplication asda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        asda.setDataB("881C10F8697E3CE696F413FE24869747");
        asda.setBpsManualRecordingInd(0);
        asda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        asda.setEligibleArea(ea);
        asda.setDataA(TestDataHolder.getRecord(TestDataHolder.DATA_A));

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(40);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        asda.setLiveStockDetails(lsdl);

        asda.setStoragePeriod("16");
        asda.setOrganicManure("33");
        asda.setBdMeasureWbThornTrLftId(true);
        asda.setBdMeasureMaintainHrowId(true);
        asda.setBdMeasureCutHedgrowId(true);
        asda.setEnvironmentalTraining("false");
        asda.setGrasslandTraining("true");
        asda.setTermsConditionsInd(true);
        asda.setSchemeYear(currentYear);

        return asda;
    }

    public String agentViewOwnApplication() {
        return TestDataHolder.getRecord(TestDataHolder.DATA_A);
    }

    public String agentViewNPDetails() {
        return "FE4E659B50A5ADD946D9A7A9E9FCE2EE";
    }

    public String staffViewNPDetails() {
        return "5096AC7BF1F631DDD36834A440EF6BD6";
    }

    public QueryApplication queryApplication(){
        QueryApplication qa = new QueryApplication();
        qa.setDataA(TestDataHolder.getRecord(TestDataHolder.DATA_A));
        qa.setEventReasonCode(100009);
        qa.setDocType(null);
        qa.setDocYear(null);
        qa.setUserComment("Test Comment Automation Framework");

        return qa;
    }

    public Map<String, String> uploadDocument(String docType, String docId, String docYear){
        Map<String, String> fp = new HashMap<>();
        fp.put("dataA",TestDataHolder.getRecord(TestDataHolder.DATA_A));
        fp.put("dataB", TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        fp.put("documentType", docType);
        fp.put("documentTypeIdString", docId);
        fp.put("fileName", "uploadfile.text");
        fp.put("fileSizeString", "408");
        fp.put("documentCreatedYear", docYear);
        return fp;
    }

    public CreateApplication staffSaveDraftApplication2020(){
        CreateApplication ssda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        ssda.setDataB("9C4CBBC8C74F26DC6CAE386A949C162E");
        ssda.setBpsManualRecordingInd(0);
        ssda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("");
        ssda.setEligibleArea(ea);
        ssda.setDataA(null);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(1);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        ssda.setLiveStockDetails(lsdl);

        ssda.setStoragePeriod("16");
        ssda.setOrganicManure("99");
        ssda.setBdMeasureWbThornTrLftId(true);
        ssda.setBdMeasureMaintainHrowId(true);
        ssda.setBdMeasureCutHedgrowId(true);
        ssda.setEnvironmentalTraining("true");
        ssda.setGrasslandTraining("true");
        ssda.setTermsConditionsInd(true);
        ssda.setSchemeYear(year2020);

        return ssda;
    }

    public CreateApplication agentSaveDraftApplication2020(){
        CreateApplication ssda = new CreateApplication();
        CreateApplication.LiveStockDetails lsd = new CreateApplication.LiveStockDetails();
        ssda.setDataB("074275758CABC0ECA2D80D3325436A79");
        ssda.setBpsManualRecordingInd(0);
        ssda.setAhcsManualRecordingInd(false);
        CreateApplication.EligibleArea ea = new CreateApplication.EligibleArea();
        ea.setEligibleHoldingArea(76.41);
        ea.setEligibleGrasslandArea(76.41);
        ea.setGrasslandPercent(null);
        ea.setBpsFlag("Y");
        ssda.setEligibleArea(ea);
        ssda.setDataA(null);

        List<CreateApplication.LiveStockDetails> lsdl = new ArrayList<>();
        lsd.setANIMAL_TYPE("BOVINE");
        lsd.setCOUNT(98);
        lsd.setANIMAL_DESCRIPTION("COW");
        lsdl.add(lsd);
        ssda.setLiveStockDetails(lsdl);

        ssda.setStoragePeriod("16");
        ssda.setOrganicManure("99");
        ssda.setBdMeasureWbThornTrLftId(true);
        ssda.setBdMeasureMaintainHrowId(true);
        ssda.setBdMeasureCutHedgrowId(true);
        ssda.setEnvironmentalTraining("true");
        ssda.setGrasslandTraining("true");
        ssda.setTermsConditionsInd(true);
        ssda.setSchemeYear(year2020);

        return ssda;
    }
}
