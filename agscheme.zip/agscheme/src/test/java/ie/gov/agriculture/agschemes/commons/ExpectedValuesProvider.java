package ie.gov.agriculture.agschemes.commons;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import io.cucumber.java.PendingException;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assume;

import lombok.extern.log4j.Log4j2;

/**
 * works with the file resources/expected-values.properties to return expected values as list of Strings.
 */
@Log4j2
public class ExpectedValuesProvider {

    static {
        final String RESOURCES_EXPECTED_VALUES_TEST_DATA_PROPERTIES = "resources/expected-values.properties";
        Properties initProperties = new Properties();
        try (
            InputStream propertyFileInputStream = new FileInputStream(RESOURCES_EXPECTED_VALUES_TEST_DATA_PROPERTIES)) {
            initProperties.load(propertyFileInputStream);
            allProperties = initProperties;
        } catch (final IOException e) {
            log.fatal("failed to load the constants file from: "
                + RESOURCES_EXPECTED_VALUES_TEST_DATA_PROPERTIES);
            Assume.assumeNoException(e);
        }
    }

    private static Properties allProperties;
    private static final String GET_FIXED_DEDUCTION_REASON_LIST = allProperties
        .getProperty("getFixedDeductionReasonListExpectedValues");

    public static List<String> getExpectedValuesAsList(String expectedValuesName) {
        List<String> expectedLabels = null;
        switch (expectedValuesName) {
        case "FIXED_DEDUCTION_REASON_LIST":
            expectedLabels = getGET_FIXED_DEDUCTION_REASON_LIST();
            break;
        default:
            throw new PendingException(
                "expected values for: " + expectedValuesName + " not configured");
        }
        return expectedLabels;
    }

    public static List<String> getGET_FIXED_DEDUCTION_REASON_LIST() {
        return Arrays
            .asList(StringUtils.splitPreserveAllTokens(GET_FIXED_DEDUCTION_REASON_LIST, ","));
    }
}
