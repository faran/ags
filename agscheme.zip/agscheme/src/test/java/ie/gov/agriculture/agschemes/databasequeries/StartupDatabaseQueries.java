package ie.gov.agriculture.agschemes.databasequeries;

import static ie.gov.agriculture.agschemes.utils.DateUtil.*;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.fail;

import java.sql.SQLException;
import java.util.ArrayList;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.utils.DatabaseUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class StartupDatabaseQueries {

    public void deleteApplication(String herdno, String year) throws Exception {

        String applicationId = selectFromTdasApplications(herdno, year);

        if (applicationId != null && !applicationId.isEmpty()) {

            log.warn("PROCCED WITH DELETING : applicationId was not null or empty");
            deleteFromTdasDocuments(applicationId);
            deleteFromTdasApplicationsUnderQuery(applicationId);
            deleteFromTdasApplicationsTracking(applicationId);
            deleteFromTdasApplicationsNitrates(applicationId);
            deleteFromTdasApplications(applicationId);
        }
    }

    private String selectFromTdasApplications(String herdno, String year) throws SQLException {
        String result;
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String query = "select APP_APPLICATION_ID from tdas_applications where app_current_business_id = '"
            + herdno + "' and app_scheme_year = '" + year + "'";
        log.warn("select query 1 : selectAllFromTdasApplicationsQuery IS " + query);

        result = db.executeQueryReturningString(query);
        log.warn("result 1 : selectAllFromTdasApplicationsResult IS " + result);
        return result;
    }

    private void deleteFromTdasDocuments(String applicationId)
        throws Exception {
        try {
            DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
            String query = "delete from tdas_documents where doc_application_id = "
                + applicationId + "";
            log.warn("delete query 1 : deleteFromTdasDocumentQuery " + query);
            db.executeDeleteInDb(query);
        } catch (SQLException e) {
            e.printStackTrace();
            log.error(" ERROR 1 : failed to delete deleteFromTdasDocumentQuery check and log defect");
            fail("FAIL 1: failed to delete deleteFromTdasDocumentQuery check and log defect");
        }
    }

    private void deleteFromTdasApplicationsUnderQuery(String applicationId)
        throws Exception {
        try {
            DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
            String query = "delete from TDAS_APPLICATIONS_UNDER_QUERY where APD_APPLICATION_ID = "
                + applicationId + "";
            log.warn("delete query 2 : deleteFrom_TDAS_APPLICATIONS_UNDER_QUERY "
                + query);
            db.executeDeleteInDb(query);
        } catch (SQLException e) {
            e.printStackTrace();
            log.error("ERROR 2 : failed to delete deleteFrom_TDAS_APPLICATIONS_UNDER_QUERY check and log defect");
            fail("FAIL 2 : failed to delete deleteFrom_TDAS_APPLICATIONS_UNDER_QUERY check and log defect");
        }
    }

    private void deleteFromTdasApplicationsTracking(String applicationId)
        throws Exception {
        try {
            DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
            String query = "delete from tdas_applications_tracking where at_application_id = "
                + applicationId + "";
            log.warn(
                "delete query 3 : deleteFromTdasApplicationsTrackingQuery "
                    + query);
            db.executeDeleteInDb(query);
        } catch (SQLException e) {
            e.printStackTrace();
            log.error("ERROR 3: failed to delete deleteFromTdasApplicationsTrackingQuery check and log defect");
            fail("FAIL 3: failed to delete deleteFromTdasApplicationsTrackingQuery check and log defect");
        }
    }

    private void deleteFromTdasApplicationsNitrates(String applicationId)
        throws Exception {
        try {
            DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
            String query = "delete from tdas_applications_nitrates where apn_application_id = "
                + applicationId + "";
            log.warn("delete query 4 : deleteFromTdasApplicationsNitrates " + query);
            db.executeDeleteInDb(query);
        } catch (SQLException e) {
            e.printStackTrace();
            log.error("ERROR 4: failed to delete deleteFromTdasApplicationsNitrates check and log defect");
            fail("FAIL 4 : failed to delete deleteFromTdasApplicationsNitrates check and log defect");

        }
    }

    private void deleteFromTdasApplications(String applicationId)
        throws Exception {
        try {
            DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
            String query = "delete from tdas_applications where app_application_id = "
                + applicationId + "";
            log.warn("delete query 5 : deleteFromtdasApplications " + query);
            db.executeDeleteInDb(query);
        } catch (SQLException e) {
            e.printStackTrace();
            log.error("ERROR 5 : failed to delete deleteFromtdasApplications check and log defect");
            fail("FAIL 5 : failed to delete deleteFromtdasApplications check and log defect");
        }
    }

    public void selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData() throws Exception {

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        // selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_query

        String query = "with herd_detail as ( select client_bus_id from table (cast(pkas_ext_ccs.ftab_clients_per_agent(3109861, 'BPS') as tab_agent_hr_list)) ) SELECT herd_no FROM VWAH_HERD_SPECIES_BREAKDOWN Animals, herd_detail WHERE herd_no = herd_detail.client_bus_id AND ( NVL(bovine_count,0) = 0 AND NVL(ovine_count,0) = 0 AND NVL(cervine_count,0) = 0 AND NVL(caprine_count,0) = 0 AND NVL(equine_count,0) = 0 ) AND NOT EXISTS ( SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Holding_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.HERD = Animals.herd_no AND ca.YEAR = 2021 AND ca.CROP_CODE IN ( 393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172, 333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407, 410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359, 491,492,361,498,499,493,317,500,408,409,380 ) UNION SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Holding_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.HERD = Animals.herd_no AND ca.YEAR = 2020 AND ca.CROP_CODE IN ( 393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172, 333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407, 410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359, 491,492,361,498,499,493,317,500,408,409,380 ) ) AND NOT EXISTS ( SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Grassland_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.HERD = Animals.herd_no AND ca.YEAR = 2021 AND ca.CROP_CODE IN ( 393, 187, 391, 396, 397, 398, 399, 401, 311, 505, 392, 342, 478, 330, 361 ) AND ca.COMMONAGE_IND = 'N' UNION SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Grassland_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.HERD = Animals.herd_no AND ca.YEAR = 2020 AND ca.CROP_CODE IN ( 393, 187, 391, 396, 397, 398, 399, 401, 311, 505, 392, 342, 478, 330, 361 ) AND ca.COMMONAGE_IND = 'N' ) AND NOT EXISTS ( SELECT * FROM tdas_applications WHERE app_current_business_id = Animals.herd_no AND app_Scheme_year = 2021 AND app_current_status_code != 100008 ) FETCH FIRST 1 ROWS ONLY";
        log.warn("the selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_query value is "
            + query);
        String result = db.executeQueryReturningString(query);
        log.warn("the selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result value is "
            + result);

        // add to data record to use in later steps in test
        TestDataHolder.addTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result",
            result, true, true);
        log.warn("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result" + TestDataHolder
            .getTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result"));

    }

    public void selectsApplicationWithSomeAnimalAndGrasslandAndAreaOfHoldingData() throws Exception {

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        // numbersForTheAnimals_Query

        String numbersForTheAnimals_Query = "SELECT herd_no,bovine_count, ovine_count, cervine_count, caprine_count, equine_count FROM( SELECT herd_no,bovine_count, ovine_count, cervine_count, caprine_count, equine_count FROM VWAH_HERD_SPECIES_BREAKDOWN, ( select client_bus_id from table (cast(pkas_ext_ccs.ftab_clients_per_agent(3109861, 'BPS') as tab_agent_hr_list))) where ( bovine_count > 0 and ovine_count = 0 and cervine_count = 0 and caprine_count = 0 and equine_count = 0 ) AND herd_no = client_bus_id ) Animals WHERE EXISTS ( SELECT Holding_Area FROM ( SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Holding_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.YEAR in ( 2020, 2021) AND HERD = Animals.herd_no AND ca.CROP_CODE IN ( 393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172, 333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407, 410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359, 491,492,361,498,499,493,317,500,408,409,380 ) ) WHERE Holding_Area > 0 ) AND EXISTS ( SELECT Grassland_Area FROM ( SELECT LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0)) Grassland_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.YEAR IN (2020 ,2021) AND HERD = Animals.herd_no AND ca.CROP_CODE IN ( 393, 187, 391, 396, 397, 398, 399, 401, 311, 505, 392, 342, 478, 330, 361 ) AND ca.COMMONAGE_IND = 'N' ) WHERE Grassland_Area > 0 ) FETCH FIRST 1 ROWS ONLY";
        log.warn("the numbersForTheAnimals_Query value is " + numbersForTheAnimals_Query);

        String numbersForTheAnimals_Result = db.executeQueryReturningString(numbersForTheAnimals_Query);

        log.warn("the numbersForTheAnimals_Result value is " + numbersForTheAnimals_Result);

        // holdingArea_Query

        String holdingArea_Query = "SELECT SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Holding_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.YEAR = 2020 AND HERD = '"
            + numbersForTheAnimals_Result
            + "' AND ca.CROP_CODE IN( 393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172, 333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407, 410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359, 491,492,361,498,499,493,317,500,408,409,380)";
        log.warn("the holdingArea_Query value is " + holdingArea_Query);

        String holdingArea_Result = db.executeQueryReturningString(holdingArea_Query);

        log.warn("the holdingArea_Result value is " + holdingArea_Result);

        // fail the test if area of holding is null
        assertThat(holdingArea_Result).isNotEmpty();

        // grasslandArea_Query

        String grasslandArea_Query = "SELECT SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Grassland_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.YEAR = 2020 AND HERD = '"
            + numbersForTheAnimals_Result
            + "' AND ca.CROP_CODE IN( 393, 187, 391, 396, 397, 398, 399, 401, 311, 505, 392, 342, 478, 330, 361) AND ca.COMMONAGE_IND = 'N'";
        log.warn("the grasslandArea_Query value is " + grasslandArea_Query);

        String grasslandArea_Result = db.executeQueryReturningString(grasslandArea_Query);

        log.warn("the grasslandArea_Result value is " + grasslandArea_Result);

        // fail the test if grassland is null
        assertThat(grasslandArea_Result).isNotEmpty();

        // add to data record to use in later steps in test
        TestDataHolder.addTestDataRecord("numbersForTheAnimals_Result", numbersForTheAnimals_Result, true, true);
        log.warn("numbersForTheAnimals_Result" + TestDataHolder.getTestDataRecord("numbersForTheAnimals_Result"));

    }

    public void assertBusinessIdIsActiveOnCcs(String herdno) throws Exception {

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        // businessIdValidOnCss
        // returns table if valid
        // returns nothing if invalid

        String businessIdValidOnCss_query = " select business_id, start_date, end_date  from vwco_agsch_business_customers  where business_id = '"
            + herdno + "' and sysdate between start_date and end_date";
        log.warn("the businessIdValidOnCss_query value is " + businessIdValidOnCss_query);
        String businessIdValidOnCss_result = db.executeQueryReturningString(businessIdValidOnCss_query);
        log.warn("the businessIdValidOnCss_result value is " + businessIdValidOnCss_result);

        assertThat(businessIdValidOnCss_result).as("Business Id (herd number) '" + herdno + "' is active on CCS?")
            .isNotEmpty();

    }

    public String verifyAnimalsOnHoldingCheckAhcsViews(String herdno) throws Exception {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String query = "select * from VWAH_HERD_SPECIES_BREAKDOWN WHERE( bovine_count > 0 OR ovine_count > 0 OR cervine_count > 0 OR caprine_count > 0 OR equine_count > 0) and herd_no = '"
            + herdno + "'";
        log.warn("query for animals, " + query);
        String result = db.executeQueryReturningString(query);
        log.warn("got animals on holding check " + result);
        return result;
    }

    public String verifyAnimalsOnHoldingCheckFetchAnimalInfoStored(String herdno) throws Exception {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        // TODO: REPLACE LATER
        // String query = "select * from VWAH_HERD_SPECIES_BREAKDOWN where herd_no = '"
        // + herdno + "'";
        String query = " select Animal_type,Count,decode(Animal_type,'BOVINE','COW','OVINE','SHEEP', "
            + "'CERVINE','DEER','CAPRINE','GOAT','EQUINE','HORSE') as Animal_description "
            + "from (select * from tdas_applications_nitrates, tdas_applications where app_Current_business_id = '"
            + herdno + "'" + "and app_application_id = apn_application_id)" + "unpivot( Count " + "for animal_type "
            + "IN ( APN_CATTLE AS 'BOVINE', " + "APN_SHEEP AS 'OVINE', " + "APN_HORSES AS 'EQUINE', "
            + "APN_GOATS AS 'CAPRINE', " + "APN_DEER AS 'CERVINE' " + ") " + ") " + "where COUNT > 0";
        log.warn("query for animals, " + query);
        String result = db.executeQueryReturningString(query);
        log.warn("got animals on holding check, " + result);
        return result;
    }

    public String verifyEligibleAreaOfHolding(String herdno) throws Exception {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String result = "";
        try {
            String eligibleAreaOfHoldingQuery = "SELECT Holding_Area FROM( SELECT ca.YEAR, SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Holding_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.YEAR in (2021, 2020) AND HERD = '"
                + herdno
                + "' AND ca.CROP_CODE IN ( 393,187,414,415,416,417,404,405,418,496,497,419,423,424,425,426,427,428,390,429,430,431,432,433,434,391,439,441,442,506,340,446,381,172, 333,385,386,332,396,397,398,399,401,311,325,518,519,452,318,454,455,456,457,458,337,312,505,392,412,9,460,330,461,179,335,463,465,406,407, 410,411,466,467,468,469,470,7,472,342,473,394,345,346,356,475,501,476,478,336,480,481,175,484,485,313,486,502,487,171,489,316,490,359, 491,492,361,498,499,493,317,500,408,409,380) GROUP BY ca.YEAR order by year desc fetch first 1 row only ) WHERE Holding_Area > 0";
            result = db.executeQueryReturningString(eligibleAreaOfHoldingQuery);
            log.warn("Eligible Area of Holding (Ha) " + result);
        } catch (Exception e) {
            log.warn("continue.. if nothing null value for eligibleAreaOfHoldingQuery");

        }

        return result;

    }

    public String verifyEligibleAreaOfGrassland(String herdno) throws Exception {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String result = "";

        try {
            String eligibleAreaOfGrasslandQuery = "SELECT Grassland_Area FROM( SELECT ca.YEAR, SUM(LEAST(NVL(MEA_AREA,0), NVL(AREA_CLAIMED,0))) Grassland_Area FROM VWDP_CROP_ACREAGE ca WHERE ca.YEAR in (2021, 2020) AND HERD = '"
                + herdno
                + "' AND ca.CROP_CODE IN ( 393, 187, 391, 396, 397, 398, 399, 401, 311, 505, 392, 342, 478, 333, 361) AND ca.COMMONAGE_IND = 'N' GROUP BY ca.YEAR order by year desc fetch first 1 row only ) WHERE Grassland_Area > 0";
            result = db.executeQueryReturningString(eligibleAreaOfGrasslandQuery);
            log.warn("Eligible Area of Holding (Ha) , " + result);
        } catch (Exception e) {
            log.warn("continue.. if nothing null value for eligibleAreaOfGrasslandQuery");

        }
        return result;
    }

    public ArrayList<String> verifyApplicationIsSubmittedStatus(String herdno) throws Exception {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String query = "select APP_CURRENT_BUSINESS_ID, APN_NET_AREA_OF_HOLDING, APN_NET_GRASSLAND, APN_CATTLE, APN_STORAGE_PERIOD, APN_AMOUNT_SLURRY_SPREAD, APN_BDMEASURE_CUT_HEDGROW_ID, APN_TERMS_CONDITIONS_IND  from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdno + "' and ST_STATUS_DESCRIPTION = 'Application Submitted' order by APN_AUDIT_DATE desc";
        ArrayList<String> result = db.getFirstRowList(query);
        // TODO
        /*
         * for (int i = 0; i < result.size(); i++) { assertThat(result.get(i) != null); log.info("result value : " +
         * result.get(i) + "result index" + i); }
         */
        return result;
    }

    public ArrayList<String> verifyApplicationIsDraftStatusOld(String herdno) throws Exception {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String query = "select APP_CURRENT_BUSINESS_ID, APN_NET_AREA_OF_HOLDING, APN_NET_GRASSLAND, APN_CATTLE, APN_STORAGE_PERIOD, APN_AMOUNT_SLURRY_SPREAD, APN_BDMEASURE_CUT_HEDGROW_ID, APN_TERMS_CONDITIONS_IND  from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdno + "' and ST_STATUS_DESCRIPTION = 'Application Draft' order by APN_AUDIT_DATE desc";
        ArrayList<String> result = db.getFirstRowList(query);
        // TODO
        /*
         * for (int i = 0; i < result.size(); i++) { assertThat(result.get(i) != null); log.info("result value : " +
         * result.get(i) + "result index" + i); }
         */
        return result;
    }


    public static Integer updateSchemeyearClosingTime() {
        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        int result = 0;

        try {
            String updateSchemeyearClosingTime = "UPDATE TSAS_APPLICATIONS_TYPE"
                    + " SET APPT_APPLICATION_CLOSING_DATE = TO_TIMESTAMP('"+ addFiveMinToTimeStamp() +"')"
                    + " WHERE APPT_APPLICATION_CODE = '100001'";
            result = db.executeUpdateInDb(updateSchemeyearClosingTime);
            log.warn("Scheme year is activated , " + result);
        } catch (Exception e) {
            log.warn("continue.. if nothing null value for updateSchemeyearClosingTime");

        }
        return result;
    }

    public static void main(String[] args) {
        System.out.println(updateSchemeyearClosingTime());
    }

}
