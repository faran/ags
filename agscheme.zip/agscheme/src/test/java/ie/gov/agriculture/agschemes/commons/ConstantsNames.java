package ie.gov.agriculture.agschemes.commons;

/**
 * constants names to be used mainly by the ConstantsProvider. The values of these properties are stored in
 * {@value #CONSTANTS_FILE_NAME}. Some are provided here to standardize names
 *
 * @author youssef.abdalla
 */
public class ConstantsNames {

    public static final String URL = "url";
    public static final String SSO_STAFF_LOGIN_USER_NAME_DEV = "ssoStaffLoginUsernameDev";
    public static final String SSO_AGENT_LOGIN_USER_NAME_DEV = "ssoAgentLoginUsernameDev";
    public static final String SSO_INDIVIDUAL_LOGIN_USER_NAME_DEV = "ssoIndividualLoginUsernameDev";
    public static final String HERDNO1 = "herdno1";
    public static final String HERDNO1STAFF = "herdno1staff";
    public static final String HERD_NO_DATA_STAFF = "herdNoDataStaff";
    public static final String HERD_WITH_SOME_DATA_STAFF = "herdWithSomeDataStaff";
    public static final String CUSTOMER_ID = "customerid";
    public static final String CUSTOMER_ID_AGENT = "customeridagent";
    public static final String HERD_WITH_N_AND_P_DETAILS_STAFF = "herdnandpdetailsStaff";
    public static final String HERD_WITH_APPLICATION_APPROVED = "herdapplicationapproved";
    public static final String HERD_NOT_IN_BPS = "herdNotInBPS";
    public static final String NTR_NITRATES_YEAR_STAFF = "ntrnitratesyearstaff";
    public static final String HERDNO1AGENT = "herdno1agent";
    public static final String NONCLIENT1 = "nonclient1";
    public static final String HERD_NO_DATA_AGENT = "herdNoDataAgent";
    public static final String HERDNO3AGENT = "herdno3agent";
    public static final String HERDNO1AGENTSAMPLE = "herdno1agentsample";
    public static final String HERDYEAR = "herdyear";
    public static final String ESTIMATEDNITROGENSPREAD = "estimatedNitrogenSpread";
    public static final String ANIMALCOUNT = "animalcount";
    public static final String ELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT = "eligibleAreaOfHoldingCheckStaffInput";
    public static final String ELIGIBLEAREAOFGRASSLANDSTAFFINPUT = "eligibleAreaofGrasslandStaffInput";
    public static final String INVALIDESTIMATEDNITROGENSPREAD = "invalidestimatedNitrogenSpread";
    public static final String INVALIDELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT = "invalideligibleAreaOfHoldingCheckStaffInput";
    public static final String INVALIDELIGIBLEAREAOFGRASSLANDSTAFFINPUT = "invalideligibleAreaofGrasslandStaffInput";
    public static final String SSOSTAFFLOGINUSERNAMECENTEST = "ssoStaffLoginUsernameCentest";
    public static final String SSOAGENTLOGINUSERNAMECENTEST = "ssoAgentLoginUsernameCentest";
    public static final String SSOINDIVIDUALLOGINUSERNAMECENTEST = "ssoIndividualLoginUsernameCentest";
    public static final String DEVAGENTURL = "devagenturl";
    public static final String DEVINDIVIDUALURL = "devindividualurl";
    public static final String CENTESTSTAFFURL = "centeststaffurl";
    public static final String CENTESTAGENTURL = "centestagenturl";
    public static final String CENTESTINDIVIDUALURL = "centestindividualurl";
    public static final String DEVSTAFFURL = "devstaffurl";
    public static final String EIRCODE = "eircode";
    public static final String ADDRESS = "address";
    public static final String CONTACTNUMBER = "contactnumber";
    public static final String USERNAME = "username";
    public static final String PASSWORD = "password";
    public static final String CLIENTID = "clientID";
    public static final String GRANT_TYPE = "grantType";
    public static final String ACCESS_TOKEN_URL = "accessTokenURL";
    public static final String SUSPECT_REPORT_SERVICE_URL = "suspectReportServiceURL";

    static final String REST_ASSURED_BASE_URLS_START = "restAssuredBaseUrlsStart";
    static final String REST_ASSURED_BASE_URLS_END = "restAssuredBaseUrlsEnd";
    static final String REST_ASSURED_INET_BASE_URLS_START = "restAssuredInetBaseUrlStart";

    static final String BASE_URL_AG_APPS = "baseURAgApps";
    static final String BASE_URL_AG_FOODS = "baseURLAgFoods";

    static final String BASE_PATH = "internalApplicationBasePath";
    static final String GLOBAL_TIMEOUT_IN_SECONDS = "globalTimeOutInSecs";
    static final String CONSTANTS_FILE_NAME = "resources/constants.properties";
    static final String JIRA_URL = "jiraUrl";
    static final String ZAPI_PATH = "zapiPath";
    static final String TEST_CYCLE_NAME = "testcycle";

    // This is the Jira instance used for the iSmart workflow. This is
    // different from Jira instance the one used for controlling issues
    static final String SELENIUM_GRID_ON = "grid";
    static final String SELENIUM_VM_IP = "seleniumVmIp";
    static final String SELENIUM_HUB_PORT = "seleniumHubPort";
    static final String SELENIUM_DRIVER_PATH = "seleniumDriverPath";
    static final String WEB_BROWSER = "browser";

    static final String SSO_LOGIN_PASSWORD_DEV = "ssoLoginPasswordDev";
    static final String SSO_LOGIN_PASSWORD_UAT = "ssoLoginPasswordUat";
    static final String SSO_LOGIN_PASSWORD_CENTEST = "ssoLoginPasswordCentest";
    static final String JIRA_USER_NAME = "jiraUsername";
    static final String JIRA_PASSWORD = "jiraPassword";
    static final String ENVIRONMENT_DEFAULT = "environmentDefault";

    // preventing instantiation and extension
    private ConstantsNames() {
    }
}
