package ie.gov.agriculture.agschemes.databasequeries;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.utils.DatabaseUtils;

public class QueryBase {
    protected final DatabaseUtils db;
    protected String query;
    protected String herdNo;
    protected String year;
    protected String applicationStatus;
    protected String stringResult;
    protected boolean booleanResult;

    public QueryBase(String herdNo, String year, String applicationStatus) {
        this.herdNo = herdNo;
        this.year = year;
        this.applicationStatus = applicationStatus;
        this.db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
    }

}
