package ie.gov.agriculture.agschemes.browserpages.nitrates;

import static org.assertj.core.api.Assertions.assertThat;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import org.apache.commons.lang3.NotImplementedException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.browserpages.sso.SsoPopupPage;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Log4j2
public class NitratesLandingPage {

    protected final WebDriver webDriver;
    protected SsoPopupPage ssoPopupPageObject;
    String value;
    int rowValue;

    @FindBy(id = "advance-search-button")
    protected WebElement advancedSearchText;

    @FindBy(id = "staff-scheme-select-year")
    protected WebElement staffSchemeSelectYear;

    @FindBy(id = "staff-scheme-button-create")
    protected WebElement staffCreateApplicationButton;

    @FindBy(id = "staff-scheme-option-2021")
    protected WebElement staffSchemeOption2021;

    @FindBy(id = "agent-login-input-businessId")
    protected WebElement searchInputTextAgent;

    @FindBy(id = "menu-button")
    protected WebElement menuButton;

    @FindBy(xpath = "//*[@id='panel-content']/div/table/tbody/tr[1]/td[2]")
    protected WebElement businessIdTable;

    @FindBy(id = "internal-businessid-create-application-no-results-button")
    protected WebElement createApplicationButtonStaff;

    @FindBy(id = "agent-login-actions-create")
    protected WebElement createApplicationButtonAgent;

    @FindBy(id = "report-block")
    protected WebElement reportButton;

    @FindBy(id = "agent-login-select-searchBy")
    protected WebElement selectSearchAgent;

    @FindBy(id = "search-dropdown-field")
    protected WebElement selectSearchStaff;

    @FindBy(id = "agent-login-select-searchBy")
    protected WebElement selectSearchDropDownAgent;

    @FindBy(id = "mat-select-1")
    protected WebElement selectSearchYear;

    @FindBy(id = "agent-login-businessId")
    protected WebElement selectBusinessIdAgent;

    @FindBy(xpath = "//*[@id=\"mat-option-3\"]/span")
    protected WebElement selectYear2020;

    @FindBy(id = "agent-login-actions-more")
    protected WebElement moreActionsButton;

    @FindBy(xpath = "(//td[@class='mat-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[1]")
    protected WebElement NAndPEnquiryDetailsTableStaff;

    @FindBy(xpath = "//*[text()=' Delete Application ']")
    protected WebElement deleteApplicationButton;

    @FindBy(id = "confimation-modal-confirm-button")
    protected WebElement deleteApplicationButtonConfirm;

    @FindBy(xpath = "//button[text()=' Manage Documents ']")
    protected WebElement viewDocuments;

    @FindBy(id = "confimation-modal-cancel-button")
    protected WebElement deleteApplicationButtonCancel;

    @FindBy(id = "agent-login-actions-view0")
    protected WebElement viewApplicationButton;

    @FindBy(id = "agent-div-mat-card-title")
    protected WebElement viewApplicationTitle;

    @FindBy(xpath = "//*[@id=\"mat-select-2\"]/div")
    protected WebElement selectItemsPerPage;

    @FindBy(xpath = "//*[@id=\"mat-option-7\"]/span")
    protected WebElement select50ItemsPerPage;

    @FindBy(xpath = "//*[@id=\"panel-content\"]/div/mat-paginator/div/div/div[2]/button[3]/span/svg")
    protected WebElement nextpageButton;

    @FindBy(id = "search-button-field")
    protected WebElement searchbutton;

    @FindBy(xpath = "//div[text()[normalize-space()='Status']]")
    protected WebElement statusLabel;

    @FindBy(xpath = "//*[text()='Business Id']")
    protected WebElement businessIdLabel;

    @FindBy(xpath = "//*[text()='Scheme Year ']")
    protected WebElement schemeYearLabel;

    @FindBy(xpath = "//*[text()='Submitted Date ']")
    protected WebElement submittedDateLabel;

    @FindBy(xpath = "//*[text()='Status Date ']")
    protected WebElement statusDateLabel;

    @FindBy(xpath = "//*[text()='Last eNMP']")
    protected WebElement lastEnmpLabel;

    @FindBy(xpath = "//*[text()='Previous Accounts']")
    protected WebElement previousAccountsLabel;

    @FindBy(xpath = "//*[text()='Last Soils']")
    protected WebElement lastSoilsLabel;

    @FindBy(xpath = "//*[text()='NpH']")
    protected WebElement npHLabel;

    @FindBy(xpath = "(//th[text()='Actions'])[2]")
    protected WebElement actionsLabel;

    @FindBy(xpath = "//span[text()='Document Manager']")
    protected WebElement documentManagerTitle;

    @FindBy(xpath = "//span[contains(text(),'Retrieving Applications')]")
    protected WebElement retrievingApplications;

    @FindBy(id = "internal-login-approved-application-list")
    protected WebElement approvedTab;

    @FindBy(id = "internal-login-submit-application-list")
    protected WebElement submittedTab;

    @FindBy(id = "agent-login-actions-np0")
    protected WebElement npEnquiryDetails;

    @FindBy(id = " view-document-manager-agent-business-id-search-button-0")
    protected WebElement manageDocuments;


    public void clickCreateApplicationByBusinessIdSearch(String herdno) {
        throw new NotImplementedException("Implement in child");
    }

    public void validateApplicationDetails() {
        ssoPopupPageObject = PageFactory.initElements(webDriver, SsoPopupPage.class);
        ssoPopupPageObject.clickPopupClose();
        assertThat(BrowserUtils.getText(webDriver, advancedSearchText) != null);
    }

    public void validateExistingApplicationDetails() {

        Assert.assertTrue(businessIdTable.isDisplayed());
        // TODO: Fix this later
        // assertThat(BrowserUtils.getText(webDriver, businessIdTable) != null);

    }

    public void validateReportButton() {
        Assert.assertTrue(reportButton.isDisplayed());
        // TODO: Fix this later
        // assertThat(BrowserUtils.getText(webDriver, businessIdTable) != null);
    }

    public void validateCreateApplicationButton() {
        throw new NotImplementedException("Awaiting implementation");
    }

    private void clickApplicationRow(String herdno) {
        for (int i = 1; i < 51; i++) {
            if (i > 51) {
                BrowserUtils.waitAndClickElement(webDriver, nextpageButton);
                i = 1;
            }
            value = webDriver.findElement(By.xpath("//*[@id=\"panel-content\"]/div/table/tbody/tr[" + i + "]/td[1]"))
                .getText();
            log.warn("value = " + value);
            log.warn("i = " + i);

            if (value.equals(herdno)) {
                log.warn("element found  value is " + value);
                log.warn("element found  herdno is " + herdno);
                rowValue = i;
                log.warn("rowValue= " + rowValue);

                // TODO:
                // WebElement xpath= "//*[@id=\"panel-content\"]/div/table/tbody/tr[" + rowValue
                // +
                // "]/td[5]/button/span/mat-icon";

                WebElement element = webDriver.findElement(By.xpath(
                    "//*[@id=\"panel-content\"]/div/table/tbody/tr[" + rowValue + "]/td[5]/button/span/mat-icon"));
                BrowserUtils.waitAndClickElement(webDriver, element);
                break;
                // TODO:
                // webDriver.findElement(
                // By.xpath(
                // "//*[@id=\"panel-content\"]/div/table/tbody/tr[" + rowValue +
                // "]/td[5]/button/span/mat-icon"));
                // .click();
                // return xpath;

            }

        }
    }

    public void clickCreateApplicationSchemeYearSearch(String herdno) throws Exception {
        // TODO: added 2020 year when required
        // BrowserUtils.waitAndClickElement(webDriver, selectSearchYear);
        // BrowserUtils.waitAndClickElement(webDriver, selectYear2020);
        ssoPopupPageObject = PageFactory.initElements(webDriver, SsoPopupPage.class);
        ssoPopupPageObject.clickPopupClose();
        BrowserUtils.waitAndClickElement(webDriver, searchbutton);
        // TODO: fix flow of year search
        // BrowserUtils.waitForAngularToLoad(webDriver);
        // BrowserUtils.waitAndClickElement(webDriver, searchInputText);
        // data should be in properties
        // BrowserUtils.sendKeysToWebElement(webDriver, searchInputText, herdno);

        try {
            BrowserUtils.waitAndClickElement(webDriver, selectItemsPerPage);
            BrowserUtils.waitAndClickElement(webDriver, select50ItemsPerPage);
        } catch (Exception e) {
            log.warn("50 pages option not there");
        }

        clickApplicationRow(herdno);
        // TODO: fix flow of year search
        // BrowserUtils.waitAndClickElement(webDriver, xpath);
        // BrowserUtils.waitForAngularToLoad(webDriver);
        /// BrowserUtils.waitUntilAngularReady(webDriver);
        // BrowserUtils.waitUntilAngular5Ready(webDriver);
    }

    public void clickOnMenuButton() {
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, menuButton);
    }

    public void clickNAndPEnquiryDetailsTableSearch(String herdno) {
        throw new NotImplementedException("Implement in child");
    }

    public void enterBusinessIdAndSearch(String record) {
        throw new NotImplementedException("Implement in child");
    }

    public void searchBySchemeYear(Integer year) {
        throw new NotImplementedException("Implement in child");
    }

    public void assertConfirmAndCancelAndViewButtonOptionsExist() {
        throw new NotImplementedException("Implement in child");
    }

    public void clickDeleteApplicationOption() {
        throw new NotImplementedException("Implement in child");
    }

    public void clickDeleteCancelApplicationOption() {
        throw new NotImplementedException("Implement in child");
    }

    public void clickManageDocumentOnAgentSearch(String record) {
        throw new NotImplementedException("Implement in child");
    }

    public void clickManageDocuments(){
        throw new NotImplementedException("Implement in child");
    }

    public void clickManageDocumentsSearchStaff(){
        throw new NotImplementedException("Implement in child");
    }

    public void searchByBusinessIdAndAssertOptionsAreDisplayed() {
        BrowserUtils.waitUntilWebElementIsInvisible(webDriver, retrievingApplications);
        Assert.assertTrue(statusLabel.isDisplayed());
        Assert.assertTrue(businessIdLabel.isDisplayed());
        Assert.assertTrue(schemeYearLabel.isDisplayed());
        Assert.assertTrue(submittedDateLabel.isDisplayed());
        Assert.assertTrue(statusDateLabel.isDisplayed());
        Assert.assertTrue(lastEnmpLabel.isDisplayed());
        Assert.assertTrue(previousAccountsLabel.isDisplayed());
        Assert.assertTrue(lastSoilsLabel.isDisplayed());
        Assert.assertTrue(npHLabel.isDisplayed());
        Assert.assertTrue(actionsLabel.isDisplayed());
    }

    public void searchBySchemeYearDefaultLandingOptionsAreDisplayed(){
        throw new NotImplementedException("Implement in child");
    }

    public void assertAllColumnOptionsAreDisplayedForDraftHeading() {
        throw new NotImplementedException("Implement in child");
    }

    public void assertAllColumnOptionsAreDisplayedForSubmittedHeading() {
        throw new NotImplementedException("Implement in child");
    }

    public void assertAllColumnOptionsAreDisplayedForApprovedHeading() {
        throw new NotImplementedException("Implement in child");
    }

    public void clickViewApplications() {
        throw new NotImplementedException("Not implemented in child");
    }

    public void waitForDocumentManagerTitle() {
        BrowserUtils.waitVisibility(webDriver, documentManagerTitle);
    }

    public boolean assertCreateApplictionButtonIsNotAvailable(){
        throw new NotImplementedException("Not implements in child");
    }

    public boolean assertCreateApplictionButtonForNoApplications(){
        throw new NotImplementedException("Not implements in child");
    }

    public void clickMoreActionsButton() {
        throw new NotImplementedException("Not implemented in child");
    }

    public void verifyActionsAvailableWhenSchemeIsClosed(){
        throw new NotImplementedException("Not implemented in child");
    }

    public boolean verifyActionsNotAvailableWhenSchemeIsClosed(){
        throw new NotImplementedException("Not implemented in child");
    }

    public void verifyActionsAvailableWhenSchemeIsOpen(){
        throw new NotImplementedException("Not implemented in child");
    }

    public boolean verifyActionsNotAvailableWhenSchemeIsOpen(){
        throw new NotImplementedException("Not implemented in child");
    }

    public void refreshPageBeforeSearching(){
        BrowserUtils.refreshPage(webDriver);
    }

    public void verifyActionsAvailableOnDraftTab(){throw new NotImplementedException("Not implemented in child");}
}
