package ie.gov.agriculture.agschemes.stepdefinitions.nitrates;

import ie.gov.agriculture.agschemes.commons.AllowedRoles;
import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.junit.Assert;

public class NitratesLandingPageSteps extends DriverFactory {

    public NitratesLandingPageSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @Then("user is logged into nitrates landing page")
    public void userIsLoggedIntoNitratesLandingPage() {
        nitratesLandingPage.validateApplicationDetails();
    }

    @And("^user searches for existing application$")
    public void userSearchesForExistingApplication() {
        nitratesLandingPage.enterBusinessIdAndSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("^user search by scheme year (\\d+)$")
    public void userSearchApplicationBySchemeYear(Integer year){
        nitratesLandingPage.searchBySchemeYear(year);
    }

    @And("^verify search by scheme year headings$")
    public void verifyHeadingSearchBySchemeYear(){
        nitratesLandingPage.searchBySchemeYearDefaultLandingOptionsAreDisplayed();
    }

    @And("^assert confirm and cancel and view button options exist$")
    public void assertConfirmAndCancelAndViewButtonOptionsExist() {
        nitratesLandingPage.assertConfirmAndCancelAndViewButtonOptionsExist();
    }

    @And("^user deletes application on ui$")
    public void userDeletesApplication() {
        nitratesLandingPage.clickDeleteApplicationOption();
    }

    @And("^user click deletes and then click cancels$")
    public void userCancelsApplication() {
        nitratesLandingPage.clickDeleteCancelApplicationOption();
    }

    @And("user creates new application")
    public void userCreatesNewApplication() {
        nitratesLandingPage.clickCreateApplicationByBusinessIdSearch(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @When("user searches by business id")
    public void userSearchesByBusinessId() {
        nitratesLandingPage.enterBusinessIdAndSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @Then("assert all column options are displayed on the table")
    public void assertAllColumnOptionsAreDisplayedOnTheTable() {
        nitratesLandingPage.searchByBusinessIdAndAssertOptionsAreDisplayed();
    }

    @Then("assert all column options are displayed for draft heading")
    public void assertAllColumnOptionsAreDisplayedForDraftHeading() {
        nitratesLandingPage.assertAllColumnOptionsAreDisplayedForDraftHeading();
    }

    @Then("assert all column options are displayed for approved heading")
    public void assertAllColumnOptionsAreDisplayedForApprovedHeading() {
        nitratesLandingPage.assertAllColumnOptionsAreDisplayedForApprovedHeading();
    }

    @Then("assert all column options are displayed for submitted heading")
    public void assertAllColumnOptionsAreDisplayedForSubmittedHeading() {
        nitratesLandingPage.assertAllColumnOptionsAreDisplayedForSubmittedHeading();
    }

    @Then("assert new application button is not available when scheme is closed")
    public void assertNewApplicationButtonIsNotAvailable() {
        Assert.assertFalse("Create Application Button is available",nitratesLandingPage.assertCreateApplictionButtonIsNotAvailable());
    }

    @Then("^assert create application not available for No Applications$")
    public void assertCreateApplicationButtonIsNotAvailableForNoApplications() {
        Assert.assertFalse("Create Application Button is available",nitratesLandingPage.assertCreateApplictionButtonForNoApplications());
    }

    @Then("^assert create application available for No Applications$")
    public void assertCreateApplicationButtonIsAvailableForNoApplications() {
        Assert.assertTrue("Create Application Button is available",nitratesLandingPage.assertCreateApplictionButtonForNoApplications());
    }

    @And("user creates and saves application as draft and selects manage documents")
    public void userCreatesAndSavesApplicationAsDraftAndSelectsManageDocuments() throws Throwable {
        nitratesLandingPage.clickCreateApplicationByBusinessIdSearch(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesApplicationFormPage
            .createApplicationEnterValidUserInputAndClickSaveAsDraft(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesLandingPage
            .clickManageDocumentOnAgentSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("search and selects manage documents")
    public void searchAndSelectsManageDocuments() {
        nitratesLandingPage
            .enterBusinessIdAndSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesLandingPage
            .clickManageDocumentOnAgentSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("search and selects manage documents staff")
    public void searchAndSelectsManageDocumentsStaff() {
        nitratesLandingPage
                .enterBusinessIdAndSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesLandingPage
                .clickManageDocumentsSearchStaff();
    }

    @And("user selects manage documents staff")
    public void userSelectsManageDocumentsStaff() {
        nitratesLandingPage
                .clickManageDocuments();
    }

    @And("user creates and saves application as draft and selects n and p equiry details")
    public void userCreatesAndSavesApplicationAsDraftAndSelectsNAndPEnquiryDetails() throws Throwable {
        nitratesLandingPage.clickCreateApplicationByBusinessIdSearch(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesApplicationFormPage
            .createApplicationEnterValidUserInputAndClickSaveAsDraft(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesLandingPage
            .clickNAndPEnquiryDetailsTableSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user creates new application with no data")
    public void userCreatesNewApplicationWithNoData() {
        // TODO: database not stable will enable this later
        // nitratesLandingPage.clickCreateApplicationByBusinessIdSearch(TestDataHolder
        // .getTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result"));
        nitratesLandingPage
            .clickCreateApplicationByBusinessIdSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user creates new application with some data")
    public void userCreatesNewApplicationWithSomeData() {
        // TODO: database not stable will enable this later
        // nitratesLandingPage.clickCreateApplicationByBusinessIdSearchForStaff(TestDataHolder.getTestDataRecord("numbersForTheAnimals_Result"));
        nitratesLandingPage
            .clickCreateApplicationByBusinessIdSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @Then("assert customer details are present")
    public void assertCustomerDetailsArePresent() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
            case AllowedRoles.ROLE_STAFF:
            case AllowedRoles.ROLE_AGENT:
                nitratesApplicationFormPage.getCustomerDetails();
            break;
            case AllowedRoles.ROLE_INDIVIDUAL:
            // TODO: IMPLEMENT LATER
            // nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForAgent(
            // ConstantsProvider.getHERDNO1AGENT(), ConstantsProvider.getHERDYEAR(),
            // "Application Draft");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @And("user creates new application with some data and save as draft")
    public void userCreatesNewApplicationWithSomeDataAndSaveAsDraft() throws Throwable {
        // TODO: database not stable will enable this later
        // nitratesLandingPage.clickCreateApplicationByBusinessIdSearchForStaff(TestDataHolder.getTestDataRecord("numbersForTheAnimals_Result"));
        nitratesLandingPage
            .clickCreateApplicationByBusinessIdSearch(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        nitratesApplicationFormPage.createApplicationEnterValidUserInputAndClickSaveAsDraft(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user views application")
    public void userViewsApplication() {
        nitratesLandingPage.clickViewApplications();
    }

    @And("^user clicks on menu bar$")
    public void userclickOnMenuBar() {
        nitratesLandingPage.clickOnMenuButton();
    }

    @And("^assert existing applications are present$")
    public void assertExistingApplicationsArePresent() {
        nitratesLandingPage.validateExistingApplicationDetails();
    }

    @And("^assert create application button is present$")
    public void assertCreateApplicationButtonIsPresent() {
        nitratesLandingPage.validateExistingApplicationDetails();
    }

    @And("^assert report button is present$")
    public void assertReportButtonIsPresent() {
        nitratesLandingPage.validateReportButton();
    }

    @And("^upload document (Fertiliser Accounts|Farm Sketch|Soil Sample)$")
    public void uploadDocument(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        if(!ConstantsProvider.isSELENIUM_GRID_ON()){
        nitratesDocumentManagerPage.uploadDocumentToAccount(accountType);
        }
    }

    @And("^view document from document manager and enter comment (Fertiliser Accounts|Farm Sketch)$")
    public void viewDocumentFromDocumentManager(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        if(!ConstantsProvider.isSELENIUM_GRID_ON()) {
            nitratesDocumentManagerPage.viewDocumentFromDocumentManager(accountType);
        }
    }

    @And("^assert that edit document not available for (Fertiliser Accounts|Farm Sketch)$")
    public void assertEditDocumentNotAvailable(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        Assert.assertFalse(nitratesDocumentManagerPage.assertEditDocumentNotAvailable(accountType));
    }

    @And("^assert that edit document not possible for (Fertiliser Accounts|Farm Sketch)$")
    public void assertEditDocumentNotPossible(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        Assert.assertEquals(nitratesDocumentManagerPage.assertEditDocumentNotPossible(accountType),"This document cannot be edited");
    }

    @And("^assert that delete document not possible for (Fertiliser Accounts|Farm Sketch)$")
    public void assertdeleteDocumentNotPossible(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        Assert.assertEquals(nitratesDocumentManagerPage.assertDeleteDocumentNotPossible(accountType),"This Document cannot be deleted");
    }

    @And("^delete document and verify delete document pop up (Fertiliser Accounts|Farm Sketch|Soil Sample) (GDPR|Other)$")
    public void deleteDocumentandVerifyPopUp(String accountType, String reason) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        if(!ConstantsProvider.isSELENIUM_GRID_ON()) {
            nitratesDocumentManagerPage.deleteDocument(accountType, reason);
        }
    }

    @And("^cancel delete document (Fertiliser Accounts|Farm Sketch|Soil Sample)$")
    public void cancelDeleteDocument(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        if(!ConstantsProvider.isSELENIUM_GRID_ON()) {
            nitratesDocumentManagerPage.cancelDeleteDocument(accountType);
        }
    }

    @And("^try upload document without select date (Soil Sample)$")
    public void tryUploadDocument(String accountType) {
        nitratesLandingPage.waitForDocumentManagerTitle();
        nitratesDocumentManagerPage.tryUploadDocument(accountType);
    }

    @And("^verify warning message for account type (Soil Sample)$")
    public void verifyWarningMessage(String accountType) {
        nitratesDocumentManagerPage.verifyDateWarning(accountType);
    }

    @Then("^verify draft action options available when scheme is closed$")
    public void verifyDraftActionOptionAvailableWhenSchemeIsClosed(){
        nitratesLandingPage.verifyActionsAvailableWhenSchemeIsClosed();
    }

    @Then("^verify draft action options not available when scheme is closed$")
    public void verifyDraftActionOptionNotAvailableWhenSchemeIsClosed(){
        Assert.assertFalse(nitratesLandingPage.verifyActionsNotAvailableWhenSchemeIsClosed());
    }

    @Then("^verify draft action options available when scheme is open$")
    public void verifyDraftActionOptionAvailableWhenSchemeIsOpen(){
        nitratesLandingPage.verifyActionsAvailableWhenSchemeIsOpen();
    }

    @Then("^verify draft action options not available when scheme is open$")
    public void verifyDraftActionOptionNotAvailableWhenSchemeIsOpen(){
        Assert.assertFalse(nitratesLandingPage.verifyActionsNotAvailableWhenSchemeIsOpen());
    }

    @Then("^verify draft action options when search by year$")
    public void verifyDraftActionOptionWhenSearchBySchemeyear(){
        nitratesLandingPage.verifyActionsAvailableOnDraftTab();
    }


    @And("^refreshing page before searching business id$")
    public void refresh(){
        nitratesLandingPage.refreshPageBeforeSearching();
    }
}
