package ie.gov.agriculture.agschemes.databasequeries.nitrates.apn;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLException;

import ie.gov.agriculture.agschemes.databasequeries.IQuery;
import ie.gov.agriculture.agschemes.databasequeries.QueryBase;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class APNGrassLandPercentQuery extends QueryBase implements IQuery {

    public APNGrassLandPercentQuery(String herdNo, String year, String applicationStatus) {
        super(herdNo, year, applicationStatus);
        buildQuery();
    }

    @Override
    public void buildQuery() {
        query = "select APN_GRASS_LAND_PERCENT from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdNo + "' and  APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";
    }

    @Override
    public String runQuery() throws SQLException {
        // TODO: need to fix this to account for bps 2020 as well

        stringResult = db.executeQueryReturningString(query);

        log.warn("the APN_GRASS_LAND_PERCENT_query value is " + query);
        log.warn("the APN_GRASS_LAND_PERCENT_result value is " + stringResult);
        assertThat(stringResult).isNotEmpty();
        return stringResult;
    }

}
