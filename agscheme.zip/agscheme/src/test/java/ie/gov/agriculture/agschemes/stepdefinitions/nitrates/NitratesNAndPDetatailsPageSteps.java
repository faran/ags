package ie.gov.agriculture.agschemes.stepdefinitions.nitrates;

import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;

public class NitratesNAndPDetatailsPageSteps extends DriverFactory {

    public NitratesNAndPDetatailsPageSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @And("^user gets n and p enquiry details from ui$")
    public void userGetsNAndPEnquiryDetailsFromUi(){
        nitratesNAndPDetatailsPage.getNAndPEnquiryDetailsPhosphorus();
    }
}
