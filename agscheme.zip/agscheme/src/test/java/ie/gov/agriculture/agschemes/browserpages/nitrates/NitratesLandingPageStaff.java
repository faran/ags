package ie.gov.agriculture.agschemes.browserpages.nitrates;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.browserpages.sso.SsoPopupPage;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.extern.log4j.Log4j2;

import java.util.Objects;

@Log4j2
public class NitratesLandingPageStaff extends NitratesLandingPage {

    @FindBy(id = "internal-login-actions-np0")
    protected WebElement nAndPEnquiryDetailsStaff;

    @FindBy(xpath = "//span[@class='mat-option-text'][text()='Business Id']")
    protected WebElement selectBusinessIdStaff;

    @FindBy(xpath = "//span[@class='mat-option-text'][text()='Scheme Year']")
    protected WebElement selectSchemeYearStaff;

    @FindBy(id = "mat-input-0")
    protected WebElement searchInputTextStaff;

    @FindBy(id = "year-dropdown-field")
    protected WebElement yearDropDownField;

    @FindBy(xpath = "//mat-icon[text()='more_horiz']")
    protected WebElement moreActionsButtonStaff;

    @FindBy(xpath = "(//button[@mattooltip='More Actions'])[6]")
    protected WebElement moreActionsButtonDraftApplication;

    @FindBy(id = "staff-scheme-select-year")
    protected WebElement staffSchemeSelectYear;

    @FindBy(id = "staff-scheme-button-create")
    protected WebElement staffCreateApplicationButton;

    @FindBy(id = "staff-scheme-option-select-0")
    protected WebElement staffSchemeOption0;

    @FindBy(css = "[id*='internal-businessid-create-application']")
    protected WebElement createApplicationButtonStaff;

    @FindBy(id = "internal-login-actions-view0")
    protected WebElement viewApplicationButtonStaff;

    @FindBy(id = "internal-login-query-application-button")
    protected WebElement queryApplicationButtonStaff;

    @FindBy(id = "internal-login-actions-tracking0")
    protected WebElement applicationTrackingButtonStaff;

    @FindBy(id = "internal-login-actions-edit0")
    protected WebElement EditApplicationButtonStaff;

    @FindBy(id = "internal-businessid-create-application-no-results-button")
    protected WebElement newAppButton;

    @FindBy(id = "staff-create-mat-card-title")
    protected WebElement appFormTitle;

    @FindBy(xpath = "(//*[@class='mat-cell cdk-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[1]")
    private WebElement phosphorusRowOneStaff;

    @FindBy(id = "internal-login-actions-manage-documents0")
    protected WebElement manageDocument;

    @FindBy(xpath = "//td[normalize-space(text())='G1650784']/following-sibling::td[9]/button")
    protected WebElement moreActionsButtonStaffForTestCase1095;

    @FindBy(id = "internal-login-draft-application-list")
    protected WebElement draftTabHeading;

    @FindBy(id = "internal-login-submit-application-list")
    protected WebElement submitTabHeading;

    @FindBy(id = "internal-login-queried-application-list")
    protected WebElement queryTabHeading;

    @FindBy(id = "internal-login-approved-application-list")
    protected WebElement approvedTabHeading;

    @FindBy(id = "internal-login-rejected-application-list")
    protected WebElement rejectedTabHeading;

    @FindBy(id = "internal-login-withdrawn-application-list")
    protected WebElement withdrawnTabHeading;

    @FindBy(xpath = "//*[text()='Status Date ']")
    protected WebElement statusDateLabel;

    @FindBy(xpath = "//div[text()[normalize-space()='Last ENMP']]")
    protected WebElement lastEnmpLabel;

    @FindBy(xpath = "//div[text()[normalize-space()='Previous Accounts']]")
    protected WebElement previousAccountsLabel;

    @FindBy(xpath = "//div[text()[normalize-space()='Last Soils']]")
    protected WebElement lastSoilsLabel;

    @FindBy(xpath = "//div[text()[normalize-space()='NPH']]")
    protected WebElement nphLabel;

    @FindBy(xpath = "(//th[text()='Actions'])[1]")
    protected WebElement actionsLabel;

    @FindBy(id = "internal-draft-view-draft-button")
    protected WebElement draftViewApplicationYear;

    @FindBy(id = "internal-draft-view-NP-button")
    protected WebElement draftViewNPYear;

    @FindBy(id = "internal-draft-view-tracking-button")
    protected WebElement draftApplicationTrackingYear;

    @FindBy(id = "internal-draft-manage-documents-button")
    protected WebElement draftManageDocumentsYear;

    @FindBy(id = "internal-draft-edit-button")
    protected WebElement draftEditApplicationYear;

    @FindBy(id = "internal-draft-view-draft-button")
    protected WebElement draftViewApplicationId;

    @FindBy(id = "internal-draft-view-NP-button")
    protected WebElement draftViewNPId;

    @FindBy(id = "internal-draft-view-tracking-button")
    protected WebElement draftApplicationTrackingId;

    @FindBy(id = "internal-draft-manage-documents-button")
    protected WebElement draftManageDocumentsId;

    @FindBy(id = "internal-draft-edit-button")
    protected WebElement draftEditApplicationId;

    @FindBy(id = "internal-businessid-create-application-button")
    protected WebElement createApplicationButtonId;

    @FindBy(id = "internal-draft-more-actions-button")
    protected WebElement draftActionButtonYear;

    public NitratesLandingPageStaff(WebDriver webDriver) {
        super(webDriver);
    }

    @Override
    public void enterBusinessIdAndSearch(String herdNo) {
        searchByBusinessId(herdNo);
        BrowserUtils.waitVisibility(webDriver, newAppButton);
    }

    @Override
    public void searchBySchemeYear(Integer year){
        try {
            ssoPopupPageObject = PageFactory.initElements(webDriver, SsoPopupPage.class);
            ssoPopupPageObject.clickPopupClose();
        } catch (AssertionError e) {
            log.warn("close popup not there.. continue with test");
        }
        BrowserUtils.waitAndClickElement(webDriver, selectSearchStaff);
        BrowserUtils.waitAndClickElement(webDriver, selectSchemeYearStaff);
        BrowserUtils.waitAndClickElement(webDriver, yearDropDownField);
        BrowserUtils.waitAndClickElement(webDriver, Objects.requireNonNull(selectYear(year)));
        BrowserUtils.waitAndClickElement(webDriver, searchbutton);
    }

    private WebElement selectYear(Integer year){
        switch (year) {
            case 2021:
                return webDriver.findElement(By.id("year-dropdown-field-option-0"));
            case 2020:
                return webDriver.findElement(By.id("year-dropdown-field-option-1"));
            case 2019:
                return webDriver.findElement(By.id("year-dropdown-field-option-2"));
            case 2018:
                return webDriver.findElement(By.id("year-dropdown-field-option-3"));
            case 2017:
                return webDriver.findElement(By.id("year-dropdown-field-option-4"));
            default:
                log.error("Year not found");
                return null;
        }
    }
    /**Verification for outer table headings*/
    public void searchBySchemeYearDefaultLandingOptionsAreDisplayed(){
        BrowserUtils.waitUntilWebElementIsInvisible(webDriver, retrievingApplications);
        Assert.assertTrue(draftTabHeading.isDisplayed());
        Assert.assertTrue(submitTabHeading.isDisplayed());
        Assert.assertTrue(queryTabHeading.isDisplayed());
        Assert.assertTrue(approvedTabHeading.isDisplayed());
        Assert.assertTrue(rejectedTabHeading.isDisplayed());
        Assert.assertTrue(withdrawnTabHeading.isDisplayed());
    }

    public void assertAllColumnOptionsAreDisplayedForDraftHeading(){
        BrowserUtils.waitUntilWebElementIsInvisible(webDriver, retrievingApplications);
        Assert.assertTrue(businessIdLabel.isDisplayed());
        Assert.assertTrue(schemeYearLabel.isDisplayed());
        Assert.assertTrue(submittedDateLabel.isDisplayed());
        Assert.assertTrue(statusLabel.isDisplayed());
        Assert.assertTrue(statusDateLabel.isDisplayed());
        Assert.assertTrue(lastEnmpLabel.isDisplayed());
        Assert.assertTrue(previousAccountsLabel.isDisplayed());
        Assert.assertTrue(lastSoilsLabel.isDisplayed());
        Assert.assertTrue(nphLabel.isDisplayed());
        Assert.assertTrue(actionsLabel.isDisplayed());
    }

    public void assertAllColumnOptionsAreDisplayedForApprovedHeading(){
        BrowserUtils.waitAndClickElement(webDriver, approvedTab);
        assertAllColumnOptionsAreDisplayedForDraftHeading();
    }

    public void assertAllColumnOptionsAreDisplayedForSubmittedHeading(){
        BrowserUtils.waitAndClickElement(webDriver, submittedTab);
        assertAllColumnOptionsAreDisplayedForDraftHeading();
    }


    private void searchByBusinessId(String herdno) {
        try {
            ssoPopupPageObject = PageFactory.initElements(webDriver, SsoPopupPage.class);
            ssoPopupPageObject.clickPopupClose();
        } catch (AssertionError e) {
            log.warn("close popup not there.. continue with test");
        }
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, selectSearchStaff);
        BrowserUtils.waitAndClickElement(webDriver, selectBusinessIdStaff);
        BrowserUtils.waitAndClickElement(webDriver, searchInputTextStaff);
        BrowserUtils.sendKeysToWebElement(webDriver, searchInputTextStaff, herdno);
        BrowserUtils.waitAndClickElement(webDriver, searchbutton);
    }

    @Override
    public void clickCreateApplicationByBusinessIdSearch(String herdno) {
        searchByBusinessId(herdno);
        BrowserUtils.waitVisibility(webDriver, newAppButton);
        BrowserUtils.waitAndClickElement(webDriver, createApplicationButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffSchemeSelectYear);
        BrowserUtils.waitAndClickElement(webDriver, staffSchemeOption0);
        BrowserUtils.waitAndClickElement(webDriver, staffCreateApplicationButton);
        BrowserUtils.waitVisibility(webDriver, appFormTitle);
    }

    @Override
    public void clickNAndPEnquiryDetailsTableSearch(String herdno) {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, nAndPEnquiryDetailsStaff);
        BrowserUtils.waitVisibility(webDriver, phosphorusRowOneStaff);
    }

    @Override
    public void clickViewApplications() {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, viewApplicationButtonStaff);
        BrowserUtils.waitVisibility(webDriver, viewApplicationTitle);
    }

    @Override
    public void clickMoreActionsButton() {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
    }

    //Hard coding xpath since cant find any other xpath to click on more actions button
    @Override
    public void clickManageDocumentsSearchStaff() {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaffForTestCase1095);
        BrowserUtils.waitAndClickElement(webDriver, manageDocument);

    }

    @Override
    public void clickManageDocuments() {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, manageDocument);
    }

    /**These button only visible when you search by business id*/
    public void verifyActionsAvailableWhenSchemeIsOpen(){
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButtonDraftApplication);
        BrowserUtils.waitVisibility(webDriver, viewApplicationButtonStaff);
        Assert.assertTrue("View Application not displayed", viewApplicationButtonStaff.isDisplayed());
        Assert.assertTrue("NP Enquiry Application not displayed", nAndPEnquiryDetailsStaff.isDisplayed());
        Assert.assertTrue("Manage Application not displayed", manageDocument.isDisplayed());
        Assert.assertTrue("Edit Application not displayed", EditApplicationButtonStaff.isDisplayed());
        Assert.assertTrue("Application tracking not displayed", applicationTrackingButtonStaff.isDisplayed());
    }

    public boolean verifyActionsNotAvailableWhenSchemeIsOpen(){
        try {
            return queryApplicationButtonStaff.isDisplayed();
        } catch (NoSuchElementException e) {
            log.error("Element not found");
            return false;
        }
    }

    /**These button only visible when you search by year*/
    public void verifyActionsAvailableOnDraftTab(){
        BrowserUtils.waitAndClickElement(webDriver, draftTabHeading);
        BrowserUtils.waitAndClickElement(webDriver, draftActionButtonYear);
        //BrowserUtils.waitVisibility(webDriver, viewApplicationButtonStaff);
        Assert.assertTrue("View Application not displayed", draftViewApplicationYear.isDisplayed());
        Assert.assertTrue("NP Enquiry Application not displayed", draftViewNPYear.isDisplayed());
        Assert.assertTrue("Manage Application not displayed", draftManageDocumentsYear.isDisplayed());
        Assert.assertTrue("Edit Application not displayed", draftEditApplicationYear.isDisplayed());
        Assert.assertTrue("Application tracking not displayed", draftApplicationTrackingYear.isDisplayed());
    }

    //click on draft tab
    //click action button
    //verify menu
}
