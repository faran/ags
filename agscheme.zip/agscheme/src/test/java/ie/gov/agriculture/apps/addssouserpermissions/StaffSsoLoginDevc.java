package ie.gov.agriculture.apps.addssouserpermissions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class StaffSsoLoginDevc extends TestBase {

    String linkText = "";

    @FindBy(how = How.XPATH, using = ("//input[@placeholder='Enter your username']"))
    private WebElement enterUsername;
    @FindBy(how = How.XPATH, using = ("//input[@placeholder='Enter your password']"))
    private WebElement enterPassword;

    @FindBy(how = How.XPATH, using = ("//div[@class='mat-checkbox-inner-container']"))
    private WebElement dataCheckBox;

    @FindBy(how = How.XPATH, using = ("//span[contains(text(),'Logon')]"))
    private WebElement logONButton;

    @FindBy(how = How.CSS, using = (".mat-paginator-navigation-next"))
    private WebElement paginatorNextButton;

    @FindBy(partialLinkText = "Organic Farming Scheme")
    public WebElement ofsLink;
    @FindBy(partialLinkText = "Organic Farming System")
    public WebElement rdfsLink;
    @FindBy(partialLinkText = "GLAS")
    public WebElement glasLink;
    @FindBy(partialLinkText = "SSO Administration")
    public WebElement ssoAdmin;
    @FindBy(partialLinkText = "Authorisations")
    public WebElement authorisationsLink;

    // Methods

    public void setUsername(String strUserName) {
        enterUsername.sendKeys(strUserName);
    }

    public void setPassword(String strPassword) {
        enterPassword.sendKeys(strPassword);
    }

    public void clickDataCheckbox() {
        dataCheckBox.click();
    }

    public void clickLogonButton() {
        logONButton.click();
    }

    public void loginToSsoDevc(String strUserName, String strPassword) {
        driver.get(TestConfig.setSsoUrl("staff"));
        String env = TestConfig.getEnvironment();
        if (env.toLowerCase() != "prelive") {

            // Fill user name
            setUsername(strUserName);
            // Fill password
            setPassword(strPassword);
            // Click Login button
            clickDataCheckbox();
            // Click Login button

            clickLogonButton();

            // if Environment is prelive, use old SSO page
        } else {
            StaffSsoLogin staffSsoLogin = PageFactory.initElements(driver, StaffSsoLogin.class);
            staffSsoLogin.loginToSso(strUserName, strPassword);
        }
    }

    public void clickLinkWithText(String applicationLinkText) throws InterruptedException {
        Thread.sleep(500);
        System.out.println("searching for link text : " + applicationLinkText);
        List<WebElement> listOfLinksMatchingString = driver.findElements(By.partialLinkText(applicationLinkText));

        System.out.println("Number of links matching String = " + listOfLinksMatchingString.size());
        if (listOfLinksMatchingString.size() > 0) {
            driver.findElement(By.partialLinkText(applicationLinkText)).click();
        } else {
            for (int i = 0; i < 5; i++) {

                System.out.println("Iteration " + i + " , paginator displayed : " + paginatorNextButton.isDisplayed());
                if (paginatorNextButton.isEnabled()) {
                    paginatorNextButton.click();
                    Thread.sleep(500);
                    listOfLinksMatchingString = driver.findElements(By.partialLinkText(applicationLinkText));

                    if (listOfLinksMatchingString.size() > 0) {
                        driver.findElement(By.partialLinkText(applicationLinkText)).click();
                        break;
                    }
                }
            }

            System.out.println("could not find Application Link text on first 5 pages of SSO: " + applicationLinkText);

        }

    }
}
