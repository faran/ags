package ie.gov.agriculture.agschemes.databasequeries.nitrates.apn;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLException;

import ie.gov.agriculture.agschemes.databasequeries.IQuery;
import ie.gov.agriculture.agschemes.databasequeries.QueryBase;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class APNNetAreaOfHoldingQuery extends QueryBase implements IQuery {

    public APNNetAreaOfHoldingQuery(String herdNo, String year, String applicationStatus) {
        super(herdNo, year, applicationStatus);
        buildQuery();
    }

    @Override
    public void buildQuery() {
        // TODO: need to fix this to account for bps 2020 as well
        query = "select APN_NET_AREA_OF_HOLDING from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";
        log.info("the APN_NET_AREA_OF_HOLDING_query value is " + query);

    }

    @Override
    public String runQuery() throws SQLException {
        stringResult = db.executeQueryReturningString(query);
        log.info("the APN_NET_AREA_OF_HOLDING_result value is " + stringResult);
        assertThat(stringResult).isNotEmpty();
        return stringResult;
    }

}
