package ie.gov.agriculture.agschemes.browserpages.ofs;

import java.io.File;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class OfsLandingPage {

    private final WebDriver webDriver;

    @FindBy(xpath = "//button/span[contains(text(),'Close')]")
    private WebElement closeButton;

    @FindBy(xpath = "//span[contains(text(),'Organic Farming Scheme')]")
    private WebElement IsAtOfs;

    @FindBy(xpath = "//button//span[contains(text(),'Menu')]")
    private WebElement menuButton;

    @FindBy(id = "herdNo")
    private WebElement herdSearchInput;

    @FindBy(xpath = "//button/span[contains(text(),'Search')]")
    private WebElement searchButton;

    @FindBy(id = "report-url-block")
    private WebElement reportButton;

    @FindBy(id = "genericHolder:layoutBody:reportSearchScheme")
    private WebElement schemeSelect;

    @FindBy(id = "genericHolder:layoutBody:reportSearchGroup")
    private WebElement reportGroupDrop;

    @FindBy(id = "genericHolder:layoutBody:reportSearch")
    private WebElement reportDrop;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:0:reportParameterDropDown")
    private WebElement scheme2;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:1:reportParameterDropDown")
    private WebElement applicationTypeDrop;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:2:reportParameterDropDown")
    private WebElement schemeYearDrop;

    @FindBy(id = "genericHolder:layoutBody:reportParameterIterator:3:reportParameterDropDown")
    private WebElement applicationStatusDrop;

    @FindBy(id = "genericHolder:layoutBody:validateButton")
    private WebElement validateButton;

    @FindBy(id = "genericHolder:layoutBody:showReportButton")
    private WebElement showReportButton;

    @FindBy(xpath = "/html/body/rdfs-root/div/rdfs-ofs-application/mat-sidenav-container/mat-sidenav-content/div/rdfs-search-application/rdfs-search-application-legacy/div/div/rdfs-panel/mat-card/mat-card-content/div/div/div/div[2]/select")
    private WebElement dropDownOfs;

    @FindBy(xpath = "/html/body/rdfs-root/div/rdfs-ofs-application/mat-sidenav-container/mat-sidenav-content/div/rdfs-search-application/rdfs-search-application-legacy/div/div/rdfs-panel/mat-card/mat-card-content/div/div/div/div[3]/button\n")
    private WebElement newApplicationButton;

    @FindBy(id = "confimation-modal-confirm-button")
    private WebElement confirmSchemeButton;

    @FindBy(xpath = "//div[1]/rdfs-panel/mat-card/mat-card-content/div/form//div[2]/mat-checkbox/label/div")
    private List<WebElement> TAndCCheckboxes;

    @FindBy(xpath = "//*[@id=\"mat-checkbox-54\"]/label/div")
    private WebElement TAndCButton1;

    @FindBy(xpath = "//*[@id=\"mat-checkbox-55\"]/label/div")
    private WebElement TAndCButton2;

    @FindBy(xpath = "//*[@id=\"mat-checkbox-56\"]/label/div")
    private WebElement TAndCButton3;

    private void switchWindowFocus() {
        Set<String> handles = webDriver.getWindowHandles();
        Iterator<String> handlesIterator = handles.iterator();
        while (handlesIterator.hasNext()) {
            String window = handlesIterator.next();
            webDriver.switchTo().window(window);
        }
    }

    public void clickCloseButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, closeButton);
    }

    public void clickMenuButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, menuButton);
    }

    public void clickReportButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, reportButton);
        switchWindowFocus();
    }

    public void selectScheme(String scheme) {
        Select select = new Select(schemeSelect);
        select.selectByVisibleText(scheme);
    }

    public void selectHerdNoSearch(String herdNo) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, herdSearchInput);
        BrowserUtils.sendKeysToWebElement(webDriver, herdSearchInput, herdNo);
    }

    public void clickSearchButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, searchButton);
    }

    public void selectSchemeAgain(String scheme) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, scheme2);
        Select select = new Select(scheme2);
        select.selectByVisibleText(scheme);
    }

    public void selectReportGroup(String group) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, reportGroupDrop);
        Select select = new Select(reportGroupDrop);
        select.selectByVisibleText(group);
    }

    public void selectReport(String report) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, reportDrop);
        Select select = new Select(reportDrop);
        select.selectByVisibleText(report);
    }

    public void selectApplicationType(String type) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, applicationTypeDrop);
        Select select = new Select(applicationTypeDrop);
        select.selectByVisibleText(type);
    }

    public void selectSchemeYear(String year) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, schemeYearDrop);
        Select select = new Select(schemeYearDrop);
        select.selectByVisibleText(year);
    }

    public void selectApplicationStatus(String status) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, applicationStatusDrop);
        Select select = new Select(applicationStatusDrop);
        select.selectByVisibleText(status);
    }

    public void clickValidateButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitUntilWebElementClickable(webDriver, validateButton);
        BrowserUtils.waitUntilWebElementIsVisible(webDriver, validateButton);
        BrowserUtils.waitAndClickElement(webDriver, validateButton);
    }

    public void clickShowReportButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, showReportButton);
    }

    public boolean fileExist() {
        // TODO: Move this method to shared to utility folder
        // TODO: Parameterise hardcoded pathname
        String pathname = "C:/Users/Conor.Kane/Downloads/OFS 3 Application Status.xls";
        File path = new File(pathname);
        boolean exists = path.exists();
        // System.out.print("File exists" + exists);
        if (path.delete()) {
            System.out.println("Deleted the folder: " + path.getName());
        } else {
            System.out.println("Failed to delete the folder.");
        }
        return exists;
    }

    public void selectDropDown(String scheme) {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, dropDownOfs);
        Select select = new Select(dropDownOfs);
        select.selectByVisibleText(scheme);
    }

    public void clickNewApplicationButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, newApplicationButton);
    }

    public void clickConfirmSchemeButton() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, confirmSchemeButton);
    }

    public void acceptTAndCs() {
        BrowserUtils.waitForAngular5Load(webDriver);
        for (WebElement checkbox : TAndCCheckboxes) {
            checkbox.click();
        }

    }

}
