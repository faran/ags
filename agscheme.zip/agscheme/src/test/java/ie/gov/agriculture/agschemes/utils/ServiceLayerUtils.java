package ie.gov.agriculture.agschemes.utils;

import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import ie.gov.agriculture.agschemes.commons.AllowedRoles;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.restassured.RestAssured;
import io.restassured.config.EncoderConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.http.Cookie;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.pojo.APIDataBuild;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.*;

public class ServiceLayerUtils {

    protected RequestSpecification reqSpec;
    protected ResponseSpecification respSpec;
    protected Response accessTokenResponse;
    protected Response response;
    protected String accessToken;
    protected String tokenType;
    protected String baseUrl;
    protected APIDataBuild apiDataBuild;
    private static Cookie cookie_SSO_SESSIONID;
    private static Cookie cookie_DAFSSO;
    APIResources apiResources;
    String index0;
    String index1;
    String index2;

    /*********************************************************************************************
     * For setting the BASE URL and creating API Logs
     *********************************************************************************************/
    public RequestSpecification requestSpecification() throws FileNotFoundException {
        //String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        //PrintStream printStream = new PrintStream("APILogs"+timeStamp+".txt");
        if(TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST).equals("agent")) {
            reqSpec = new RequestSpecBuilder().setBaseUri(TestDataHolder.getTestDataRecord("BASE_URL"))
                    //.addFilter(RequestLoggingFilter.logRequestTo(printStream))
                    //.addFilter(ResponseLoggingFilter.logResponseTo(printStream))
                    .addCookie(getCookieForAgent())
                    .setContentType(ContentType.JSON)
                    .build();
        }
        if(TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST).equals("staff")) {
            reqSpec = new RequestSpecBuilder().setBaseUri(TestDataHolder.getTestDataRecord("BASE_URL"))
                    //.addFilter(RequestLoggingFilter.logRequestTo(printStream))
                    //.addFilter(ResponseLoggingFilter.logResponseTo(printStream))
                    .addCookie(getCookieForStaff())
                    .setContentType(ContentType.JSON)
                    .build();
        }
        return reqSpec;
    }

    /*********************************************************************************************
     * ResponseSpecification
     *********************************************************************************************/
    public ResponseSpecification responseSpecification(){
        return respSpec = new ResponseSpecBuilder().build();
    }

    /*********************************************************************************************
     * Getting a value from from JSON Body
     *********************************************************************************************/

    public String getJsonPath(Response response, String key) {
        String resp = response.asString();
        JsonPath js = new JsonPath(resp);
        return js.get(key).toString();
    }

    private Cookie pacResponseAgentOnly(){
        apiResources = new APIResources();
        //Get PAC
        response = RestAssured
                .given().log().all()
                .contentType(ContentType.JSON)
                .relaxedHTTPSValidation()
                .get(apiResources.getServiceResource("SSO_GET_PAC_API"))
                .then().log().all().extract().response();

        cookie_SSO_SESSIONID = response.getDetailedCookie("SSO_SESSIONID");
        //Parse PAC digits
        List<String> jsonresponse = response.jsonPath().getList("$");
        index0 = String.valueOf(jsonresponse.get(0));
        index1 = String.valueOf(jsonresponse.get(1));
        index2 = String.valueOf(jsonresponse.get(2));

        return cookie_SSO_SESSIONID;
    }

    /**This needs to be seperate method since agent takes in PAC*/
    private Cookie getAuthReponseAgentOnly(){

        response = RestAssured.given()
                .config(RestAssuredConfig.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                .accept("application/json, text/plain, */*")
                .cookie(pacResponseAgentOnly())
                .formParam("username", getUser())
                .formParam("password", "@c3ntst678!!:"+index0+"-1,"+index1+"-1,"+index2+"-1").relaxedHTTPSValidation()//required for execution through Bamboo - unable to add trusted certificate to Java JDK cacerts
                .when().log().all()
                .post(setUserType())
                .then().log().all().statusCode(200).extract().response();

        return cookie_SSO_SESSIONID = response.getDetailedCookie("SSO_SESSIONID");
    }

    /**This needs to be seperate method since staff dont takes in PAC*/
    private Cookie getAuthReponseStaffOnly(){
        Response authRepsonse = RestAssured.given()
                .config(RestAssuredConfig.config().encoderConfig(EncoderConfig.encoderConfig().appendDefaultContentCharsetToContentTypeIfUndefined(false)))
                .accept("application/json, text/plain, */*")
                //.cookie(cookie_SSO_SESSIONID)
                .formParam("username", getUser())
                .formParam("password", "@c3ntst678!!").relaxedHTTPSValidation()//required for execution through Bamboo - unable to add trusted certificate to Java JDK cacerts
                .when().log().all()
                .post(setUserType())
                .then().log().all().statusCode(200).extract().response();

        return cookie_SSO_SESSIONID = authRepsonse.getDetailedCookie("SSO_SESSIONID");
    }

    //We need DAFSSO cookie in order to hit to any endpoint
    private Cookie getCookieDAFSSO(Cookie cookie) {

        //Login Gives you userid
        response = RestAssured.given().contentType("application/json")
                .relaxedHTTPSValidation()
                .accept("application/json, text/plain, */*")
                .cookie(cookie)
                .when().log().all()
                .get(apiResources.getServiceResource("SSO_LOGIN"))
                .then().log().all().statusCode(200).extract().response();

        Integer userId = response.jsonPath().get("userid");

        response = RestAssured.given().contentType("application/json")
                .relaxedHTTPSValidation()
                .accept("application/json, text/plain, */*")
                .redirects().follow(false) //required for redirect issue only present in rest assured - UI and Postman were smart enough to retrieve the cookie
                .cookie(cookie_SSO_SESSIONID)
                .when().log().all()
                .get(apiResources.getServiceResource("SSO_GET_COOKIE")+"/"+userId)
                .then().log().all().statusCode(200).extract().response();

        Integer appId = response.jsonPath().get("[0].id");

        return cookie_DAFSSO = RestAssured.given().contentType("application/json")
                .relaxedHTTPSValidation()
                .accept("application/json, text/plain, */*")
                .redirects().follow(false) //required for redirect issue only present in rest assured - UI and Postman were smart enough to retrieve the cookie
                .cookie(cookie_SSO_SESSIONID)
                .when().log().all()
                .get(apiResources.getServiceResource("SSO_GET_COOKIE")+"/"+userId+"/"+appId)
                .then().log().all().statusCode(302).extract().response().getDetailedCookie("DAFSSO");
    }

    public Cookie getCookieForAgent(){
        return getCookieDAFSSO(getAuthReponseAgentOnly());
    }

    public Cookie getCookieForStaff(){
        return getCookieDAFSSO(getAuthReponseStaffOnly());
    }

    protected String setBaseUrl(String API){
        switch (API){
            case "AgFoods":
                baseUrl = ConstantsProvider.getBASE_URL_AG_FOODS();
                break;
            case "AgApps":
                baseUrl = ConstantsProvider.getBASE_URL_AG_APPS();
                break;
        }
        TestDataHolder
                .addTestDataRecord(TestDataHolder.BASE_URL, baseUrl,
                        true, false);
        return baseUrl;
    }

    private String setUserType(){
        apiResources = new APIResources();
        String sso_set_usertype = null;
        if(TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST).equals("agent")) {
            sso_set_usertype  = apiResources.getServiceResource("SSO_SET_USERTYPE")+"/agent";
        }

        if (TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST).equals("staff")) {
            sso_set_usertype = apiResources.getServiceResource("SSO_SET_USERTYPE") + "/staff";
        }
        return sso_set_usertype;
    }

    private String getUser(){
       return SharedBrowserSteps.getLoginUserNameForUiTests(ConstantsProvider.getENVIRONMENT_DEFAULT(),
               TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST));
    }
}
