package ie.gov.agriculture.agschemes.databasequeries.nitrates;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLException;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.databasequeries.IQuery;
import ie.gov.agriculture.agschemes.databasequeries.QueryBase;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class CheckLoggedInUserIsRecordedForAgentQuery extends QueryBase implements IQuery {

    public CheckLoggedInUserIsRecordedForAgentQuery(String herdNo, String year, String applicationStatus) {
        super(herdNo, year, applicationStatus);
    }

    @Override
    public void buildQuery() {
        // not used by this class
    }

    @Override
    public String runQuery() throws SQLException {
        String userApplicationId = getApplicationIdFromHerdNo();
        String userId = getIdOfLoggedInUser(userApplicationId);
        String savedApplicationId = getIdOfSavedApplication(userApplicationId);

        assertApplicationIdIsForLoggedInUser(userApplicationId, userId,
            savedApplicationId);
        return stringResult;
    }

    private String getApplicationIdFromHerdNo() throws SQLException {
        log.warn("GETTING Application id of the application from herd number...");

        String getLoggedInUserApplicationIdQuery = "select APP_APPLICATION_ID from tdas_applications where app_current_business_id = '"
            + herdNo + "' and app_scheme_year = '" + year + "'";

        log.warn("select query 1 : getLoggedInUserApplicationIdQuery IS " + getLoggedInUserApplicationIdQuery);

        String getLoggedInUserApplicationIdResult = db.executeQueryReturningString(getLoggedInUserApplicationIdQuery);

        log.warn("result 1 : getLoggedInUserApplicationIdResult IS " + getLoggedInUserApplicationIdResult);

        log.warn("---------------------------------------------------------------------------------------------------");
        return getLoggedInUserApplicationIdResult;
    }

    private String getIdOfLoggedInUser(String getLoggedInUserApplicationIdResult) throws SQLException {
        log.warn("GETTING USER id of the user that logged in...");

        String getUserIdQuery = "select APN_AUDIT_USER from tdas_applications_nitrates where APN_APPLICATION_ID  = "
            + getLoggedInUserApplicationIdResult + "";

        log.warn("select query 2 : getUserIdQuery IS " + getUserIdQuery);

        String getUserIdResult = db.executeQueryReturningString(getUserIdQuery);

        log.warn("result 2 : getUserIdResult IS " + getUserIdResult);

        log.warn("---------------------------------------------------------------------------------------------------");
        return getUserIdResult;
    }

    private String getIdOfSavedApplication(String getLoggedInUserApplicationIdResult) throws SQLException {
        log.warn("GETTING application id of the saved application to ensure its the same...");

        String getApplicationIdQuery = "select APN_APPLICATION_ID from tdas_applications_nitrates where APN_APPLICATION_ID  = "
            + getLoggedInUserApplicationIdResult + "";

        log.warn("select query 3 : getApplicationIdQuery IS " + getApplicationIdQuery);

        String getApplicationIdResult = db.executeQueryReturningString(getApplicationIdQuery);

        log.warn("result 3 : getApplicationIdResult IS " + getApplicationIdResult);
        return getApplicationIdResult;
    }

    private void assertApplicationIdIsForLoggedInUser(String getLoggedInUserApplicationIdResult, String getUserIdResult,
        String getApplicationIdResult) {
        log.warn("ASSERTING USER ID FOR AGENT ...");
        log.warn("getUserIdResult IS " + getUserIdResult);
        log.warn("SSOAGENTLOGINUSERNAMECENTES IS " + ConstantsProvider.getSSOAGENTLOGINUSERNAMECENTEST());

        assertThat(getUserIdResult).isEqualTo(ConstantsProvider.getSSOAGENTLOGINUSERNAMECENTEST());

        log.warn("ASSERTING APPLICATION ID FOR AGENT ...");
        log.warn("getLoggedInUserApplicationIdResult IS " + getLoggedInUserApplicationIdResult);
        log.warn("getApplicationIdResult IS " + getApplicationIdResult);

        assertThat(getLoggedInUserApplicationIdResult).isEqualTo(getApplicationIdResult);
    }

}
