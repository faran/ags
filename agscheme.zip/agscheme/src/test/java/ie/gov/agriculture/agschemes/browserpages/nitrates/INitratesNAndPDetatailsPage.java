package ie.gov.agriculture.agschemes.browserpages.nitrates;

public interface INitratesNAndPDetatailsPage {

    void getNAndPEnquiryDetailsPhosphorus();

}