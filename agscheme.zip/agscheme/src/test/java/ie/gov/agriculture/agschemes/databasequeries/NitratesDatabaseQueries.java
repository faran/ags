package ie.gov.agriculture.agschemes.databasequeries;

import static org.assertj.core.api.Assertions.assertThat;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.CheckDatabaseIsNotNullQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.CheckLoggedInUserIsRecordedForAgentQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.NTRNitratesProsphatesForStaffQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNAnimalForAgentQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNAnimalForStaffQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNAnimalQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNGrassLandPercentQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNNetAreaOfHoldingForAgentQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNNetAreaOfHoldingForStaffQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.APNNetAreaOfHoldingQuery;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.AllowedAnimals;
import ie.gov.agriculture.agschemes.databasequeries.nitrates.apn.NitratesColumns;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import ie.gov.agriculture.agschemes.utils.DatabaseUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class NitratesDatabaseQueries {

    private StartupDatabaseQueries databaseQueryUtils;

    TestDataHolder testDataHolder;

    private final WebDriver webDriver;

    private int animalFailCount = 0;
    private int queryCount = 0;
    private int nAndPDetailsCount = 0;

    private boolean checkDatabaseIsNotNull(String herdNo, String year, String applicationStatus) throws SQLException {
        CheckDatabaseIsNotNullQuery query = new CheckDatabaseIsNotNullQuery(herdNo, year, applicationStatus);
        query.runQuery();
        return query.getBooleanResult();
    }

    private void checkLoggedInUserIsRecordedForStaff(String herdNo, String year, String applicationStatus,
        DatabaseUtils db) throws SQLException {

        log.warn("GETTING Application id of the application from herd number...");

        String getLoggedInUserApplicationIdQuery = "select APP_APPLICATION_ID from tdas_applications where app_current_business_id = '"
            + herdNo + "' and app_scheme_year = '" + year + "'";

        log.warn("select query 1 : getLoggedInUserApplicationIdQuery IS " + getLoggedInUserApplicationIdQuery);

        String getLoggedInUserApplicationIdResult = db.executeQueryReturningString(getLoggedInUserApplicationIdQuery);

        log.warn("result 1 : getLoggedInUserApplicationIdResult IS " + getLoggedInUserApplicationIdResult);

        log.warn("---------------------------------------------------------------------------------------------------");
        log.warn("GETTING USER id of the user that logged in...");

        String getUserIdQuery = "select APN_AUDIT_USER from tdas_applications_nitrates where APN_APPLICATION_ID  = "
            + getLoggedInUserApplicationIdResult + "";

        log.warn("select query 2 : getUserIdQuery IS " + getUserIdQuery);

        String getUserIdResult = db.executeQueryReturningString(getUserIdQuery);

        log.warn("result 2 : getUserIdResult IS " + getUserIdResult);

        log.warn("---------------------------------------------------------------------------------------------------");
        log.warn("GETTING application id of the saved application to ensure its the same...");

        String getApplicationIdQuery = "select APN_APPLICATION_ID from tdas_applications_nitrates where APN_APPLICATION_ID  = "
            + getLoggedInUserApplicationIdResult + "";

        log.warn("select query 3 : getApplicationIdQuery IS " + getApplicationIdQuery);

        String getApplicationIdResult = db.executeQueryReturningString(getApplicationIdQuery);

        log.warn("result 3 : getApplicationIdResult IS " + getApplicationIdResult);

        log.warn("ASSERTING USER ID FOR STAFF ...");
        log.warn("getUserIdResult IS " + getUserIdResult);
        log.warn("SSOSTAFFLOGINUSERNAMECENTEST IS " + ConstantsProvider.getSSOSTAFFLOGINUSERNAMECENTEST());

        assertThat(getUserIdResult).isEqualTo(ConstantsProvider.getSSOSTAFFLOGINUSERNAMECENTEST());

        log.warn("ASSERTING APPLICATION ID FOR STAFF ...");
        log.warn("getLoggedInUserApplicationIdResult IS " + getLoggedInUserApplicationIdResult);
        log.warn("getApplicationIdResult IS " + getApplicationIdResult);

        assertThat(getLoggedInUserApplicationIdResult).isEqualTo(getApplicationIdResult);

    }

    private void apnGrassLandPercentQueryForAgent(String herdNo, String year, String applicationStatus,
        DatabaseUtils db) throws SQLException {
        // TODO: need to fix this to account for bps 2020 as well
        // APN_NET_GRASSLAND_query

        // TODO: OLD value verify tests then delete this
        // eligibleAreaOfGrasslandCheckAgentValue

        String APN_GRASS_LAND_PERCENT_query = "select APN_GRASS_LAND_PERCENT from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_GRASS_LAND_PERCENT_result = db.executeQueryReturningString(APN_GRASS_LAND_PERCENT_query);

        log.warn("the APN_GRASS_LAND_PERCENT_query value is " + APN_GRASS_LAND_PERCENT_query);
        log.warn("the APN_GRASS_LAND_PERCENT_result value is " + APN_GRASS_LAND_PERCENT_result);
        // assertThat(APN_GRASS_LAND_PERCENT_result).isNotEmpty();
        log.warn("eligibleAreaOfGrasslandCheckAgentValue "
            + TestDataHolder
                .getTestDataRecord(TestDataHolder.getRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE)));
        assertThat(APN_GRASS_LAND_PERCENT_result)
            .isEqualTo(TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));
    }

    private void apnGrassLandPercentQueryForStaff(String herdNo, String year, String applicationStatus,
        DatabaseUtils db) throws SQLException, InterruptedException {
        // TODO: need to fix this to account for bps 2020 as well, delete old query
        // later
        // APN_NET_GRASSLAND_query

        String APN_GRASS_LAND_PERCENT_query = "select APN_GRASS_LAND_PERCENT from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_GRASS_LAND_PERCENT_result = db.executeQueryReturningString(APN_GRASS_LAND_PERCENT_query);

        Thread.sleep(10000);
        log.warn("DOING APN_GRASS_LAND_PERCENT_query CHECK - WAITING ...");

        log.warn("the APN_GRASS_LAND_PERCENT_query value is " + APN_GRASS_LAND_PERCENT_query);
        log.warn("the APN_GRASS_LAND_PERCENT_result value is " + APN_GRASS_LAND_PERCENT_result);
        // assertThat(APN_GRASS_LAND_PERCENT_result).isNotEmpty();
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));
        assertThat(APN_GRASS_LAND_PERCENT_result)
            .isEqualTo(TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));

    }

    // TODO: WHAT is this check for? Need to talk with developers on this
    private void apnGrassLandNetQueryForStaff(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws SQLException {
        // TODO: need to fix this to account for bps 2020 as well
        // APN_NET_GRASSLAND_query

        String APN_NET_GRASSLAND_query = "select APN_NET_GRASSLAND from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_NET_GRASSLAND_result = db.executeQueryReturningString(APN_NET_GRASSLAND_query);

        log.warn("the APN_NET_GRASSLAND_query value is " + APN_NET_GRASSLAND_query);
        log.warn("the APN_NET_GRASSLAND_result value is " + APN_NET_GRASSLAND_result);
        // assertThat(APN_GRASS_LAND_PERCENT_result).isNotEmpty();
        // Need to get more information from developers on this
        log.warn("eligibleAreaOfGrasslandCheckValue "
            + TestDataHolder.getTestDataRecord("eligibleAreaOfGrasslandCheckValue"));
        assertThat(APN_NET_GRASSLAND_result)
            .isEqualTo(TestDataHolder.getTestDataRecord("eligibleAreaOfGrasslandCheckValue"));

    }

    // TODO: WHAT is this check for? Need to talk with developers on this
    private void apnGrassLandNetQueryForAgent(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws SQLException {
        // TODO: need to fix this to account for bps 2020 as well
        // APN_NET_GRASSLAND_query

        String APN_NET_GRASSLAND_query = "select APN_NET_GRASSLAND from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_NET_GRASSLAND_result = db.executeQueryReturningString(APN_NET_GRASSLAND_query);

        log.warn("the APN_NET_GRASSLAND_query value is " + APN_NET_GRASSLAND_query);
        log.warn("the APN_NET_GRASSLAND_result value is " + APN_NET_GRASSLAND_result);
        // assertThat(APN_GRASS_LAND_PERCENT_result).isNotEmpty();
        // Need to get more information from developers on this
        log.warn("eligibleAreaOfGrasslandCheckAgentValue "
            + TestDataHolder.getTestDataRecord("eligibleAreaOfGrasslandCheckAgentValue"));
        assertThat(APN_NET_GRASSLAND_result)
            .isEqualTo(TestDataHolder.getTestDataRecord("eligibleAreaOfGrasslandCheckAgentValue"));

    }

    private void apnStoragePeriodQuery(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws SQLException {
        // APN_STORAGE_PERIOD_query

        String APN_STORAGE_PERIOD_query = "select APN_STORAGE_PERIOD from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";
        String APN_STORAGE_PERIOD_result = db.executeQueryReturningString(APN_STORAGE_PERIOD_query);

        log.warn("the APN_STORAGE_PERIOD_query value is " + APN_STORAGE_PERIOD_query);
        log.warn("the APN_STORAGE_PERIOD_result value is " + APN_STORAGE_PERIOD_result);
        assertThat(APN_STORAGE_PERIOD_result).isNotEmpty();

    }

    private void apnStoragePeriodQueryForAgent(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws SQLException {
        // APN_STORAGE_PERIOD_query

        String APN_STORAGE_PERIOD_query = "select APN_STORAGE_PERIOD from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_STORAGE_PERIOD_result = db.executeQueryReturningString(APN_STORAGE_PERIOD_query);

        log.warn("the APN_STORAGE_PERIOD_query value is " + APN_STORAGE_PERIOD_query);
        log.warn("the APN_STORAGE_PERIOD_result value is " + APN_STORAGE_PERIOD_result);
        // assertThat(APN_STORAGE_PERIOD_result).isNotEmpty();
        log.warn("TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION));
        assertThat(TestDataHolder.getTestDataRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION))
            .contains(APN_STORAGE_PERIOD_result);

    }

    private void apnStoragePeriodQueryForStaff(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws SQLException {
        // APN_STORAGE_PERIOD_query

        String APN_STORAGE_PERIOD_query = "select APN_STORAGE_PERIOD from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_STORAGE_PERIOD_result = db.executeQueryReturningString(APN_STORAGE_PERIOD_query);

        log.warn("the APN_STORAGE_PERIOD_query value is " + APN_STORAGE_PERIOD_query);
        log.warn("the APN_STORAGE_PERIOD_result value is " + APN_STORAGE_PERIOD_result);
        // assertThat(APN_STORAGE_PERIOD_result).isNotEmpty();
        log.warn("TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION));
        assertThat(TestDataHolder.getTestDataRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION))
            .contains(APN_STORAGE_PERIOD_result);

    }

    private void apnAmountSlurrySpreadQuery(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws SQLException {
        // APN_AMOUNT_SLURRY_SPREAD_query

        String APN_AMOUNT_SLURRY_SPREAD_query = "select APN_AMOUNT_SLURRY_SPREAD from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";
        String APN_AMOUNT_SLURRY_SPREAD_result = db.executeQueryReturningString(APN_AMOUNT_SLURRY_SPREAD_query);

        log.warn("the APN_AMOUNT_SLURRY_SPREAD_query value is " + APN_AMOUNT_SLURRY_SPREAD_query);
        log.warn("the APN_AMOUNT_SLURRY_SPREAD_result value is " + APN_AMOUNT_SLURRY_SPREAD_result);
        assertThat(APN_AMOUNT_SLURRY_SPREAD_result).isNotEmpty();

    }

    private void apnAmountSlurrySpreadQueryForAgent(String herdNo, String year, String applicationStatus,
        DatabaseUtils db) throws SQLException {
        // APN_AMOUNT_SLURRY_SPREAD_query
        // TODO: original value is = estimatedNitrogenSpreadAgent delete later if this
        // works

        String APN_AMOUNT_SLURRY_SPREAD_query = "select APN_AMOUNT_SLURRY_SPREAD from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_AMOUNT_SLURRY_SPREAD_result = db.executeQueryReturningString(APN_AMOUNT_SLURRY_SPREAD_query);

        log.warn("the APN_AMOUNT_SLURRY_SPREAD_query value is " + APN_AMOUNT_SLURRY_SPREAD_query);
        log.warn("the APN_AMOUNT_SLURRY_SPREAD_result value is " + APN_AMOUNT_SLURRY_SPREAD_result);
        // assertThat(APN_AMOUNT_SLURRY_SPREAD_result).isNotEmpty();
        log.warn("estimatedNitrogenSpread " + TestDataHolder.getTestDataRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD_AGENT));
        assertThat(APN_AMOUNT_SLURRY_SPREAD_result)
            .isEqualTo(TestDataHolder.getTestDataRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD_AGENT));

    }

    private void apnAmountSlurrySpreadQueryForStaff(String herdNo, String year, String applicationStatus,
        DatabaseUtils db) throws SQLException {
        // APN_AMOUNT_SLURRY_SPREAD_query

        String APN_AMOUNT_SLURRY_SPREAD_query = "select APN_AMOUNT_SLURRY_SPREAD from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String APN_AMOUNT_SLURRY_SPREAD_result = db.executeQueryReturningString(APN_AMOUNT_SLURRY_SPREAD_query);

        log.warn("the APN_AMOUNT_SLURRY_SPREAD_query value is " + APN_AMOUNT_SLURRY_SPREAD_query);
        log.warn("the APN_AMOUNT_SLURRY_SPREAD_result value is " + APN_AMOUNT_SLURRY_SPREAD_result);
        log.warn("estimatedNitrogenSpread " + TestDataHolder.getTestDataRecord("estimatedNitrogenSpread"));
        assertThat(APN_AMOUNT_SLURRY_SPREAD_result)
            .isEqualTo(TestDataHolder.getTestDataRecord("estimatedNitrogenSpread"));
        // assertThat(APN_AMOUNT_SLURRY_SPREAD_result).isNotEmpty();

    }

    private void runTDASApplicationsNitratesQuery(String herdNo, String year, String applicationStatus, String column,
        String expected) throws SQLException {

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        String query = "select " + column
            + " from tdas_applications, tdas_applications_nitrates, tsas_status "
            + "where app_application_id = apn_application_id "
            + "and app_current_status_code = ST_STATUS_CODE "
            + "and app_current_business_id = '" + herdNo
            + "' and APP_SCHEME_YEAR='" + year
            + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        String result = db.executeQueryReturningString(query);

        log.warn("the " + column + "_query value is " + query);
        log.warn("the " + column + "result value is " + result);
        assertThat(result).isEqualTo(expected);
    }

    private void apnNetAreaOlolfHoldingQueryForStaff(String herdNo, String year, String applicationStatus,
        DatabaseUtils db) throws SQLException {

        String APN_NET_AREA_OF_HOLDING_query = "select APN_NET_AREA_OF_HOLDING from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";

        log.warn("the APN_NET_AREA_OF_HOLDING_query value is " + APN_NET_AREA_OF_HOLDING_query);
        String actual = db.executeQueryReturningString(APN_NET_AREA_OF_HOLDING_query);
        String expected = TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_VALUE);

        log.warn("the APN_NET_AREA_OF_HOLDING_query value is " + APN_NET_AREA_OF_HOLDING_query);
        log.warn("the APN_NET_AREA_OF_HOLDING_result value is " + actual);
        log.warn("expected eligibleAreaOfHoldingCheckValue " + expected);
        assertThat(actual)
            .as("APN_NET_AREA_OF_HOLDING is as expected? ")
            .isEqualTo(expected);
        // assertThat(APN_NET_AREA_OF_HOLDING_result).isNotEmpty();

    }

    private void assertNAndPInDbQueryForStaff(String herdNo, String ntrYear, DatabaseUtils db) throws Exception {

        String n_And_p_query_result = new NTRNitratesProsphatesForStaffQuery(herdNo, ntrYear, "").runQuery();

        log.warn("n_And_p_query_result IS " + n_And_p_query_result);

        try {
            log.warn("phosphorusRowOneStaffValue "
                + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_ONE_STAFF_VALUE));
            assertThat(n_And_p_query_result)
                .isEqualTo(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_ONE_STAFF_VALUE));
        } catch (AssertionError e) {
            log.warn("continue.. PHOSPHORUS_ROW_ONE_STAFF_VALUE does match database nAndPDetailsCount");
            nAndPDetailsCount++;
            log.warn("continue.. nAndPDetailsCount IS " + nAndPDetailsCount);
        }

        try {
            log.warn("phosphorusRowTwoStaffValue "
                + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_TWO_STAFF_VALUE));
            assertThat(n_And_p_query_result)
                .isEqualTo(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_TWO_STAFF_VALUE));
        } catch (AssertionError e) {
            log.warn("continue.. PHOSPHORUS_ROW_TWO_STAFF_VALUE does match database nAndPDetailsCount");
            nAndPDetailsCount++;
            log.warn("continue.. nAndPDetailsCount IS " + nAndPDetailsCount);
        }

        try {
            log.warn("phosphorusRowThreeStaffValue "
                + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_THREE_STAFF_VALUE));
            assertThat(n_And_p_query_result)
                .isEqualTo(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_THREE_STAFF_VALUE));
        } catch (AssertionError e) {
            log.warn("continue.. PHOSPHORUS_ROW_THREE_STAFF_VALUE does match database nAndPDetailsCount");
            nAndPDetailsCount++;
            log.warn("continue.. nAndPDetailsCount IS " + nAndPDetailsCount);
        }

        try {
            log.warn("phosphorusRowFourStaffValue "
                + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FOUR_STAFF_VALUE));
            assertThat(n_And_p_query_result)
                .isEqualTo(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FOUR_STAFF_VALUE));
        } catch (AssertionError e) {
            log.warn("continue.. PHOSPHORUS_ROW_FOUR_STAFF_VALUE does match database nAndPDetailsCount");
            nAndPDetailsCount++;
            log.warn("continue.. nAndPDetailsCount IS " + nAndPDetailsCount);
        }

        try {
            log.warn("phosphorusRowFiveStaffValue "
                + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FIVE_STAFF_VALUE));
            assertThat(n_And_p_query_result)
                .isEqualTo(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FIVE_STAFF_VALUE));
        } catch (AssertionError e) {
            log.warn("continue.. PHOSPHORUS_ROW_FIVE_STAFF_VALUE does match database nAndPDetailsCount");
            nAndPDetailsCount++;
            log.warn("continue.. nAndPDetailsCount IS " + nAndPDetailsCount);
        }

        // Fail the test if all nAndPDetailsCount data is not matching the rows in ui
        // for PHOSPHORUS
        log.warn("nAndPDetailsCount value " + nAndPDetailsCount);
        assertThat(animalFailCount).isNotEqualTo(5);
    }

    private void assertAnimalsInDbQueryForAgent(String herdNo, String year, String applicationStatus, DatabaseUtils db)
        throws Exception {

        runAPNAnimalForAgentQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_CATTLE);
        runAPNAnimalForAgentQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_HORSES);
        runAPNAnimalForAgentQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_SHEEP);
        runAPNAnimalForAgentQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_PIGS);
        runAPNAnimalForAgentQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_GOATS);
        runAPNAnimalForAgentQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_DEER);

        // Fail the test if all animal data is null
        log.warn("AnimalFailCount value " + animalFailCount);
        assertThat(animalFailCount).isNotEqualTo(6);
    }

    private void runAPNAnimalForAgentQuery(String herdNo, String year, String applicationStatus, String animal)
        throws SQLException {
        try {
            new APNAnimalForAgentQuery(herdNo, year, applicationStatus, animal).runQuery();
        } catch (AssertionError e) {
            log.warn("continue.. " + animal + "_result is null");
            animalFailCount++;
        }
    }

    private void assertAnimalsInDbQueryForStaff(String herdNo, String year, String applicationStatus)
        throws Exception {

        runAPNAnimalForStaffQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_CATTLE);
        runAPNAnimalForStaffQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_HORSES);
        runAPNAnimalForStaffQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_SHEEP);
        runAPNAnimalForStaffQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_PIGS);
        runAPNAnimalForStaffQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_GOATS);
        runAPNAnimalForStaffQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_DEER);

        // Fail the test if all animal data is null
        log.warn("AnimalFailCount value " + animalFailCount);
        assertThat(animalFailCount).as("animalFailCount != # animal queries run? ").isNotEqualTo(queryCount);
    }

    private void runAPNAnimalForStaffQuery(String herdNo, String year, String applicationStatus, String animal)
        throws SQLException {
        queryCount++;
        try {
            new APNAnimalForStaffQuery(herdNo, year, applicationStatus, animal).runQuery();
        } catch (AssertionError e) {
            log.warn("continue.. " + animal + "_result is null");
            animalFailCount++;

        }
    }

    private void assertAnimalsInDbQuery(String herdNo, String year, String applicationStatus)
        throws SQLException {

        runAPNAnimalQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_CATTLE);
        runAPNAnimalQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_HORSES);
        runAPNAnimalQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_SHEEP);
        runAPNAnimalQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_PIGS);
        runAPNAnimalQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_GOATS);
        runAPNAnimalQuery(herdNo, year, applicationStatus, AllowedAnimals.APN_DEER);

        // Fail the test if all animal data is null
        log.warn("AnimalFailCount value " + animalFailCount);
        assertThat(animalFailCount).isNotEqualTo(6);

    }

    private void runAPNAnimalQuery(String herdNo, String year, String applicationStatus, String animal)
        throws SQLException {
        try {
            new APNAnimalQuery(herdNo, year, applicationStatus, animal).runQuery();
        } catch (AssertionError e) {
            log.warn("continue.. " + animal + "_result is null");
            animalFailCount++;
        }
    }

    public void assertApplicationIsDeletedStatus(String herdNo) throws Exception {

        String deletedStatus = "Application Deleted";

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        String ST_STATUS_DESCRIPTION_query = "select ST_STATUS_DESCRIPTION  from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdNo + "' and ST_STATUS_DESCRIPTION = 'Application Deleted'  order by APN_AUDIT_DATE desc";
        String result = db.executeQueryReturningString(ST_STATUS_DESCRIPTION_query);

        log.warn("the ST_STATUS_DESCRIPTION_query value is " + ST_STATUS_DESCRIPTION_query);
        log.info("result VALUE =" + result);
        log.info("deleted status VALUE = " + deletedStatus);

        assertThat(result).isEqualTo(deletedStatus);

    }

    public void assertApplicationIsNotInDatabase(String herdNo, String year) throws Exception {

        Thread.sleep(10000);

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        // APP_CURRENT_BUSINESS_ID_query

        String APP_CURRENT_BUSINESS_ID_query = "select APP_CURRENT_BUSINESS_ID from tdas_applications, tdas_applications_nitrates, tsas_status where app_application_id = apn_application_id and app_current_status_code = ST_STATUS_CODE and app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' order by APN_AUDIT_DATE desc";

        log.warn("the APP_CURRENT_BUSINESS_ID_query value is " + APP_CURRENT_BUSINESS_ID_query);
        String APP_CURRENT_BUSINESS_ID_result = db.executeQueryReturningString(APP_CURRENT_BUSINESS_ID_query);
        log.warn("the APP_CURRENT_BUSINESS_ID_result value is " + APP_CURRENT_BUSINESS_ID_result);
        assertThat(APP_CURRENT_BUSINESS_ID_result).isEmpty();
    }

    public void assertApplicationStatusIsSavedInDatabaseForAgent(String herdNo, String year, String applicationStatus)
        throws Exception {

        log.warn("DOING DB CHECK - WAITING ...");

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        boolean found = false;
        int loops = 0;
        do {
            try {
                Thread.sleep(10000);
                log.warn(" DB CHECK - WAITING EVERY 10 SECONDS ... LOOP COUNTER ... " + loops);
                log.warn(" DB CHECK - FOUND VALUE " + found);
            } catch (InterruptedException e) {
                log.error("Sleep interupted while waiting to check DB", e);
            }
            found = checkDatabaseIsNotNull(herdNo, year, applicationStatus);

        } while (!found && loops++ < 20);
        assertThat(found).isTrue();

        // TODO: need to add more checks and check ids once that is fixed
        new APNNetAreaOfHoldingForAgentQuery(herdNo, year, applicationStatus).runQuery();
        apnGrassLandPercentQueryForAgent(herdNo, year, applicationStatus, db);
        apnGrassLandNetQueryForAgent(herdNo, year, applicationStatus, db);
        apnStoragePeriodQueryForAgent(herdNo, year, applicationStatus, db);
        apnAmountSlurrySpreadQueryForAgent(herdNo, year, applicationStatus, db);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_CUT_HEDGROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_WBTHORN_TRLFT_ID, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_MAINTAIN_HROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_CUT_HEDGROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.ST_STATUS_DESCRIPTION, applicationStatus);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APP_CURRENT_BUSINESS_ID, herdNo);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TERMS_CONDITIONS_IND, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TRAINING_GRASSLAND_IND, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TRAINING_ENVIRONMENTAL_IND, "0");
        assertAnimalsInDbQueryForAgent(herdNo, year, applicationStatus, db);

    }

    public void assertApplicationStatusIsSavedInDatabase(String herdNo, String year, String applicationStatus)
        throws Exception {

        log.warn("DOING DB CHECK - WAITING ...");
        BrowserUtils.pause(10);

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
        // TODO: need to add more checks and check ids once that is fixed
        new APNNetAreaOfHoldingQuery(herdNo, year, applicationStatus).runQuery();
        new APNGrassLandPercentQuery(herdNo, year, applicationStatus).runQuery();
        apnStoragePeriodQuery(herdNo, year, applicationStatus, db);
        apnAmountSlurrySpreadQuery(herdNo, year, applicationStatus, db);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_CUT_HEDGROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_WBTHORN_TRLFT_ID, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_MAINTAIN_HROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_CUT_HEDGROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.ST_STATUS_DESCRIPTION, applicationStatus);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APP_CURRENT_BUSINESS_ID, herdNo);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TERMS_CONDITIONS_IND, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TRAINING_GRASSLAND_IND, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TRAINING_ENVIRONMENTAL_IND, "0");
        assertAnimalsInDbQuery(herdNo, year, applicationStatus);

    }

    public void assertApplicationStatusIsSavedInDatabaseForStaff(String herdNo, String year, String applicationStatus)
        throws Exception {

        log.warn("DOING DB CHECK - WAITING ...");

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        boolean found = false;
        int loops = 0;
        do {
            try {
                Thread.sleep(10000);
                log.warn(" DB CHECK - WAITING EVERY 10 SECONDS ... LOOP COUNTER ... " + loops);
                log.warn(" DB CHECK - FOUND VALUE " + found);
            } catch (InterruptedException e) {
                log.error("Sleep interupted while waiting to check DB", e);
            }
            found = checkDatabaseIsNotNull(herdNo, year, applicationStatus);

        } while (!found && loops++ < 20);
        assertThat(found).isTrue();

        // TODO: need to add more checks and check ids once that is fixed

        new APNNetAreaOfHoldingForStaffQuery(herdNo, year, applicationStatus).runQuery();
        apnGrassLandPercentQueryForStaff(herdNo, year, applicationStatus, db);
        apnGrassLandNetQueryForStaff(herdNo, year, applicationStatus, db);
        apnStoragePeriodQueryForStaff(herdNo, year, applicationStatus, db);
        apnAmountSlurrySpreadQueryForStaff(herdNo, year, applicationStatus, db);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_CUT_HEDGROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_WBTHORN_TRLFT_ID, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_MAINTAIN_HROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_BDMEASURE_CUT_HEDGROW_ID, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.ST_STATUS_DESCRIPTION, applicationStatus);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APP_CURRENT_BUSINESS_ID, herdNo);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TRAINING_GRASSLAND_IND, "1");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TRAINING_ENVIRONMENTAL_IND, "0");
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APN_TERMS_CONDITIONS_IND, "1");
        checkLoggedInUserIsRecordedForStaff(herdNo, year, applicationStatus, db);
        assertAnimalsInDbQueryForStaff(herdNo, year, applicationStatus);

    }

    public void assertNAndPDetailsForStaff(String herdNo, String year, String applicationStatus, String ntrYear)
        throws Exception {

        log.warn("DOING DB CHECK - WAITING ...");

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        boolean found = false;
        int loops = 0;
        do {
            try {
                Thread.sleep(10000);
                log.warn(" DB CHECK - WAITING EVERY 10 SECONDS ... LOOP COUNTER ... " + loops);
                log.warn(" DB CHECK - FOUND VALUE " + found);
            } catch (InterruptedException e) {
                log.error("Sleep interupted while waiting to check DB", e);
            }
            found = checkDatabaseIsNotNull(herdNo, year, applicationStatus);

        } while (!found && loops++ < 20);
        assertThat(found).isTrue();

        assertNAndPInDbQueryForStaff(herdNo, ntrYear, db);

    }

    public void assertApplicationStatusNoDataIsSavedInDatabaseStaff(String herdNo, String year,
        String applicationStatus) throws Exception {

        log.warn("DOING DB CHECK - WAITING ...");

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        boolean found = false;
        int loops = 0;
        do {
            try {
                Thread.sleep(10000);
                log.warn(" DB CHECK - WAITING EVERY 10 SECONDS ... LOOP COUNTER ... " + loops);
                log.warn(" DB CHECK - FOUND VALUE " + found);
            } catch (InterruptedException e) {
                log.error("Sleep interupted while waiting to check DB", e);
            }
            found = checkDatabaseIsNotNull(herdNo, year, applicationStatus);

        } while (!found && loops++ < 20);
        assertThat(found).isTrue();

        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.ST_STATUS_DESCRIPTION, applicationStatus);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APP_CURRENT_BUSINESS_ID, herdNo);
        checkLoggedInUserIsRecordedForStaff(herdNo, year, applicationStatus, db);

    }

    public void assertApplicationStatusNoDataIsSavedInDatabaseAgent(String herdNo, String year,
        String applicationStatus) throws Exception {

        log.warn("DOING DB CHECK - WAITING ...");

        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        DatabaseUtils db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());

        boolean found = false;
        int loops = 0;
        do {
            try {
                Thread.sleep(10000);
                log.warn(" DB CHECK - WAITING EVERY 10 SECONDS ... LOOP COUNTER ... " + loops);
                log.warn(" DB CHECK - FOUND VALUE " + found);
            } catch (InterruptedException e) {
                log.error("Sleep interupted while waiting to check DB", e);
            }
            found = checkDatabaseIsNotNull(herdNo, year, applicationStatus);

        } while (!found && loops++ < 20);
        assertThat(found).isTrue();

        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.ST_STATUS_DESCRIPTION, applicationStatus);
        runTDASApplicationsNitratesQuery(herdNo, year, applicationStatus,
            NitratesColumns.APP_CURRENT_BUSINESS_ID, herdNo);
        new CheckLoggedInUserIsRecordedForAgentQuery(herdNo, year, applicationStatus).runQuery();

    }

}
