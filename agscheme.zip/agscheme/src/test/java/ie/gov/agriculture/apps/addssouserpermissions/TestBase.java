package ie.gov.agriculture.apps.addssouserpermissions;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.restassured.response.Response;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class TestBase {
    public static WebDriver driver;
    public static Properties environment;
    public static Properties config;
    public static String API_URL = System.getProperty("testAPIEnvironment");
    public static String ENV_URL = System.getProperty("testEnvironment");
    public static String SSO_UERNAME = System.getProperty("ssoUserName");

    String URL = null;
    Response resp;

    /******* To intialize the property file ****************************/
    public void intializeProperties() {
        if (config == null) {
            config = new Properties();

            try {
                FileInputStream fs = new FileInputStream("resources/config.properties");
                config.load(fs);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @SuppressWarnings("deprecation")

    public void openBrowser(String bType) throws MalformedURLException {
        System.out.println(" #### Selenium Grid On :" + config.getProperty("seleniumGridOn"));

        if (config.getProperty("seleniumGridOn").equalsIgnoreCase("false")) {
            // Run locally if Grid is off

            if (bType.equalsIgnoreCase("Mozilla")) {
                System.setProperty("webdriver.gecko.driver",
                    System.getProperty("user.dir") + "\\resources\\Softwares\\FireFox\\geckodriver.exe");
                DesiredCapabilities dc = new DesiredCapabilities();
                dc.setCapability("marionatte", false);
                FirefoxOptions opt = new FirefoxOptions();
                opt.merge(dc);
                driver = new FirefoxDriver(opt);

            } else if (bType.equalsIgnoreCase("Chrome")) {
                System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
                    + "\\resources\\Softwares\\chromedriver\\win32\\chromedriver.exe");
                driver = new ChromeDriver();

                System.out.println("\n Environment is: " + environment);

            } else {
                System.setProperty("webdriver.ie.driver", System.getProperty("user.dir")
                    + "\\resources\\Softwares\\IEDriverServer\\IEDriverServer-32bit.exe");
                DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
                capabilities.setCapability(InternetExplorerDriver.NATIVE_EVENTS, false);
                capabilities.setCapability("unexpectedAlertBehaviour", "accept");
                capabilities.setCapability("ignoreProtectedModeSettings", true);
                capabilities.setCapability("disable-popup-blocking", true);
                capabilities.setCapability("enablePersistentHover", true);
                capabilities.setCapability("ignoreZoomSetting", true);
                driver = new InternetExplorerDriver(capabilities);
            }
        } else {

            System.out.println("\n ************* USING VIRTUAL MACHINE  ************** \n");
            System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
                + "\\resources\\Softwares\\chromedriver\\win32\\chromedriver.exe");
            // DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
            ChromeOptions capabilities = new ChromeOptions();
            capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
            // log.debug("trying to get the remote webdriver");
            driver = new RemoteWebDriver(new URL("http://10.2.68.88:5555/wd/hub"), capabilities);

            // log.debug("got the remote webdriver");
        }
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        driver.manage().window().maximize();
    }

    /****
     * To select the API url for different env passed from jenkins or run locally.
     ****/
    public String getApiUrl() {
        String URL = null;
        if (API_URL != null) {
            if (API_URL.equalsIgnoreCase("DEV_API_URL")) {
                URL = config.getProperty("ENV_DEV");
            } else if (API_URL.equalsIgnoreCase("UAT_API_URL")) {
                URL = config.getProperty("ENV_DEV");
            }
        } else {
            URL = config.getProperty("ENV_UAT");
        }
        return URL;
    }

    public String getEnvUrl(String ENV_URL) {
        if (ENV_URL != null) {
            if (ENV_URL.equalsIgnoreCase("DEV")) {
                URL = config.getProperty("DEV_URL");
            } else if (ENV_URL.equalsIgnoreCase("UAT")) {
                URL = config.getProperty("UAT_URL");
            } else if (ENV_URL.equalsIgnoreCase("CENTEST")) {
                URL = config.getProperty("CENTEST");
            }
        } else {
            URL = config.getProperty("CENTEST");
        }
        return URL;
    }

    public static ExpectedCondition<Boolean> angularHasFinishedProcessing() {
        return driver -> Boolean.valueOf(((JavascriptExecutor) driver).executeScript(
            "return (window.angular !== undefined) && (angular.element(document).injector() !== undefined) && (angular.element(document).injector().get('$http').pendingRequests.length === 0)")
            .toString());
    }

    private boolean isElementPresent(String Locator) {
        List<WebElement> elementList = null;
        elementList = driver.findElements(By.cssSelector("Locator"));
        return elementList.size() != 0;

    }

    public static int getRandomNumber() {
        Random rand = new Random(System.currentTimeMillis());
        int num = rand.nextInt(2000);
        return num;
    }

    public static String gettripNumber(String Year) {
        long trip = System.currentTimeMillis();
        String tripNo = Year + trip;
        return tripNo;
    }

    public void clickWebObject(WebElement we) {
        if (we.isEnabled()) {
            JavascriptExecutor executor = (JavascriptExecutor) driver;
            executor.executeScript("arguments[0].click()", we);
        } else {
            System.out.println("Element is not enabled");
        }
    }

    /**** To read the file and store in string. ****/
    public String generateStringFromFile(String path) throws IOException {
        return new String(Files.readAllBytes(Paths.get(path)));
    }

    /********
     * To pass the file path. in Example
     ************************************/
    public String getPostFile(String vesselLength, String fileName) {
        return "resources//DataJasonfile//" + vesselLength + "//" + fileName + ".json";
    }

    public String getPostFileForPut(String vesselLength, String fileName) {
        return System.getProperty("user.dir") + "\\resources\\Jason file\\" + vesselLength + "\\PUTMethod\\" + fileName
            + ".json";
    }

    /**********************
     * get file from the GetMethod folder and pass to datatable
     ******************/
    public String getFile(List<List<String>> data) {
        return System.getProperty("user.dir") + "\\src\\test\\resources\\Jason file\\VesselGreater15M\\"
            + data.get(1).get(0) + ".json";
    }

    private DesiredCapabilities getDesiredCapabilities(@NonNull String browserName) {
        DesiredCapabilities capabilities;
        ChromeOptions chromeOptions = new ChromeOptions();
        switch (browserName.toLowerCase()) {
        case "chrome-headless":
        case "chrome":
            capabilities = new DesiredCapabilities();
            capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
            chromeOptions.addArguments("disable-extensions", "--start-maximized");
            capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
            capabilities.setCapability("chrome.switches", "--auth-server-whitelist='jira.*.agriculture.gov.ie'");
            break;
        case "ie":
            capabilities = DesiredCapabilities.internetExplorer();
            capabilities.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, "about:blank");
            capabilities.setCapability(InternetExplorerDriver.REQUIRE_WINDOW_FOCUS, true);
            capabilities.setCapability(InternetExplorerDriver.IE_ENSURE_CLEAN_SESSION, true);
            capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
            capabilities.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.ACCEPT);
            capabilities.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
            capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
            break;
        case "firefox":
            FirefoxOptions ffOptions = new FirefoxOptions();
            capabilities = new DesiredCapabilities();
            FirefoxProfile profile = new FirefoxProfile();// new ProfilesIni().getProfile("default");
            File profileDir = profile.layoutOnDisk();
            profile.clean(profileDir);
            profile.deleteExtensionsCacheIfItExists(profileDir);
            profile.setAcceptUntrustedCertificates(true);
            profile.setAssumeUntrustedCertificateIssuer(false);
            profile.setPreference("network.proxy.type", 2);
            ffOptions.setCapability("marionette", true);
            ffOptions.setProfile(profile);
            capabilities.setCapability(FirefoxOptions.FIREFOX_OPTIONS, ffOptions);
            break;
        default:
            throw new IllegalArgumentException("Browser: " + browserName + " not " + "supported..");
        }
        return capabilities;
    }

    private DesiredCapabilities getDesiredCapabilities(@NonNull String browserName, boolean enableLogging) {
        DesiredCapabilities capabilities = getDesiredCapabilities(browserName);
        if (capabilities != null && enableLogging) {
            // log.debug("Enable logging on browser of type performance");
            LoggingPreferences logPrefs = new LoggingPreferences();
            logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
            capabilities.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);
        }
        return capabilities;
    }

    public void refreshPage() {
        driver.navigate().refresh();
    }

    /**
     * Wait will ignore instances of NotFoundException that are encountered (thrown) by default in the 'until'
     * condition, and immediately propagate all others. // * @param driver The WebDriver instance to pass to the
     * expected conditions // * @param timeOutInSeconds The timeout in seconds when an expectation is called // * @param
     * sleepInMillis The duration in milliseconds to sleep between polls.
     */
    public void driverWait() {
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(webDriver -> ((JavascriptExecutor) driver).executeScript("return document.readyState").toString()
            .equals("complete"));
    }

    public void clickWebElement(WebElement element) {
        try {
            Thread.sleep(2000);
            Actions act = new Actions(driver);
            act.moveToElement(element).click().build().perform();
        } catch (InterruptedException e) {
            e.printStackTrace();
            // log.info("Fishery doesnot exist inQB dasboard screen ");
        }

    }
}
