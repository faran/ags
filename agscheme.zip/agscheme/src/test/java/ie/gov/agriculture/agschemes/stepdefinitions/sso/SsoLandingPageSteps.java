package ie.gov.agriculture.agschemes.stepdefinitions.sso;

import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;

public class SsoLandingPageSteps extends DriverFactory {

    public SsoLandingPageSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @Then("^user is logged in to sso landing page$")
    public void userIsLoggedInToSsoLandingPage() {
        ssoLandingPage.validateDafmDetails();
    }

    @And("^user navigates to nitrates landing page$")
    public void userNavigatesToNitratesLandingPage() {
        ssoLandingPage.clickNitratesDerogationSystemLink();
    }

    @Given("user navigates to ofs landing page")
    public void user_navigates_to_ofs_landing_page() {
        ssoLandingPage.clickOfsSystemLink();
    }

}
