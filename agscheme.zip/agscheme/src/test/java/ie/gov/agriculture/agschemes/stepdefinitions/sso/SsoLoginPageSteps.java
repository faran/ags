package ie.gov.agriculture.agschemes.stepdefinitions.sso;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.Given;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class SsoLoginPageSteps extends DriverFactory {

    public SsoLoginPageSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @Given("user logs into sso")
    public void userLogsIn() throws Exception {

        String url = SharedBrowserSteps.getUrlForUiTests(ConstantsProvider.getENVIRONMENT_DEFAULT(),
            TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST));
        driver.get(url);

        log.debug("Got URL, " + url + ". Logging in...");
        loginPage.login();
    }

}
