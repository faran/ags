package ie.gov.agriculture.agschemes.browserpages.sso;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.commons.AllowedRoles;
import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class SsoLoginPage {

    private final WebDriver webDriver;

    private SsoAgentPinCodePage ssoAgentPinCodePageObject;

    @FindBy(id = "mat-input-sso-lib-username-field-0")
    private WebElement userNameTextField;

    @FindBy(id = "mat-input-sso-lib-password-field-0")
    private WebElement passwordTextField;

    @FindBy(id = "login-form-submit-button")
    private WebElement loginButton;

    @FindBy(id = "confirm_data_protection")
    private WebElement confirmButton;

    public void login() throws Exception {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        if (AllowedRoles.ROLE_STAFF.contentEquals(userType)) {
            loginAsStaff(userType);
            return;
        }
        loginAsAgentOrIndividual(userType);
    }

    public void loginAsStaff(String userType) throws Exception {
        enterUserNameAndPassword(userType);
        BrowserUtils.waitAndClickElement(webDriver, confirmButton);
        BrowserUtils.waitAndClickElement(webDriver, loginButton);
        BrowserUtils.waitUntilAngular5Ready(webDriver);

    }

    public void loginAsAgentOrIndividual(String userType) throws Exception {
        enterUserNameAndPassword(userType);
        enterPinCode();
        BrowserUtils.waitAndClickElement(webDriver, loginButton);
        BrowserUtils.waitUntilAngular5Ready(webDriver);

    }

    private void enterUserNameAndPassword(String userType) throws Exception {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.sendKeysToWebElement(webDriver, userNameTextField,
            SharedBrowserSteps.getLoginUserNameForUiTests(ConstantsProvider.getENVIRONMENT_DEFAULT(), userType));
        BrowserUtils.sendKeysToWebElement(webDriver, passwordTextField,
            SharedBrowserSteps.getPasswordForUiTests(ConstantsProvider.getENVIRONMENT_DEFAULT()));
    }

    private void enterPinCode() throws InterruptedException {
        ssoAgentPinCodePageObject = PageFactory.initElements(webDriver, SsoAgentPinCodePage.class);
        Thread.sleep(5000);
        BrowserUtils.waitForAngular5Load(webDriver);
        ssoAgentPinCodePageObject.enterPinCode();
    }

}
