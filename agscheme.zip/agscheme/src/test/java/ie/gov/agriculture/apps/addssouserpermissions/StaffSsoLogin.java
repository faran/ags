package ie.gov.agriculture.apps.addssouserpermissions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class StaffSsoLogin extends TestBase {
    WebDriver driver;

    public StaffSsoLogin(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(partialLinkText = "Organic Farming Scheme")
    public WebElement ofsLink;
    @FindBy(partialLinkText = "Organic Farming System")
    public WebElement rdfsLink;
    @FindBy(partialLinkText = "GLAS")
    public WebElement glasLink;
    @FindBy(partialLinkText = "SSO Administration")
    public WebElement ssoAdmin;
    @FindBy(partialLinkText = "Authorisations")
    public WebElement authorisationsLink;

    // @FindBy(how = How.CSS, using = "input[id='inputUsername']")
    @FindBy(how = How.CSS, using = "input[id='inputUsername']")
    public WebElement ssoUserName;

    @FindBy(how = How.CSS, using = "input[id='inputPassword']")
    public WebElement ssoPassword;
    @FindBy(how = How.CSS, using = "input[id='_id33']")
    public WebElement ssoDataCheckBox;
    @FindBy(how = How.CSS, using = "input[id='logonCommandButton']")
    public WebElement ssoLogonButton;
    @FindBy(css = "img[*]")
    public WebElement inProgressImg;
    /********************** Admin ***********/

    @FindBy(css = "input[id='usernameCriteria']")
    public WebElement adminUsernameField;

    @FindBy(css = "a[id='searchCommandButton']")
    public WebElement searchButton;

    @FindBy(css = "*[id='searchResultsTable:0:selectButton']")
    public WebElement selectUserRadioButton;

    @FindBy(css = "a[id='searchResultsTable:editButton']")
    public WebElement editUserButton;

    @FindBy(css = "select[id='applicationsListSelect']")
    public WebElement applicationSelect;

    // workarea
    @FindBy(partialLinkText = "Remove All")
    public WebElement removeAllWorkAreasLink;

    @FindBy(css = "select[title='Workareas Available']")
    public WebElement workAreaSelect;

    @FindBy(css = "a[title='Move selected items to other list']")
    public WebElement moveWorkArea;

    // permissions
    @FindBy(css = "table[ id='_id20'] a[title='Remove all items from list']")
    public WebElement removeAllPermissions;

    @FindBy(css = "select[title='Roles Available']")
    public WebElement permissionSelect;

    @FindBy(css = "table[ id='_id20'] a[title='Move selected items to other list']")
    public WebElement movePermission;

    @FindBy(css = "img[src='/ssoadmin/adf/images/cache/en/bSave2FDC.gif']")
    public WebElement saveAuthorisationsButton;

    @FindBy(partialLinkText = "Search")
    public WebElement searchLink;

    /**************** Methods **********************/

    public void setUsername(String strUserName) {

        ssoUserName.sendKeys(strUserName);
    }

    // Set password in password textbox

    public void setPassword(String strPassword) {
        ssoPassword.sendKeys(strPassword);
    }

    // Click on login button

    public void clickDataCheckbox() {
        ssoDataCheckBox.click();
    }

    // Get the title of Login Page

    public void clickLogonButton() {
        ssoLogonButton.click();
    }

    public void loginToSso(String strUserName, String strPasword) {
        // Fill user name
        setUsername(strUserName);
        // Fill password
        setPassword(strPasword);
        // Click Login button
        clickDataCheckbox();
        // Click Login button
        clickLogonButton();
    }

    public void clickOfs() {

        ofsLink.click();
    }

    public void clickRdfs() {
        rdfsLink.click();
    }

    public void clickGlas() {

        glasLink.click();
    }

    public void clickSsoAdminLink() {

        ssoAdmin.click();
    }

    public void listImages() {

    }

    /****************** Admimistrator ***************************************************/

    public void setAdminUsername(String Username) {

        adminUsernameField.sendKeys(Username);
    }

    public void clickSearchUser() {

        searchButton.click();
    }

    public void clickSelectUserRadio() {

        selectUserRadioButton.click();
    }

    public void clickEditUser() {
        editUserButton.click();
    }

    public void clickAuthorisations() {
        authorisationsLink.click();
    }

    public void SelectApplication(String appName) {
        Select dropdown = new Select(applicationSelect);
        dropdown.selectByVisibleText(appName);
    }

    public void clickRemoveAllWorkAreas() throws InterruptedException {
        Thread.sleep(1000);
        removeAllWorkAreasLink.click();
    }

    public void SelectWorkArea(String workArea) {
        Select dropdown = new Select(workAreaSelect);
        dropdown.selectByVisibleText(workArea);
        moveWorkArea.click();
    }

    public void clickRemoveAllPermissions() throws InterruptedException {
        Thread.sleep(1000);
        removeAllPermissions.click();
    }

    public void selectPermission(String permission) {
        Select dropdown = new Select(permissionSelect);
        dropdown.selectByVisibleText(permission);
        movePermission.click();

    }

    public void clicksaveAuthorisations() {
        saveAuthorisationsButton.click();
    }

    public void clickSearchLink() {
        searchLink.click();
    }

}
