package ie.gov.agriculture.agschemes.databasequeries.nitrates;

import java.sql.SQLException;

import ie.gov.agriculture.agschemes.databasequeries.IQuery;
import ie.gov.agriculture.agschemes.databasequeries.QueryBase;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class NTRNitratesProsphatesForStaffQuery extends QueryBase implements IQuery {

    public NTRNitratesProsphatesForStaffQuery(String herdNo, String year, String applicationStatus) {
        super(herdNo, year, applicationStatus);
        buildQuery();
    }

    @Override
    public void buildQuery() {
        query = "Select NTR_PHOSPHATES from TDAG_NITRATES where NTR_CLIENT_ID = '" + herdNo
            + "' and NTR_NITRATES_YEAR ='" + year + "' order by NTR_AUDIT_DATE";

        log.warn("the NTR_PHOSPHATES_query value is " + query);
    }

    @Override
    public String runQuery() throws SQLException {
        stringResult = db.executeQueryReturningString(query);

        log.warn("--------------------------------------------------------------------------------------------------");
        log.warn("the NTR_PHOSPHATES_result value is " + stringResult);
        return stringResult;
    }

}
