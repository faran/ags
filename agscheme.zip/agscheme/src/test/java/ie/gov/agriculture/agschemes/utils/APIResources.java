package ie.gov.agriculture.agschemes.utils;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;

public class APIResources {

    //CAA - create application agent
    //CA - create application

    public String getServiceResource(String serviceResource){
        switch (serviceResource){
            case "SSO_SET_USERTYPE":
                return TestDataHolder
                        .getTestDataRecord(TestDataHolder.BASE_URL)+"/sso-auth-api/auth";
            case "SSO_GET_COOKIE":
                return TestDataHolder
                        .getTestDataRecord(TestDataHolder.BASE_URL)+"/sso-auth-api/protected/authorised-applications";
            case "SSO_LOGIN":
                return TestDataHolder
                        .getTestDataRecord(TestDataHolder.BASE_URL)+"/sso-auth-api/login";
            case "SSO_GET_PAC_API":
                return TestDataHolder
                        .getTestDataRecord(TestDataHolder.BASE_URL)+"/sso-auth-api/get-prompted-pac-digits";
            case "CA_GET_CUST_ID":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/create-application/customer-id";
            case "CA_POST_SUBMIT_APPLICATION":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/create-application/submit-application";
            case "CA_POST_SAVE_DRAFT_APPLICATION":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/create-application/save-draft-application";
            case "CA_POST_UPDATE_DRAFT_APPLICATION":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/create-application/update-application";
            case "DA_DELETE_APPLICATION":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/application/delete-application/confirm";
            case "CA_VIEW_APPLICATION":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/create-application/view-application";
            case "A_NP_ENQUIRY_DETAILS":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/application/np-enquiry-details";
            case "A_QUERY_APPLICATION":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/application/query-application";
            case "RG_REPORT_GENERATE":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/report/generate/?reportName=Nitrates%20Applications%20Status&reportPath=AGSCH/NITRATES/Agent%20Status%20Report.xdo&reportFormat=SPREADSHEET&reportParamArray=i_scheme_year:2021";
            case "ID_UPLOAD_DOCUMENT":
                return ConstantsProvider.getBASE_URL_AG_APPS()+"/agsch-ns-api/internal-document/upload-document";
                default:
                break;
        }
        return null;
    }
}
