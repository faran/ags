package ie.gov.agriculture.agschemes.stepdefinitions.database;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;

public class StartupDatabaseQueriesSteps extends DriverFactory {

    public StartupDatabaseQueriesSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @Given("^business id is active on ccs$")
    public void businessIdIsActiveOnCCS() throws Throwable {
        startupDatabaseQueries
            .assertBusinessIdIsActiveOnCcs(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user deletes application in database")
    public void deleteApplication() throws Throwable {
        startupDatabaseQueries.deleteApplication(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST),
            ConstantsProvider.getHERDYEAR());
    }

    @And("user selects application with no animal and grassland and area of holding data")
    public void selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData() throws Throwable {
        startupDatabaseQueries.selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData();
    }

    @And("user selects application with some animal and grassland and area of holding data")
    public void selectsApplicationWithSomeAnimalAndGrasslandAndAreaOfHoldingData() throws Throwable {
        startupDatabaseQueries.selectsApplicationWithSomeAnimalAndGrasslandAndAreaOfHoldingData();
    }

}
