package ie.gov.agriculture.agschemes.commons;

import lombok.extern.log4j.Log4j2;

/**
 * Environments where tests allowed to run on. Mainly used to facilitate the usage of {@link EnvironmentHandler}
 */
@Log4j2
public class AllowedRoles {

    public static final String ROLE_STAFF = "staff";
    public static final String ROLE_AGENT = "agent";
    public static final String ROLE_INDIVIDUAL = "individual";
}
