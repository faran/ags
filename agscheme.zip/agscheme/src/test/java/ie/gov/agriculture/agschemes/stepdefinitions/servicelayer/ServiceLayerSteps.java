package ie.gov.agriculture.agschemes.stepdefinitions.servicelayer;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.pojo.APIDataBuild;
import ie.gov.agriculture.agschemes.stepdefinitions.database.DataBaseSteps;
import ie.gov.agriculture.agschemes.utils.APIResources;
import ie.gov.agriculture.agschemes.utils.ServiceLayerUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import lombok.extern.log4j.Log4j2;


import javax.ws.rs.core.MediaType;
import java.io.File;
import java.io.FileNotFoundException;

import static ie.gov.agriculture.agschemes.stepdefinitions.database.DataBaseSteps.*;
import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;

@Log4j2
public class ServiceLayerSteps extends ServiceLayerUtils {

   public ServiceLayerSteps(){
       RestAssured.useRelaxedHTTPSValidation();
    }

    RequestSpecification reqSpec;
    Response response;
    String currentYear = ConstantsProvider.getHERDYEAR();
    String year2020 = "2020";

    @Given("user access the {string} BaseUrl")
    public void user_access_the_BaseUrl(String API) throws FileNotFoundException {
        setBaseUrl(API);
        reqSpec = requestSpecification();
    }

    @When("user calls {string} with {string} http request")
    public void user_calls_with_http_request_for_a_given(String API, String requestMethod) {

        APIResources apiResources = new APIResources();
        if (requestMethod.equalsIgnoreCase("POST")) {
            reqSpec =given().spec(reqSpec);
            response =  reqSpec.when().post(apiResources.getServiceResource(API)).then()
                    .spec(responseSpecification()).extract().response();
        }
        else if (requestMethod.equalsIgnoreCase("GET")) {
            reqSpec =given().spec(reqSpec);
            response =  reqSpec.when().get(apiResources.getServiceResource(API)).then()
                    .spec(responseSpecification()).extract().response();
        }

        else if (requestMethod.equalsIgnoreCase("DELETE")) {
            reqSpec =given().spec(reqSpec);
            response = reqSpec.when().delete(apiResources.getServiceResource(API)).then()
                    .spec(responseSpecification()).extract().response();
        }
    }

    @Then("the API call is success with status code {int}")
    public void the_API_call_is_success_with_status_code(int statusCode) {
        assertEquals("StatusCode",statusCode,response.getStatusCode());
    }

    @Then("the status line in response body is {string}")
    public void the_status_line_in_response_body_is(String statusLine) {
        assertEquals("StatusLine",statusLine,response.getStatusLine().trim());
    }

    @Then("the content type of response is {string}")
    public void the_content_type_of_response_is(String contentType) {
        Assert.assertEquals("ContentType",contentType, response.getHeader("Content-Type"));
    }

    @Then("response should be {string}")
    public void assert_response(String message) {
        Assert.assertEquals("Response is not same ",message,response.jsonPath().get("message").toString());
    }

    private String dataA(){
        String dataA = response.jsonPath().get("dataA");
        TestDataHolder.addRecord(TestDataHolder.DATA_A, dataA);
        return dataA;
    }

    @Then("dataA should be received in response")
    public void assert_response_dataA() {
        String pattern = "[A-Z0-9]{16}";
        Assert.assertTrue(response.jsonPath().get("dataA").toString(), dataA().matches(pattern));
    }

    @Then("dataA should match with original dataA")
    public void assert_response_dataA_with_dataA() {
        Assert.assertEquals(response.jsonPath().get("dataA").toString(), TestDataHolder.getRecord(TestDataHolder.DATA_A));
    }

    @Given("the json payload for the {string}")
    public void the_json_payload_for_the_end_point(String endPoint) {
        APIDataBuild apiDataBuild = new APIDataBuild();
        switch (endPoint) {
            case "agentSubmitApplication":
               reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentSubmitApplication());
                break;
            case "staffSubmitApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.staffSubmitApplication());
                break;
            case "staffSaveDraftApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.staffSaveDraftApplication());
                break;
            case "staffSaveDraftApplication2020":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.staffSaveDraftApplication2020());
                break;
            case "agentSaveDraftApplication2020":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentSaveDraftApplication2020());
                break;
            case "staffUpdateDraftApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.staffUpdateDraftApplication());
                break;
            case "agentSaveDraftApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentSaveDraftApplication());
                break;
            case "agentUpdateDraftApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentUpdateDraftApplication());
                break;
            case "agentSubmitDraftApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentSubmitDraftApplication());
                break;
            case "agentDeleteApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentDeleteApplication());
                break;
            case "agentSubmitApplicationForNonClient":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentSubmitApplicationForNonClient());
                break;
            case "agentSaveDraftApplicationForNonClient":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentSaveDraftApplicationForNonClient());
                break;
            case "agentUpdateDraftApplicationForNonClient":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentUpdateDraftApplicationForNonClient());
                break;
            case "agentViewOwnApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentViewOwnApplication());
                break;
            case "agentViewNPDetails":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.agentViewNPDetails());
                break;
            case "staffViewNPDetails":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.staffViewNPDetails());
                break;
            case "queryApplication":
                reqSpec = given().spec(reqSpec)
                        .body(apiDataBuild.queryApplication());
                break;
            case "uploadMapDocumentHerdYear":
                APIDataBuild apiDataBuild1 = new APIDataBuild();
                reqSpec = given().spec(reqSpec)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .multiPart("documentUploaded", new File("src/main/resources/uploadfile.text"), "application/json")
                        .formParams(apiDataBuild1.uploadDocument("Map", "100002", currentYear));
                break;
            case "uploadFarmSketchDocumentHerdYear":
                APIDataBuild apiDataBuild2 = new APIDataBuild();
                reqSpec = given().spec(reqSpec)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .multiPart("documentUploaded", new File("src/main/resources/uploadfile.text"), "application/json")
                        .formParams(apiDataBuild2.uploadDocument("Farm Sketch", "100004", currentYear));
                break;
            case "uploadFarmSketchDocument2020":
                APIDataBuild apiDataBuild5 = new APIDataBuild();
                reqSpec = given().spec(reqSpec)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .multiPart("documentUploaded", new File("src/main/resources/uploadfile.text"), "application/json")
                        .formParams(apiDataBuild5.uploadDocument("Farm Sketch", "100004", year2020));
                break;
            case "uploadFertliserAccountsDocument2020":
                APIDataBuild apiDataBuild3 = new APIDataBuild();
                reqSpec = given().spec(reqSpec)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .multiPart("documentUploaded", new File("src/main/resources/uploadfile.text"), "application/json")
                        .formParams(apiDataBuild3.uploadDocument("Fertiliser Accounts", "195011", year2020));
                break;
            case "uploadFertliserAccountsDocumentHerdYear":
                APIDataBuild apiDataBuild4 = new APIDataBuild();
                reqSpec = given().spec(reqSpec)
                        .contentType(MediaType.MULTIPART_FORM_DATA)
                        .multiPart("documentUploaded", new File("src/main/resources/uploadfile.text"), "application/json")
                        .formParams(apiDataBuild4.uploadDocument("Fertiliser Accounts", "195011", currentYear));
                break;
            default:
                break;
        }
    }

    @Then("^delete application by application id$")
    public void deleteApplicationId(){
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        deleteFromTDAS_DOCUMENTSByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDAS_APPLICATIONSUNDERQUERYByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDASAPPLICATIONSTRACKINGByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDASAPPLICATIONSNITRATESByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDASAPPLICATIONSByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    @And("delete application by application id and year {string}")
    public void deleteApplicationByApplicationIdAndYear(String year) {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), year);
        deleteFromTDAS_DOCUMENTSByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDAS_APPLICATIONSUNDERQUERYByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDASAPPLICATIONSTRACKINGByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDASAPPLICATIONSNITRATESByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
        deleteFromTDASAPPLICATIONSByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

}
