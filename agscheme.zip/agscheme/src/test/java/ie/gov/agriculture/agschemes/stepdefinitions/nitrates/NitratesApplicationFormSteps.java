package ie.gov.agriculture.agschemes.stepdefinitions.nitrates;

import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;

public class NitratesApplicationFormSteps extends DriverFactory {

    public NitratesApplicationFormSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @And("^user enters no data and saves application as draft$")
    public void userCreatesNewApplication() throws Throwable {
        nitratesApplicationFormPage.clickCreateApplicationNoUserInputAndClickSaveAsDraft();
    }

    @And("user enters all valid application and saves application as draft")
    public void userEntersAllValidApplicationAndSavesApplicationAsDraft() throws Throwable {
        nitratesApplicationFormPage.createApplicationEnterValidUserInputAndClickSaveAsDraft(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all valid data into application with no data and saves application as draft")
    public void userEntersAllValidDataIntoApplicationWithNoDataAndSavesApplicationAsDraft()
        throws Throwable {
        nitratesApplicationFormPage.createApplicationWithNoDataEnterValidUserInputAndClickSaveAsDraft(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all valid data into application with some data and saves application as draft")
    public void userEntersAllValidDataIntoApplicationWithSomeDataAndSavesApplicationAsDraft()
        throws Throwable {
        nitratesApplicationFormPage.createApplicationEnterValidUserInputAndClickSaveAsDraft(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all valid data into application with some data and submits application")
    public void userEntersAllValidDataIntoApplicationWithSomeDataAndSubmitsApplication()
        throws Throwable {
        nitratesApplicationFormPage
            .createApplicationEnterValidUserInputForSubmit(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all valid application and cancels application")
    public void userEntersAllValidApplicationAndCancelsApplication() throws Throwable {
        nitratesApplicationFormPage.createApplicationAndClickCancel(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all valid application and submits application")
    public void userEntersAllValidApplicationAndSubmitsApplication() throws Throwable {
        nitratesApplicationFormPage.createApplicationEnterValidUserInputForSubmit(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all valid into application with no data and submits application")
    public void userEntersAllValidIntoApplicationWithNoDataAndSubmitsApplication() throws Throwable {
        // TODO: IMPLEMENT LATER DB unstable
        //No idea why is this here
//         nitratesApplicationFormPage.createApplicationEnterValidUserInputForSubmit(TestDataHolder
//         .getTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result"));
        nitratesApplicationFormPage.createApplicationWithNoDataEnterValidUserInputForSubmit(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    @And("user enters all incorrect data into application and submits application")
    public void userEntersAllInvalidApplicationAndSubmitsApplication() throws Throwable {
        nitratesApplicationFormPage.createApplicationEnterIncorrectUserInputForSubmit(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

}
