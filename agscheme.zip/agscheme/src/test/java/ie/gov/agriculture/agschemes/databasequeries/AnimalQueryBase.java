package ie.gov.agriculture.agschemes.databasequeries;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.utils.DatabaseUtils;

public class AnimalQueryBase {
    protected final DatabaseUtils db;
    protected String query;
    protected String herdNo;
    protected String year;
    protected String applicationStatus;
    protected String animal;
    protected String stringResult;
    protected boolean booleanResult;

    public AnimalQueryBase(String herdNo, String year, String applicationStatus, String animal) {
        this.herdNo = herdNo;
        this.year = year;
        this.applicationStatus = applicationStatus;
        this.animal = animal;
        this.db = new DatabaseUtils(ConstantsProvider.getENVIRONMENT_DEFAULT());
    }

}
