package ie.gov.agriculture.agschemes.browserpages.nitrates;

import org.apache.commons.lang.NotImplementedException;
import org.openqa.selenium.WebDriver;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Log4j2
public class NitratesNAndPDetatailsPageAgent implements INitratesNAndPDetatailsPage {

    protected final WebDriver webDriver;

    @Override
    public void getNAndPEnquiryDetailsPhosphorus() {
        throw new NotImplementedException("Awaiting implementation of INitratesNAndPDetatailsPage for Agent");
    }

}
