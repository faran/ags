package ie.gov.agriculture.agschemes.browserpages.sso;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.paulhammant.ngwebdriver.NgWebDriver;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class SsoAgentPinCodePage {

    private static final String AGENT_AUTH_PIN = "1";
    private JavascriptExecutor javascriptExecutor;
    private WebDriver webDriver;
    private WebDriverWait wait;
    private static NgWebDriver ngwebDriver;

    public SsoAgentPinCodePage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.wait = new WebDriverWait(webDriver, 15);
        webDriver.manage().timeouts().setScriptTimeout(5, TimeUnit.SECONDS);
        if (webDriver instanceof JavascriptExecutor) {
            javascriptExecutor = (JavascriptExecutor) webDriver;
        } else {
            throw new IllegalArgumentException("provided webdriver can't execute " + "js commands");
        }
        ngwebDriver = new NgWebDriver(javascriptExecutor);
    }

    @CacheLookup
    @FindBy(id = "pac1")
    private WebElement pinDigit1;

    @CacheLookup
    @FindBy(id = "pac2")
    private WebElement pinDigit2;

    @CacheLookup
    @FindBy(id = "pac3")
    private WebElement pinDigit3;

    @CacheLookup
    @FindBy(id = "pac4")
    private WebElement pinDigit4;

    @CacheLookup
    @FindBy(id = "pac5")
    private WebElement pinDigit5;

    @CacheLookup
    @FindBy(id = "pac6")
    private WebElement pinDigit6;

    @CacheLookup
    @FindBy(id = "pac7")
    private WebElement pinDigit7;

    @CacheLookup
    @FindBy(id = "authenticatePINCommandButton")
    private WebElement authenicateButton;

    public void enterPinCode() {

        if (pinDigit1.isEnabled()) {
            pinDigit1.sendKeys(AGENT_AUTH_PIN);
        }
        if (pinDigit2.isEnabled()) {
            pinDigit2.sendKeys(AGENT_AUTH_PIN);
        }
        if (pinDigit3.isEnabled()) {
            pinDigit3.sendKeys(AGENT_AUTH_PIN);
        }

        if (pinDigit4.isEnabled()) {
            pinDigit4.sendKeys(AGENT_AUTH_PIN);
        }

        if (pinDigit5.isEnabled()) {
            pinDigit5.sendKeys(AGENT_AUTH_PIN);
        }
        if (pinDigit6.isEnabled()) {
            pinDigit6.sendKeys(AGENT_AUTH_PIN);
        }
        if (pinDigit7.isEnabled()) {
            pinDigit7.sendKeys(AGENT_AUTH_PIN);
        }
        // return this;
    }

    public SsoApplicationsListPage authenicatePIN() {
        // authenicateButton.click();
        return PageFactory.initElements(webDriver, SsoApplicationsListPage.class);
    }
}
