package ie.gov.agriculture.agschemes.stepdefinitions.nitrates;

import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class NitratesDocumentManagerPageSteps extends DriverFactory {

    public NitratesDocumentManagerPageSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @Then("assert soil sample option is visible on document manager")
    public void assertSoilSampleOptionIsVisibleOnDocumentManager() {
        nitratesDocumentManagerPage.validateSoilSampleIsDisplayed();
    }

    @Then("assert all documents option is visible on document manager")
    public void assertAllDocumentsOptionIsVisibleOnDocumentManager() {
        nitratesDocumentManagerPage.assertFileUploadFertiliserAccount();
    }

    @And("assert soil sample file is uploaded on document manager")
    public void assertSoilSampleOptionFileIsUploadedOnDocumentManager(){
        nitratesDocumentManagerPage.uploadFile();
        nitratesDocumentManagerPage.assertFileUploaded();
    }

}
