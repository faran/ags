package ie.gov.agriculture.agschemes.browserpages.sso;

import static org.assertj.core.api.Assertions.assertThat;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class SsoLandingPage {

    private final WebDriver webDriver;

    @FindBy(id = "application-list-title")
    private WebElement labelAuthorisedApplications;

    @FindBy(xpath = "//a[contains(text(),'AgSchemes')]")
    private WebElement nitratesDerogationSystemLink;

    @FindBy(xpath = "//a[contains(text(),'Organic Farming')]")
    private WebElement ofsSystemLink;

    public void validateDafmDetails() {
        assertThat(BrowserUtils.getText(webDriver, labelAuthorisedApplications) != null);
    }

    public void clickNitratesDerogationSystemLink() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, nitratesDerogationSystemLink);
    }

    public void clickOfsSystemLink() {
        BrowserUtils.waitForAngular5Load(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, ofsSystemLink);
    }

}
