package ie.gov.agriculture.agschemes.browserpages.nitrates;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@RequiredArgsConstructor
@Log4j2
public class NitratesNAndPDetatailsPageStaff implements INitratesNAndPDetatailsPage {

    protected final WebDriver webDriver;

    @FindBy(xpath = "(//*[@class='mat-cell cdk-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[1]")
    private WebElement phosphorusRowOneStaff;

    @FindBy(xpath = "(//*[@class='mat-cell cdk-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[2]")
    private WebElement phosphorusRowTwoStaff;

    @FindBy(xpath = "(//*[@class='mat-cell cdk-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[3]")
    private WebElement phosphorusRowThreeStaff;

    @FindBy(xpath = "(//*[@class='mat-cell cdk-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[4]")
    private WebElement phosphorusRowFourStaff;

    @FindBy(xpath = "(//*[@class='mat-cell cdk-cell cdk-column-phosphorusTotal mat-column-phosphorusTotal ng-star-inserted'])[5]")
    private WebElement phosphorusRowFiveStaff;

    @Override
    public void getNAndPEnquiryDetailsPhosphorus() {

        String phosphorusRowOneStaffValue = BrowserUtils.getText(webDriver, phosphorusRowOneStaff);
        log.warn("phosphorusRowOneStaffValue " + phosphorusRowOneStaffValue);
        // Set key for checking database for comparing with ui
        TestDataHolder.addRecord(TestDataHolder.PHOSPHORUS_ROW_ONE_STAFF_VALUE, phosphorusRowOneStaffValue);
        log.warn("phosphorusRowOneStaffValue "
            + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_ONE_STAFF_VALUE));

        log.warn("---------------------------------------------------------------------------------");

        //Code commented as more values become available for year 2021 we can enable the below code accordingly.

//        String phosphorusRowTwoStaffValue = BrowserUtils.getText(webDriver, phosphorusRowTwoStaff);
//        log.warn("phosphorusRowTwoStaffValue " + phosphorusRowTwoStaffValue);
//        // Set key for checking database for comparing with ui
//        TestDataHolder.addRecord(TestDataHolder.PHOSPHORUS_ROW_TWO_STAFF_VALUE, phosphorusRowTwoStaffValue);
//        log.warn("phosphorusRowTwoStaffValue "
//            + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_TWO_STAFF_VALUE));
//
//        log.warn("---------------------------------------------------------------------------------");
//
//        String phosphorusRowThreeStaffValue = BrowserUtils.getText(webDriver, phosphorusRowThreeStaff);
//        log.warn("phosphorusRowThreeStaffValue " + phosphorusRowThreeStaffValue);
//        // Set key for checking database for comparing with ui
//        TestDataHolder.addRecord(TestDataHolder.PHOSPHORUS_ROW_THREE_STAFF_VALUE, phosphorusRowThreeStaffValue);
//        log.warn("phosphorusRowThreeStaffValue "
//            + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_THREE_STAFF_VALUE));
//
//        log.warn("---------------------------------------------------------------------------------");
//
//        String phosphorusRowFourStaffValue = BrowserUtils.getText(webDriver, phosphorusRowFourStaff);
//        log.warn("phosphorusRowFourStaffValue " + phosphorusRowFourStaffValue);
//        // Set key for checking database for comparing with ui
//        TestDataHolder.addRecord(TestDataHolder.PHOSPHORUS_ROW_FOUR_STAFF_VALUE, phosphorusRowFourStaffValue);
//        log.warn("phosphorusRowFourStaffValue "
//            + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FOUR_STAFF_VALUE));
//
//        log.warn("---------------------------------------------------------------------------------");
//
//        String phosphorusRowFiveStaffValue = BrowserUtils.getText(webDriver, phosphorusRowFiveStaff);
//        log.warn("phosphorusRowFiveStaffValue " + phosphorusRowFiveStaffValue);
//        // Set key for checking database for comparing with ui
//        TestDataHolder.addRecord(TestDataHolder.PHOSPHORUS_ROW_FIVE_STAFF_VALUE, phosphorusRowFiveStaffValue);
//        log.warn("phosphorusRowFiveStaffValue "
//            + TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FIVE_STAFF_VALUE));
//
//        log.warn("---------------------------------------------------------------------------------");

    }

}