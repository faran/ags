package ie.gov.agriculture.agschemes.databasequeries.nitrates.apn;

import ie.gov.agriculture.agschemes.commons.EnvironmentHandler;
import lombok.extern.log4j.Log4j2;

/**
 * Environments where tests allowed to run on. Mainly used to facilitate the usage of {@link EnvironmentHandler}
 */
@Log4j2
public class NitratesColumns {

    public static final String APN_BDMEASURE_CUT_HEDGROW_ID = "APN_BDMEASURE_CUT_HEDGROW_ID";
    public static final String APN_TRAINING_GRASSLAND_IND = "APN_TRAINING_GRASSLAND_IND";
    public static final String APN_TRAINING_ENVIRONMENTAL_IND = "APN_TRAINING_ENVIRONMENTAL_IND";
    public static final String APN_BDMEASURE_MAINTAIN_HROW_ID = "APN_BDMEASURE_MAINTAIN_HROW_ID";
    public static final String APN_BDMEASURE_WBTHORN_TRLFT_ID = "APN_BDMEASURE_WBTHORN_TRLFT_ID";
    public static final String APN_TERMS_CONDITIONS_IND = "APN_TERMS_CONDITIONS_IND";
    public static final String ST_STATUS_DESCRIPTION = "ST_STATUS_DESCRIPTION";
    public static final String APP_CURRENT_BUSINESS_ID = "APP_CURRENT_BUSINESS_ID";
}
