package ie.gov.agriculture.agschemes.databasequeries.nitrates;

import java.sql.SQLException;

import ie.gov.agriculture.agschemes.databasequeries.IQuery;
import ie.gov.agriculture.agschemes.databasequeries.QueryBase;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class CheckDatabaseIsNotNullQuery extends QueryBase implements IQuery {

    public CheckDatabaseIsNotNullQuery(String herdNo, String year, String applicationStatus) {
        super(herdNo, year, applicationStatus);
    }

    @Override
    public void buildQuery() {
        // not used by this class
    }

    @Override
    public String runQuery() throws SQLException {
        // Random query to check the database is not null before it continues

        log.warn("CHECKING NOT NULL ... ");
        String query = "select APN_NET_AREA_OF_HOLDING from tdas_applications, tdas_applications_nitrates, tsas_status where app_current_business_id = '"
            + herdNo + "' and APP_SCHEME_YEAR='" + year + "' and ST_STATUS_DESCRIPTION = '" + applicationStatus
            + "' order by APN_AUDIT_DATE desc";
        log.warn("CHECKING NOT NULL the APN_NET_AREA_OF_HOLDING_query value is " + query);
        booleanResult = db.executeQueryCheckIfTableExists(query);

        log.warn("CHECKING NOT NULL the APN_NET_AREA_OF_HOLDING_query value is " + query);
        log.warn("CHECKING NOT NULL the APN_NET_AREA_OF_HOLDING_result value is " + stringResult);

        log.warn("RETURNING VALUE FOR DATABASE NOT NULL METHOD ... " + stringResult);
        return stringResult;
    }

    public boolean getBooleanResult() {
        return booleanResult;
    }

}
