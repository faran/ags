package ie.gov.agriculture.agschemes.utils;

import java.util.List;
import lombok.extern.log4j.Log4j2;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.Select;

/**
 * Represents {@link org.openqa.selenium.support.ui.ExpectedConditions} for {@link
 * org.openqa.selenium.WebElement} which loads slowly to the UI. As an example in ISmart the
 * drop-down (aka {@link org.openqa.selenium.support.ui.Select}) first loads as text field in the
 * form of TextInput then updates to drop-down
 */
@Log4j2
public class
ExpectedConditionsLazyWebElement {

  /**
   * Espicially useful for lazy loading select elements
   *
   * @return ExpectedCondition when the web element is visible with expected tag name.
   */
  public static ExpectedCondition<WebElement> visibilityOf(final WebElement element,
      final String expectedTagName) {
    return driver -> {
      if (element.isDisplayed() && (element.getTagName().equals(expectedTagName))) {
        return element;
      } else {
        return null;
      }
    };
  }

  public static ExpectedCondition<WebElement> visibilityOfElementLocatedBy(final By locator,
      final String expectedTagName) {
    return driver -> {
      WebElement element;
      try {
        element = driver.findElement(locator);
      } catch (NoSuchElementException nse) {
        return null;
      }
      if (element.isDisplayed() && (element.getTagName().equals(expectedTagName))) {
        return element;
      } else {
        return null;
      }
    };
  }

  /**
   * @param locator for the select element
   * @return ExpectedCondition usable when waiting for a select element till: <ol> <li>available inthe
   * DOM</li> <li>visible and has tag 'select'</li> <li>has more than 2 elements</li> </ol>
   */
  public static ExpectedCondition<Select> readinessOfSelectElementLocatedBy(final By locator) {
    return webDriver -> {
      Select selectElement = null;
      WebElement element;
      try {
        element = webDriver.findElement(locator);
      } catch (NoSuchElementException nse) {
        return null;
      }
      try {
        if (element.isDisplayed() && (element.getTagName().equals("select"))) {
          selectElement = new Select(element);
          List<WebElement> options = selectElement.getOptions();
          if (options.size() > 1) {
            options.forEach(option -> log.debug("option found" + option.getText()));
            return selectElement;
          } else {
            return null;
          }
        } else {
          return null;
        }
      } catch (StaleElementReferenceException ser) {
        return null;
      }
    };
  }

}

