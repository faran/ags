package ie.gov.agriculture.agschemes.commons;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import com.google.common.base.Strings;

import lombok.Getter;
import lombok.extern.log4j.Log4j2;

/**
 * Keeps track of test data throughout the test session. This has two main uses: the first is to share the data between
 * the steps and the other is to make test data relevant for each test scenario available for the test report.
 *
 * @author youssef.abdalla
 */
@Log4j2
public class TestDataHolder {

    public static final String ENVIRONMENT = "ENVIRONMENT";
    public static final String ZEPHYR_TEST_ID = "ZEPHYR_TEST_ID";
    public static final String HERD_UNDER_TEST = "HERD_UNDER_TEST";
    public static final String USERTYPE_UNDER_TEST = "USERTYPE_UNDER_TEST";
    public static final String USER_UNDER_TEST = "USER_UNDER_TEST";
    public static final String ESTIMATED_NITROGEN_SPREAD_AGENT = "ESTIMATED_NITROGEN_SPREAD_AGENT";
    public static final String PHOSPHORUS_ROW_ONE_STAFF_VALUE = "PHOSPHORUS_ROW_ONE_STAFF_VALUE";
    public static final String PHOSPHORUS_ROW_TWO_STAFF_VALUE = "PHOSPHORUS_ROW_TWO_STAFF_VALUE";
    public static final String PHOSPHORUS_ROW_THREE_STAFF_VALUE = "PHOSPHORUS_ROW_THREE_STAFF_VALUE";
    public static final String PHOSPHORUS_ROW_FOUR_STAFF_VALUE = "PHOSPHORUS_ROW_FOUR_STAFF_VALUE";
    public static final String PHOSPHORUS_ROW_FIVE_STAFF_VALUE = "PHOSPHORUS_ROW_FIVE_STAFF_VALUE";
    public static final String STORAGE_PERIOD_DROPDOWN_FIRST_OPTION = "STORAGE_PERIOD_DROPDOWN_FIRST_OPTION";
    public static final String ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = "ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE";
    public static final String CUSTOMER_BUSINESS_ID_STAFF_VALUE = "CUSTOMER_BUSINESS_ID_STAFF_VALUE";
    public static final String CUSTOMER_START_DATE_STAFF_VALUE = "CUSTOMER_START_DATE_STAFF_VALUE";
    public static final String CUSTOMER_BUSINESS_ID_AGENT_VALUE = "CUSTOMER_BUSINESS_ID_AGENT_VALUE";
    public static final String CUSTOMER_START_DATE_AGENT_VALUE = "CUSTOMER_START_DATE_AGENT_VALUE";
    public static final String BASE_URL = "BASE_URL";
    public static final String DATA_A = "DATA_A";
    public static final String DATA_B = "DATA_B";

    /** TDAS_APPLICATIONS */
    public static final String APP_APPLICATION_ID = "APP_APPLICATION_ID";
    public static final String APP_APPLICATION_CODE = "APP_APPLICATION_CODE";
    public static final String APP_CURRENT_BUSINESS_ID = "APP_CURRENT_BUSINESS_ID";
    public static final String APP_SCHEME_YEAR = "APP_SCHEME_YEAR";
    public static final String APP_CURRENT_STATUS_CODE = "APP_CURRENT_STATUS_CODE";
    public static final String APP_OWNER_BUSINESS_ID = "APP_OWNER_BUSINESS_ID";
    public static final String APP_IS_PARTNERSHIP = "APP_IS_PARTNERSHIP";
    public static final String APP_CURRENT_DATE_OF_APPLIC = "APP_CURRENT_DATE_OF_APPLIC";
    public static final String APP_AUDIT_USERID = "APP_AUDIT_USERID";

    /** TSAS_STATUS */
    public static final String ST_STATUS_CODE = "ST_STATUS_CODE";
    public static final String ST_STATUS_DESCRIPTION = "ST_STATUS_DESCRIPTION";
    public static final String ST_SCREEN_DISPLAY = "ST_SCREEN_DISPLAY";
    public static final String ST_AUDIT_USER = "ST_AUDIT_USER";
    public static final String ST_AUDIT_DATE = "ST_AUDIT_DATE";

    /** TDAS_APPLICATIONS_NITRATES */
    public static final String APN_APPLICATION_ID = "APN_APPLICATION_ID";
    public static final String APN_NET_AREA_OF_HOLDING = "APN_NET_AREA_OF_HOLDING";
    public static final String APN_NET_GRASSLAND = "APN_NET_GRASSLAND";
    public static final String APN_CATTLE = "APN_CATTLE";
    public static final String APN_SHEEP = "APN_SHEEP";
    public static final String APN_PIGS = "APN_PIGS";
    public static final String APN_HORSES = "APN_HORSES";
    public static final String APN_GOATS = "APN_GOATS";
    public static final String APN_DEER = "APN_DEER";
    public static final String APN_GRASS_LAND_PERCENT = "APN_GRASS_LAND_PERCENT";
    public static final String APN_TRAINING_ENVIRONMENTAL_IND = "APN_TRAINING_ENVIRONMENTAL_IND";
    public static final String APN_AUDIT_USER = "APN_AUDIT_USER";
    public static final String APN_BDMEASURE_MAINTAIN_HROW_ID = "APN_BDMEASURE_MAINTAIN_HROW_ID";
    public static final String APN_BDMEASURE_WBTHORN_TRLFT_ID = "APN_BDMEASURE_WBTHORN_TRLFT_ID";
    public static final String APN_TERMS_CONDITIONS_IND = "APN_TERMS_CONDITIONS_IND";
    public static final String APN_STORAGE_PERIOD = "APN_STORAGE_PERIOD";
    public static final String APN_AHCS_MANUAL_RECORDING_IND = "APN_AHCS_MANUAL_RECORDING_IND";
    public static final String APN_BPS_MANUAL_RECORDING_IND = "APN_BPS_MANUAL_RECORDING_IND";
    public static final String APN_NITROGEN_APPLIED = "APN_NITROGEN_APPLIED";
    public static final String APN_BDMEASURE_CUT_HEDGROW_ID = "APN_BDMEASURE_CUT_HEDGROW_ID";
    public static final String APN_AMOUNT_SLURRY_SPREAD = "APN_AMOUNT_SLURRY_SPREAD";
    public static final String APN_TRAINING_GRASSLAND_IND = "APN_TRAINING_GRASSLAND_IND";

    /** VWCO_AGSCH_BUSINESS_CUSTOMERS */
    public static final String CUSTOMER_ID = "CUSTOMER_ID";
    public static final String BUSINESS_ID = "BUSINESS_ID";
    public static final String START_DATE = "START_DATE";

    /**TDAS_APPLICATION_UNDER_QUERY*/
    public static final String APD_DOCUMENT_TYPE = "APD_DOCUMENT_TYPE";
    public static final String APD_DOCUMENT_YEAR = "APD_DOCUMENT_YEAR";
    public static final String APD_USER_COMMENT = "APD_USER_COMMENT";
    public static final String APD_AUDIT_DATE = "APD_AUDIT_DATE";
    public static final String APD_APPLICATION_TRACKING_ID = "APD_APPLICATION_TRACKING_ID";


    /*** Query Results Holders */
    public static final String ANIMALS_ON_HOLDING_CHECK_DB = "animalsOnHoldingCheckDb";
    public static final String VERIFY_ELIGIBLE_AREA_OF_GRASSLAND_DB = "verifyEligibleAreaOfGrasslandDb";
    public static final String ANIMALS_ON_HOLDING_CHECK_COWDB = "animalsOnHoldingCheckCowDb";
    public static final String ELIGIBLE_AREA_OF_HOLDING_CHECKDB = "EligibleAreaOfHoldingCheckDb";
    public static final String VERIFY_ELIGIBLE_AREA_OF_GRASSLAND = "verifyEligibleAreaOfGrassland";

    public static final String ELIGIBLE_AREA_OF_HOLDING_CHECK = "EligibleAreaOfHoldingCheck";
    public static final String ESTIMATED_NITROGEN_SPREAD = "estimatedNitrogenSpread";

    /**Values coming back from UI*/
    public static final String ELIGIBLE_AREA_OF_HOLDING_CHECK_VALUE = "eligibleAreaOfHoldingCheckValue";
    public static final String ANIMALS_ON_HOLDING_CHECK_VALUE = "animalsOnHoldingCheckValue";
    public static final String ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE = "eligibleAreaOfGrasslandCheckValue";
    public static final String ANIMALS_ON_HOLDING_CHECK_AGENT_VALUE = "animalsOnHoldingCheckAgentValue";
    public static final String ELIGIBLE_AREA_OF_GRASSLAND_CHECK_AGENT_VALUE = "eligibleAreaOfGrasslandCheckAgentValue";
    public static final String ELIGIBLE_AREA_OF_HOLDING_CHECK_AGENT_VALUE = "eligibleAreaOfHoldingCheckAgentValue";

    /**TDAS_DOCUMENT*/
    public static final String DOC_DOCUMENT_ID = "DOC_DOCUMENT_ID";


    @Getter
    private static Map<String, String> testDataMap;
    private static Map<String, ArrayList<String>> testDataMapArry;

    public static String getTestDataRecord(String key) {
        if (testDataMap == null) {
            initDataMap();
        }
        log.debug("getting the value for the key " + key);
        String record = testDataMap.get(key);
        if (key.equals(ENVIRONMENT) && Strings.isNullOrEmpty(record)) {
            TestDataHolder.addTestDataRecord(TestDataHolder.ENVIRONMENT, EnvironmentHandler.getEnvironmentForTest(),
                true, true);
            record = testDataMap.get(key);
        } else if (record == null) {
            log.debug("no record found for " + key + " . Returning empty string instead...");
            record = "";
        }

        log.debug("record: " + key + " = " + record);
        return record;
    }

    private static void initDataMap() {
        testDataMap = new HashMap<>();
    }

    public static void addRecord(String key, String value) {
        addTestDataRecord(key, value, true, true);
    }

    public static String getRecord(String key) {
        return getTestDataRecord(key);
    }

    /**
     * only adds record if the key is not found in #testDataMap or if the key is found but the value is null
     *
     * @param key
     *            for the data record. preferably one of the static fields.
     * @param value
     *            to be stored as String
     */
    public static void addTestDataRecord(String key, String value, boolean resetValuesIfAlreadyRecorded,
        boolean printValueInLog) {
        if (testDataMap == null) {
            initDataMap();
        }
        if (resetValuesIfAlreadyRecorded) {
            testDataMap.remove(key);
        }
        final boolean isKeyRecordedBefore = testDataMap.containsKey(key);
        if (isKeyRecordedBefore) {
            if (!Strings.isNullOrEmpty(testDataMap.get(key))) {
                key = key + "_i";
            }
        }
        if (printValueInLog) {
            log.debug("recording the test data key: " + key + " with the value: " + value);
        }
        testDataMap.put(key, value);
        if (key.equals(TestDataHolder.ENVIRONMENT)) {
            TestEnvironmentDataHolder.addTestEnvironment(value.toUpperCase());
        }
    }

    public static void appendTestDataRecordWithPipe(String key, String value, boolean printValueInLog) {
        if (testDataMap == null) {
            initDataMap();
        }
        final boolean isKeyRecordedBefore = testDataMap.containsKey(key);
        if (isKeyRecordedBefore) {
            if (!Strings.isNullOrEmpty(testDataMap.get(key))) {
                key = key + "_i";
            }
        }
        if (printValueInLog) {
            log.debug("recording the test data key: " + key + " with the value: " + value);
        }

        String existingRecord = getTestDataRecord(key);

        testDataMap.put(key, value + "|" + existingRecord);
        if (key.equals(TestDataHolder.ENVIRONMENT)) {
            TestEnvironmentDataHolder.addTestEnvironment(value.toUpperCase());
        }
    }

    public void fileOutWrite(ArrayList<String> array) {
        File fileName = new File("data.txt");
        try {
            FileWriter fw = new FileWriter(fileName);
            Writer output = new BufferedWriter(fw);
            int numEntries = array.size();
            for (int i = 0; i < numEntries; i++) {
                output.write(array.get(i).toString() + "\n");
            }
            output.close();
        } catch (Exception e) {
            System.out.println("File cannot be created");
        }
    }

    public ArrayList<String> fileInRead() {
        ArrayList<String> array = new ArrayList<>();
        String line;
        try {
            BufferedReader input = new BufferedReader(new FileReader("data.txt"));
            if (!input.ready()) {
                throw new IOException();
            }
            while ((line = input.readLine()) != null) {
                array.add(new String(line));
            }
            input.close();
        } catch (IOException e) {

        }
        array.forEach(System.out::println); // Java8
        return array;
    }

    /**
     * reset a specific key in the map
     */
    public static void resetTestDataRecord(String key) {
        if (testDataMap.containsKey(key)) {
            testDataMap.remove(key);
        } else {
            log.debug("nothing to remove..");
        }
    }

    public static void resetAllDataValues() {
        testDataMap = null;
    }

    public static List<String> getTestDataRecordWithKeyStartsWith(String keyPrefix) {
        if (testDataMap == null) {
            initDataMap();
        }
        log.debug("getting the values for the keys starting with" + keyPrefix);
        Set<String> keysStartsWithKeyPrefixSet = testDataMap.keySet().stream().filter(k -> k.startsWith(keyPrefix))
            .collect(Collectors.toSet());

        return keysStartsWithKeyPrefixSet.stream().map(k -> {
            String v = testDataMap.get(k);
            if (v == null) {
                return "";
            }
            return v;
        }).collect(Collectors.toList());
    }

    public static void addTestDataArryRecord(String key, ArrayList<String> values, boolean resetValuesIfAlreadyRecorded,
        boolean printValueInLog) {
        if (testDataMapArry == null) {
            initDataMap();
        }
        if (resetValuesIfAlreadyRecorded) {
            testDataMapArry.remove(key);
        }
        final boolean isKeyRecordedBefore = testDataMapArry.containsKey(key);
        if (isKeyRecordedBefore) {
            if (values.isEmpty()) {
                key = key + "_i";
            }
        }
        if (printValueInLog) {
            log.debug("recording the test data key: " + key + " with the value: " + values);
        }
        testDataMapArry.put(key, values);

    }

    public static ArrayList<String> getTestDataArryRecord(String key) {
        if (testDataMapArry == null) {
            initDataMap();
        }
        log.debug("getting the value for the key " + key);
        ArrayList<String> record = testDataMapArry.get(key);
        if (key.equals(ENVIRONMENT) && record.isEmpty()) {
            TestDataHolder.addTestDataRecord(TestDataHolder.ENVIRONMENT, EnvironmentHandler.getEnvironmentForTest(),
                true, true);
            record = testDataMapArry.get(key);
        } else if (record == null) {
            log.debug("no record found for " + key + " . Returning empty string instead...");
            record = null;
        }

        log.debug("record: " + key + " = " + record);
        return record;
    }
}
