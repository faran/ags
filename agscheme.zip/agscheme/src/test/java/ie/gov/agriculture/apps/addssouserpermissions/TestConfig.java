package ie.gov.agriculture.apps.addssouserpermissions;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import lombok.extern.log4j.Log4j2;

//This class helps to set Urls and passwords for different Environments/usertypes.
@Log4j2
public class TestConfig {

    public static String environment = ConstantsProvider.getENVIRONMENT_DEFAULT();

    public static String setEnvPassWord() {
        if (environment.toLowerCase().equals("centest")) {
            String envPassword;
            envPassword = "@c3ntst678!!";
            log.debug("password is :  " + envPassword);
            return envPassword;

        } else if (environment.toLowerCase().equals("prelive")) {
            String envPassword;
            envPassword = "@pr3lv3246!!";
            log.debug("password is :  " + envPassword);
            return envPassword;

        } else if (environment.toLowerCase().equals("uat")) {
            String envPassword;
            envPassword = "@u@tpw369!!";
            log.debug("password is :  " + envPassword);
            return envPassword;

        } else if (environment.toLowerCase().equals("dev")) {
            String envPassword;
            envPassword = "@d3vpw4812!!";
            log.debug("password is :  " + envPassword);
            return envPassword;

        } else {
            System.out.println("Error in TestConfig, environment not found");
            return "x";
        }

    }

    public static String setSsoUrl(String usertype) {

        String urlEnv = "error";
        String urlUserType = "error";

        if (environment.equals("centest")) {

            urlEnv = "centest";

        } else if (environment.equals("prelive")) {

            urlEnv = "prelive";

        } else if (environment.equals("uat")) {

            urlEnv = "uat";

        } else if (environment.equals("dev")) {

            urlEnv = "dev";

        } else {
            System.out.println("Error in TestConfig, environment not found");
        }

        // new If statement to set user part of URL

        if (usertype.equals("individual")) {

            urlUserType = "individual";

        } else if (usertype.equals("staff")) {

            urlUserType = "staff";

        } else if (usertype.equals("partner")) {

            urlUserType = "partner";

        } else if (usertype.equals("agent")) {

            urlUserType = "agent";

        } else {
            System.out.println("Error in TestConfig, URL User Type not found");
        }

        return "https://agapps." + urlEnv + ".agriculture.gov.ie/ssoauth/" + urlUserType + ".jsp";
    }

    public static String getEnvironment() {
        return environment;
    }

}
