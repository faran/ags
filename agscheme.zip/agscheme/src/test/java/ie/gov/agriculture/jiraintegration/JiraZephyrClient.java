package ie.gov.agriculture.jiraintegration;

import static io.restassured.RestAssured.basic;

import java.net.URI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.junit.Assume;

import com.atlassian.jira.rest.client.api.JiraRestClient;
import com.atlassian.jira.rest.client.api.domain.BasicProject;
import com.atlassian.jira.rest.client.api.domain.Issue;
import com.atlassian.jira.rest.client.internal.async.AsynchronousJiraRestClientFactory;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import io.atlassian.util.concurrent.Promise;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import lombok.Getter;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;

/**
 * Jira and ZAPI client to create test executions with correct status in the
 * correct cycle. All methods interacting with ZEPHYR assumes that ZAPI plugin
 * is installed on the JIRA server. If not they will fail.
 *
 * @author youssef.abdalla
 */
@Log4j2
public class JiraZephyrClient implements AutoCloseable {

	private String userName;
	private String password;
	@Getter
	private JiraRestClient jiraRestClient;

	/**
	 * All other parameters are read from the file constants.properties using
	 * {@link ConstantsProvider}
	 *
	 * @param userName is the normal Jira user name
	 * @param password is the normal Jira password
	 */
	public JiraZephyrClient(String userName, String password) {
		this(URI.create(ConstantsProvider.getJIRA_URL()), ConstantsProvider.getZAPI_PATH(), userName, password);
	}

	/**
	 * @param jiraUri  in DAFM's case this is: https://jira.agriculture.gov .ie/jira
	 * @param zapiPath the installation path of the ZAPI Plugin for Jira. DAFM's
	 *                 Case this is: /rest/zapi/latest
	 * @param userName is the normal Jira user name
	 * @param password is the normal Jira password
	 */
	public JiraZephyrClient(@NonNull URI jiraUri, @NonNull String zapiPath, @NonNull String userName,
			@NonNull String password) {
		log.debug("set jira url to: " + jiraUri.toString());
		log.debug("set jira username to: " + userName);// and password to: " + "" + password);
		this.userName = userName;
		this.password = password;
		jiraRestClient = new AsynchronousJiraRestClientFactory().createWithBasicHttpAuthentication(jiraUri, userName,
				password);
		RestAssured.baseURI = jiraUri.toString() + zapiPath;
		RestAssured.authentication = basic(userName, password);
	}

	/**
	 * @see #createNewExecution(String, String, String, String, String, String)
	 */
	public String createNewExecution(String cycleId, String issueId, String projectId) {
		// default value for cycleId (Ad Hoc), versionId (unscheduled),
		// folderId.
		String cycleAndVersionDefaultValue = getExecutionCycleByProjectIdAndCycleNames("14747",ConstantsProvider.getTEST_CYCLE_NAME());;
		String folderId = ConstantsProvider.getTEST_CYCLE_NAME();
		String assigneeDefaultValue = "bamboo.zephyr.agsch";
		return createNewExecution(cycleId, issueId, projectId, cycleAndVersionDefaultValue, assigneeDefaultValue,
				folderId);
	}

	/**
	 * Creates a new execution. The status of the execution after this call will be
	 * 'Not Executed'.<br>
	 * All parameters have to be supplied as non null Strings except folderId
	 *
	 * @param cycleId   Zephyr cycle id as per
	 *                  {@link #getExecutionCycleByProjectIdAndCycleNames(String, String)}
	 *                  or "-1" for the 'AD HOC' cycle
	 * @param issueId   is the JIRA issue id as String returned from
	 *                  {@link Issue#getId()} where the {@link Issue} can be found
	 *                  by calling {@link #findIssue(String)}
	 * @param projectId is the JIRA project id as String returned from
	 *                  {@link BasicProject#getId()} where the {@link BasicProject}
	 *                  can be found by calling {@link Issue#getProject()}
	 * @param versionId is the JIRA Version Id as String or -1 for 'Unschedualed'
	 *                  the later is the most used value in DAFM
	 * @param assignee  name
	 * @param folderId  or '-1' if non
	 * @return the id of the newly created execution ready for use in future calls
	 */
	public String createNewExecution(@NonNull String cycleId, @NonNull String issueId, @NonNull String projectId,
			@NonNull String versionId, @NonNull String assignee, String folderId) {
		JSONObject jsonPayload = new JSONObject();
		jsonPayload.put("cycleId", cycleId);
		jsonPayload.put("issueId", issueId);
		jsonPayload.put("projectId", projectId);
		jsonPayload.put("versionId", versionId);
		jsonPayload.put("assigneeType", "assignee");
		jsonPayload.put("assignee", assignee);
		jsonPayload.put("folderId", folderId);
		final String executionTargetUrlString = "/execution";
		Response response = RestAssured.with().auth().preemptive().basic(userName, password)
				.contentType(ContentType.JSON).body(jsonPayload.toString()).post(executionTargetUrlString);

		new JSONObject(response.asString());
		String executionId = new JSONObject(response.asString()).keys().next();
		log.debug("execution created with the ID: " + executionId);
		return executionId;
	}

	/**
	 * @param projectId        is the JIRA project id as String returned from
	 *                         {@link BasicProject#getId()} where the
	 *                         {@link BasicProject} can be found by calling
	 *                         {@link Issue#getProject()}
	 * @param partialCycleName as displayed in ZEPHYR UI
	 * @return id of execution cycle ready for use in future calls
	 */
	public String getExecutionCycleByProjectIdAndCycleNames(String projectId, String partialCycleName) {
		String cycleTarget = "/cycle";
		String cycleKey = null;

		Response response = RestAssured.with().auth().preemptive().basic(userName, password)
				.contentType(ContentType.JSON).param("projectId", projectId).get(cycleTarget);

		log.info("-JSON response:" + response.toString());
		log.info("-JIRA JSON Object: " + response.asString());

		JSONObject searchCyclesJsonResponseObject = new JSONObject(response.asString());

		// used to retrieve parent level JSONArray keys from /cycles response to allow
		// iteration through all cycle folders
		JsonElement jsonElement = new JsonParser().parse(response.asString());
		List<String> listOfParentLevelkeys = getCycleReleaseParentLevelKeys(jsonElement, "");
		log.info("JSON Parent Level Cycle Keys = " + listOfParentLevelkeys);

		for (String keysString : listOfParentLevelkeys) {
			// updated .getJSONArray("X")... to dynamically select from uniquely generated
			// parent level JSON Keys
			// e.g. JSONARRAY -1 = unscheduled - JSONARRAY 28656 = sprint 2
			JSONObject allCyclesJSON = searchCyclesJsonResponseObject.getJSONArray(keysString).getJSONObject(0);
			Iterator<String> keysIterator = allCyclesJSON.keys();
			log.info("searching keys for JSON Object containing  partialCycleName: " + partialCycleName);

			while (keysIterator.hasNext()) {
				String key = keysIterator.next();
				JSONObject currentJSONObject = allCyclesJSON.optJSONObject(key);

				if (currentJSONObject != null
						&& StringUtils.containsIgnoreCase(currentJSONObject.getString("name"), partialCycleName)) {
					log.info("cycle key: " + key);
					cycleKey = key;
				}
			}
		}
		return cycleKey;
	}

	public static List<String> getCycleReleaseParentLevelKeys(final JsonElement jsonElement, final String prefix) {
		List<String> keys = new ArrayList<>();
		if (jsonElement.isJsonObject()) {
			com.google.gson.JsonObject jObj = jsonElement.getAsJsonObject();
			for (Map.Entry<String, JsonElement> entry : jObj.entrySet()) {
				JsonElement value = entry.getValue();
				String newPrefix = prefix + entry.getKey();

				if (value.isJsonArray()) {
					keys.add(newPrefix);
					keys.addAll(getCycleReleaseParentLevelKeys(value, newPrefix + "_"));
				}
			}
		} else {
			com.google.gson.JsonArray array = jsonElement.getAsJsonArray();
			for (JsonElement element : array) {
				keys.addAll(getCycleReleaseParentLevelKeys(element, prefix));
			}
		}
		return keys;
	}

	// /**
	// * @param projectId
	// * is the JIRA project id as String returned from {@link BasicProject#getId()}
	// where the
	// * {@link BasicProject} can be found by calling {@link Issue#getProject()}
	// * @param partialCycleName
	// * as displayed in ZEPHYR UI
	// * @return id of execution cycle ready for use in future calls
	// */
	// public String getExecutionCycleByProjectIdAndCycleNames(String projectId,
	// String partialCycleName) {
	// String cyclePath = "/cycle";
	// String versionId = "28763";
	// log.warn("THE HAIDER USER NAME IS" + userName);
	// log.warn("THE HAIDER USER password IS" + password);
	// log.warn("THE HAIDER USER partialCycleName IS" + partialCycleName);
	// log.warn("THE HAIDER USER projectid IS" + projectId);
	// log.warn("THE HAIDER USER cycleTarget IS" + cyclePath);
	//
	// Response response = RestAssured.with().auth().preemptive().basic(userName,
	// password)
	// .contentType(ContentType.JSON).param("projectId", projectId)
	// .get(cyclePath);
	// log.warn("THE HAIDER USER got here 5 " + response);
	//
	// log.warn("THE HAIDER USER got here 1");
	// JSONObject searchCyclesJsonResponseObject = new
	// JSONObject(response.asString());
	// log.warn("THE HAIDER USER got here 2");
	// log.debug("JIRA JSON Object: " + response.asString());
	// log.warn("THE HAIDER USER got here 3");
	//
	// // JSONObject allCyclesJSON =
	// searchCyclesJsonResponseObject.getJSONArray("-1").getJSONObject(0);
	// JSONObject allCyclesJSON =
	// searchCyclesJsonResponseObject.getJSONArray("28743").getJSONObject(0);
	// log.warn("THE HAIDER USER got here 4");
	// Iterator<String> keysIterator = allCyclesJSON.keys();
	//
	// log.warn("haider key " + allCyclesJSON.keys());
	// String cycleKey = null;
	// while (keysIterator.hasNext()) {
	//
	// String key = keysIterator.next();
	// log.warn("THE HAIDER USER got here 6 " + key);
	// JSONObject currentJSONObject = allCyclesJSON.optJSONObject(key);
	// if (currentJSONObject != null && StringUtils
	// .containsIgnoreCase(currentJSONObject.getString("name"), partialCycleName)) {
	// log.debug("cycle key: " + key);
	// cycleKey = key;
	// }
	// }
	// return cycleKey;
	// }

	/**
	 * @param executionId            of the execution which should be updated . The
	 *                               current use case involves creating the
	 *                               execution beforehand
	 * @param newExecutionStatusCode either
	 *                               {@link ConstantsProvider#EXECUTION_STATUS_PASS},
	 *                               {@link ConstantsProvider#EXECUTION_STATUS_FAIL}
	 *                               or
	 *                               {@link ConstantsProvider#EXECUTION_STATUS_WIP}
	 * @param executionComment       comment that should appear in the comments
	 *                               section
	 * @return {@link Response} after updating the execution
	 */
	public Response updateExecutionStatus(String executionId, String newExecutionStatusCode, String executionComment) {
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			log.fatal(e.getMessage());
			// skipping the test in case of system failure
			Assume.assumeTrue(false);
		}
		String updateExecutionTarget = "/execution/" + executionId + "/execute";
		return RestAssured.with().auth().preemptive().basic(userName, password).contentType(ContentType.JSON).body(
				new JSONObject().put("status", newExecutionStatusCode).put("comment", executionComment).toString())
				.put(updateExecutionTarget);
	}

	/**
	 * This call blocks till the response is retrieved from the JIRA server
	 *
	 * @param issueLabel which is the label seen on the JIRA UI (eg. JIRA-650)
	 * @return {@link Issue}
	 */
	public Issue findIssue(@NonNull String issueLabel) {
		log.debug("search for issue with label: " + issueLabel);
		Promise<Issue> promise = jiraRestClient.getIssueClient().getIssue(issueLabel);
		log.debug("waiting for search results from Jira...");
		while (!promise.isDone()) {
		}
		return promise.claim();
	}

	@Override
	public void close() throws Exception {
		if (jiraRestClient != null) {
			jiraRestClient.close();
		}
	}
}