package ie.gov.agriculture.agschemes.runner;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.assertj.core.api.Assumptions;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestRule;
import org.junit.rules.Timeout;
import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import lombok.extern.log4j.Log4j2;
import org.junit.runner.RunWith;

/** Test runner */
@Log4j2
@RunWith(Cucumber.class)

@CucumberOptions(tags = "not @uino and not @schemeclosed", monochrome = true, strict = true,
        features = "classpath:features",
        glue = {"ie.gov.agriculture.agschemes.stepdefinitions" },
        plugin = { "pretty", "json:target/jsonReports/cucumber-report.json",
        "html:target/cucumber-html-report", "json:target/cucumber.json",
        "io.qameta.allure.cucumber5jvm.AllureCucumber5Jvm"
})

public class RunnerTest1 {

    @Rule
    public final TestRule globalTimeOut = Timeout.seconds(ConstantsProvider.getGLOBAL_TIMEOUT());

    /** This will skip the complete test run if the selenium hub is not reachable */
    @BeforeClass
    public static void checkVmStatus() throws IOException {
        if (ConstantsProvider.isSELENIUM_GRID_ON()) {
            log.info("got here 1 ...");
            try (Socket socket = new Socket()) {
                log.info("got here 2 ...");
                String selenium_vm_ip = ConstantsProvider.getSELENIUM_VM_IP();
                log.info("got here 3 ...");
                int selenium_hub_port = ConstantsProvider.getSELENIUM_HUB_PORT();
                log.info("got here 4 ...");
                Assumptions.assumeThatCode(() -> {
                    socket.connect(new InetSocketAddress(selenium_vm_ip, selenium_hub_port), 300);
                    log.info("got here 5 ...");
                }).as("Virtual Machine is not reachable: " + selenium_vm_ip + " or port :" + selenium_hub_port
                    + " is closed").doesNotThrowAnyException();
                log.info("got here 6 ...");
            }
        }
    }
}
