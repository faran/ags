package ie.gov.agriculture.agschemes.browserpages.nitrates;

import java.util.List;
import java.util.Objects;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.browserpages.sso.SsoPopupPage;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class NitratesLandingPageAgent extends NitratesLandingPage {

    public NitratesLandingPageAgent(WebDriver webDriver) {
        super(webDriver);
    }

    @FindBy(id = "agent-login-actions-create")
    protected List<WebElement> createApplicationButtonsAgent;

    @FindBy(id = "agent-login-actions-create")
    protected WebElement createApplicationButtonAgent;

    @FindBy(xpath = "(//button[@mattooltip='Create Application'])[1]")
    protected WebElement createApplicationButtonForNoApplications;

    @FindBy(xpath = "//mat-card-title[text()=' Application Form ']")
    protected WebElement applicationFormTitle;

    @FindBy(xpath = "//span[text()='New Application ']")
    protected WebElement newAppButton;

    @FindBy(id = "agent-login-no-application-list")
    protected WebElement noApplicationsTab;

    @FindBy(id = "agent-login-scheme-year")
    protected WebElement selectSchemeYearAgent;

    @FindBy(id = "mat-select-18")
    protected WebElement yearDropDownAgent;

    @FindBy(id = "agent-login-actions-edit0")
    protected WebElement editApplication;

    @FindBy(id = " agent-login-actions-delete0")
    protected WebElement deleteApplication;

    @FindBy(id = "agent-login-query-application-button")
    protected WebElement queryApplication;

    @FindBy(id = "internal-draft-view-tracking-button")
    protected WebElement draftViewTracking;

    private void searchByBusinessIdAgent(String herdno) {

        try {
            ssoPopupPageObject = PageFactory.initElements(webDriver, SsoPopupPage.class);
            ssoPopupPageObject.clickPopupClose();
        } catch (AssertionError e) {
            log.warn("close popup not there.. continue with test");
        }
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, selectSearchAgent);
        BrowserUtils.waitAndClickElement(webDriver, selectBusinessIdAgent);
        BrowserUtils.waitAndClickElement(webDriver, searchInputTextAgent);
        BrowserUtils.sendKeysToWebElement(webDriver, searchInputTextAgent, herdno);
        BrowserUtils.waitAndClickElement(webDriver, searchbutton);
    }

    @Override
    public void enterBusinessIdAndSearch(String herdNo) {
        searchByBusinessIdAgent(herdNo);
    }

    @Override
    public void clickDeleteApplicationOption() {
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        BrowserUtils.waitAndClickElement(webDriver, deleteApplicationButton);
        BrowserUtils.waitAndClickElement(webDriver, deleteApplicationButtonConfirm);
    }

    @Override
    public void clickDeleteCancelApplicationOption() {
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, deleteApplicationButton);
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, deleteApplicationButtonCancel);
    }

    @Override
    public void assertConfirmAndCancelAndViewButtonOptionsExist() {
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitUntilWebElementIsVisible(webDriver, viewApplicationButton);
        Assert.assertTrue("viewApplicationButton is displayed? ", viewApplicationButton.isDisplayed());
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitAndClickElement(webDriver, deleteApplicationButton);
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        BrowserUtils.waitUntilWebElementIsVisible(webDriver, deleteApplicationButtonCancel);
        Assert.assertTrue("deleteApplicationButtonCancel is displayed? ", deleteApplicationButtonCancel.isDisplayed());
        Assert.assertTrue("deleteApplicationButtonConfirm is displayed? ",
            deleteApplicationButtonConfirm.isDisplayed());
    }

    @Override
    public void clickManageDocumentOnAgentSearch(String herdno) {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        BrowserUtils.waitAndClickElement(webDriver, viewDocuments);
    }

    @Override
    public void clickCreateApplicationByBusinessIdSearch(String herdno) {
        searchByBusinessIdAgent(herdno);
        BrowserUtils.waitAndClickElement(webDriver,
            createApplicationButtonsAgent.get(createApplicationButtonsAgent.size() - 1));
    }

    @Override
    public void validateCreateApplicationButton() {
        BrowserUtils.waitUntilAngular5Ready(webDriver);
        Assert.assertTrue(createApplicationButtonsAgent.get(0).isDisplayed());
        // TODO: Fix this later
        // assertThat(BrowserUtils.getText(webDriver, businessIdTable) != null);

    }

    @Override
    public boolean assertCreateApplictionButtonIsNotAvailable() {
        try {
            return createApplicationButtonAgent.isDisplayed();
        } catch (NoSuchElementException e) {
            log.error("Element not found");
            return false;
        }
    }

    @Override
    public boolean assertCreateApplictionButtonForNoApplications() {
        try {
            return createApplicationButtonForNoApplications.isDisplayed();
        } catch (NoSuchElementException e) {
            log.error("Element not found");
            return false;
        }
    }

    @Override
    public void searchBySchemeYear(Integer year){
        try {
            ssoPopupPageObject = PageFactory.initElements(webDriver, SsoPopupPage.class);
            ssoPopupPageObject.clickPopupClose();
        } catch (AssertionError e) {
            log.warn("close popup not there.. continue with test");
        }
        BrowserUtils.waitAndClickElement(webDriver, selectSearchDropDownAgent);
        BrowserUtils.waitAndClickElement(webDriver, selectSchemeYearAgent);
        BrowserUtils.waitAndClickElement(webDriver, yearDropDownAgent);
        BrowserUtils.waitAndClickElement(webDriver, Objects.requireNonNull(selectYear(year)));
        BrowserUtils.waitAndClickElement(webDriver, searchbutton);
    }

    private WebElement selectYear(Integer year){
        switch (year) {
            case 2021:
                return webDriver.findElement(By.id("agent-login-option-schemeYear -0"));
            case 2020:
                return webDriver.findElement(By.id("agent-login-option-schemeYear -1"));
            case 2019:
                return webDriver.findElement(By.id("agent-login-option-schemeYear -2"));
            case 2018:
                return webDriver.findElement(By.id("agent-login-option-schemeYear -3"));
            case 2017:
                return webDriver.findElement(By.id("agent-login-option-schemeYear -4"));
            default:
                log.error("Year not found");
                return null;
        }
    }

    public void verifyActionsAvailableWhenSchemeIsClosed(){
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        Assert.assertTrue("View Application not displayed", viewApplicationButton.isDisplayed());
        Assert.assertTrue("View Application not displayed", npEnquiryDetails.isDisplayed());
        Assert.assertTrue("View Application not displayed", manageDocuments.isDisplayed());
    }

    public boolean verifyActionsNotAvailableWhenSchemeIsClosed(){
        try {
            return editApplication.isDisplayed() && deleteApplication.isDisplayed() && queryApplication.isDisplayed();
        } catch (NoSuchElementException e) {
            log.error("Element not found");
            return false;
        }
    }

    public void verifyActionsAvailableWhenSchemeIsOpen(){
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        Assert.assertTrue("View Application not displayed", viewApplicationButton.isDisplayed());
        Assert.assertTrue("NP Enquiry Application not displayed", npEnquiryDetails.isDisplayed());
        Assert.assertTrue("manage Application not displayed", manageDocuments.isDisplayed());
        Assert.assertTrue("Delete Application not displayed", deleteApplication.isDisplayed());
        Assert.assertTrue("Edit Application not displayed", editApplication.isDisplayed());
    }

    public boolean verifyActionsNotAvailableWhenSchemeIsOpen(){
        try {
            return queryApplication.isDisplayed() && draftViewTracking.isDisplayed() && moreActionsButton.isDisplayed();
        } catch (NoSuchElementException e) {
            log.error("Element not found");
            return false;
        }
    }

    public void clickViewApplications() {
        BrowserUtils.waitAndClickElement(webDriver, moreActionsButton);
        BrowserUtils.waitAndClickElement(webDriver, viewApplicationButton);
        BrowserUtils.waitVisibility(webDriver, viewApplicationTitle);
    }
}
