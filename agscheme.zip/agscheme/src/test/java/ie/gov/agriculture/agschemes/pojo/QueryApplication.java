package ie.gov.agriculture.agschemes.pojo;

import lombok.Getter;
import lombok.Setter;

public class QueryApplication {
    @Getter @Setter private String dataA;
    @Getter @Setter private Integer eventReasonCode;
    @Getter @Setter private String docType;
    @Getter @Setter private String docYear;
    @Getter @Setter private String userComment;
}
