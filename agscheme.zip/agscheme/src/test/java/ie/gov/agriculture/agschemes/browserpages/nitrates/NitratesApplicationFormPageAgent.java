package ie.gov.agriculture.agschemes.browserpages.nitrates;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.commons.lang.NotImplementedException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.databasequeries.StartupDatabaseQueries;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class NitratesApplicationFormPageAgent implements INitratesApplicationFormPage {
    private StartupDatabaseQueries databaseQueryUtils;

    TestDataHolder testDataHolder;

    private final WebDriver webDriver;

    @FindBy(id = "agent-create-button-draft")
    private WebElement saveAsDraftButtonAgent;

    @FindBy(id = "agent-create-button-next")
    private WebElement agentNextButton;

    @FindBy(id = "agent-view-button-next")
    private WebElement agentViewNextButton;

    @FindBy(id = "agent-create-checkbox-terms-agreement")
    private WebElement termsAndCondtionsCheckboxAgent;

    @FindBy(id = "agent-create-button-cancel")
    private WebElement cancelApplicationButtonAgent;

    @FindBy(id = "agent-create-button-submit")
    private WebElement saveAsSubmitButtonAgent;

    @FindBy(id = "confimation-modal-confirm-button")
    private WebElement applicationConfirmButtonAgent;

    @FindBy(id = "confimation-modal-cancel-button")
    private WebElement applicationCancelButtonAgent;

    @FindBy(id = "agent-document-manager-back-button")
    private WebElement documentManagerCancelButtonAgent;

    @FindBy(id = "agent-create-select-storage-period")
    private WebElement storagePeroidDropdownAgent;

    @FindBy(id = "agent-create-option-16-weeks")
    private WebElement storagePeroidDropdownFirstOptionAgent;

    @FindBy(id = "agent-create-input-manure")
    private WebElement estimatedNitrogenSpreadAgent;

    @FindBy(id = "agent-create-checkbox-biodiversity-0")
    private WebElement biodiversityMeasuresCheckBoxOptionOneAgent;

    @FindBy(id = "agent-create-input-eligible-manual-value")
    private WebElement eligibleAreaOfHoldingCheckAgentInput;

    @FindBy(id = "agent-create-input-eligible-holding-value")
    private WebElement eligibleAreaOfHoldingCheckAgentValue;

    @FindBy(id = "agent-create-input-grassland-value-enter")
    private WebElement eigibleAreaofGrasslandAgentInput;

    @FindBy(id = "agent-create-input-grassland-value")
    private WebElement eigibleAreaofGrasslandAgentValue;

    @FindBy(id = "agent-create-grassland-percent")
    private WebElement eigibleAreaofGrasslandPercentageAgent;

    @FindBy(id = "agent-create-col-animal-count-0")
    private WebElement animalCountAgent;

    @FindBy(id = "agent-create-radio-yes-grassland-trainings")
    private WebElement yesGrasslandTrainingRadioButtonAgent;

    @FindBy(id = "agent-create-radio-no-environmental-trainings")
    private WebElement noEnvironmentalRadioButtonAgent;

    @FindBy(id = "agent-create-select-animal-holding-name-0")
    private WebElement selectAnimalTypeAgent;

    @FindBy(id = "agent-create-option-animal-holding-name-0COW")
    private WebElement selectAnimalTypeCowAgent;

    @FindBy(id = "agent-create-input-livestock-count-value-0")
    private WebElement enterAnimalCountAgent;

    @FindBy(id = "agent-create-icon-add-button-0")
    private WebElement addAnimalButtonAgent;

    @FindBy(xpath = "//div[@id='customer-businessId']/dl/dt/following-sibling::dd")
    protected WebElement customerBusinessIdLabel;

    @FindBy(xpath = "//div[@id='customer-startDate']/dl/dt/following-sibling::dd")
    protected WebElement customerStartDateLabel;

    private void termsAndConditionsCheckboxForAgent() {
        BrowserUtils.waitAndClickElement(webDriver, termsAndCondtionsCheckboxAgent);
    }

    private void trainingRadioButtonsForAgent() {
        BrowserUtils.waitAndClickElement(webDriver, yesGrasslandTrainingRadioButtonAgent);
        BrowserUtils.waitAndClickElement(webDriver, noEnvironmentalRadioButtonAgent);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
    }

    private void biodiversityMeasuresCheckBoxForAgent() {
        BrowserUtils.waitAndClickElement(webDriver, biodiversityMeasuresCheckBoxOptionOneAgent);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
    }

    private void estimatedNitrogenSpreadForAgent() {
        BrowserUtils.sendKeysToWebElement(webDriver, estimatedNitrogenSpreadAgent,
            ConstantsProvider.getESTIMATEDNITROGENSPREAD());
        TestDataHolder.addTestDataRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD_AGENT,
            ConstantsProvider.getESTIMATEDNITROGENSPREAD(),
            true, true);
        log.warn("estimatedNitrogenSpreadAgent "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD_AGENT));
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
    }

    private void storagePeroidDropdownForAgent() {
        BrowserUtils.waitAndClickElement(webDriver, storagePeroidDropdownAgent);
        String dropdownFirstOption = BrowserUtils.getText(webDriver,
            storagePeroidDropdownFirstOptionAgent);
        // Set key for checking database for comparing with ui
        TestDataHolder.addRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION,
            dropdownFirstOption);
        log.warn("TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION "
            + TestDataHolder.getTestDataRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION));
        BrowserUtils.waitAndClickElement(webDriver, storagePeroidDropdownFirstOptionAgent);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
    }

    private void eligibleAreaOfGrasslandForAgent(String herdno) throws Exception {
        try {
            log.warn("CHECKING verifyEligibleAreaOfGrasslandAgentCheckDb ...");

            String verifyEligibleAreaOfGrasslandAgentCheck = databaseQueryUtils.verifyEligibleAreaOfGrassland(herdno);
            // db check will delete this later
            TestDataHolder.addTestDataRecord("verifyEligibleAreaOfGrasslandAgentCheckDb",
                verifyEligibleAreaOfGrasslandAgentCheck, true, true);
            log.warn("verifyEligibleAreaOfGrasslandAgentCheckDb"
                + TestDataHolder.getTestDataRecord("verifyEligibleAreaOfGrasslandAgentCheckDb"));

            assertThat(verifyEligibleAreaOfGrasslandAgentCheck).isNotEmpty();

            log.warn("GRAB DATA eligibleAreaOfGrasslandCheckAgentValue FROM UI BPS DATA LOAD ...");

            // staff-create-input-grassland-value-enter - get value from ui // TODO ADD
            // EXACT agent-create-input-grassland-value CHECKS
            String eligibleAreaOfGrasslandCheckAgentValueFromTextBox = BrowserUtils.getValueFromInputBox(webDriver,
                eigibleAreaofGrasslandAgentValue);
            log.warn("eligibleAreaOfGrasslandCheckAgentValue " + eligibleAreaOfGrasslandCheckAgentValueFromTextBox);
            // Set key for checking database for
            // comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_AGENT_VALUE,
                eligibleAreaOfGrasslandCheckAgentValueFromTextBox, true, true);
            log.warn("eligibleAreaOfGrasslandCheckAgentValue "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_AGENT_VALUE));

            log.warn("GOT DATA eligibleAreaOfGrasslandCheckAgentValue FROM UI BPS DATA MOVING ON ...");
        } catch (AssertionError e) {
            log.warn("no eligibleAreaOfGrasslandCheckAgentValue data for agent IN UI ...");
            log.warn("continue.. enter data");
            log.warn("entering data for eligibleAreaOfGrasslandCheckAgentValue data ...");

            BrowserUtils.sendKeysToWebElement(webDriver, eigibleAreaofGrasslandAgentInput,
                ConstantsProvider.getELIGIBLEAREAOFGRASSLANDSTAFFINPUT());
            // checking database from what input is
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_AGENT_VALUE,
                ConstantsProvider.getELIGIBLEAREAOFGRASSLANDSTAFFINPUT(), true, true);
            log.warn("eigibleAreaofGrasslandAgentValueInput "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_AGENT_VALUE));
            log.warn("ENTERED data for eligibleAreaOfGrasslandCheckAgentValue data ...");

        }

        // TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE

        String eligiblePercentage = BrowserUtils.getValueFromInputBox(webDriver,
            eigibleAreaofGrasslandPercentageAgent);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = " + eligiblePercentage);
        // Set key for checking database for
        // comparing with ui
        TestDataHolder.addRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE,
            eligiblePercentage);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));
        assertThat(eligiblePercentage).isNotEmpty();
        log.warn("GOT DATA eigibleAreaofGrasslandPercentageValue FROM UI BPS DATA MOVING ON ...");

        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
    }

    private void eligibleAreaOfHoldingForAgent(String herdno) throws Exception {
        try {
            log.warn("CHECKING EligibleAreaOfHoldingAgentCheckDb ...");
            // db check will delete this later
            String verifyEligibleAreaOfHoldingAgentCheck = databaseQueryUtils.verifyEligibleAreaOfHolding(herdno);
            TestDataHolder.addTestDataRecord("EligibleAreaOfHoldingAgentCheckDb", verifyEligibleAreaOfHoldingAgentCheck,
                true, true);
            log.warn("EligibleAreaOfHoldingAgentCheckDb"
                + TestDataHolder.getTestDataRecord("EligibleAreaOfHoldingAgentCheckDb"));

            assertThat(verifyEligibleAreaOfHoldingAgentCheck).isNotEmpty();

            // TODO: agent-create-input-eligible-holding-value - get value from ui
            log.warn("GRAB DATA eligibleAreaOfHoldingCheckAgentValue FROM UI BPS DATA LOAD ...");
            // Thread.sleep(30000);
            String eligibleAreaOfHoldingCheckAgentValueFromTextbox = BrowserUtils.getValueFromInputBox(webDriver,
                eligibleAreaOfHoldingCheckAgentValue);
            log.warn("eligibleAreaOfHoldingCheckAgentValue " + eligibleAreaOfHoldingCheckAgentValueFromTextbox);
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_AGENT_VALUE,
                eligibleAreaOfHoldingCheckAgentValueFromTextbox, true, true);
            log.warn("eligibleAreaOfHoldingCheckAgentValue "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_AGENT_VALUE));

            log.warn("GOT DATA eligibleAreaOfHoldingCheckAgentValue FROM UI BPS DATA MOVING ON ...");

        } catch (AssertionError e) {
            log.warn("no eligibleAreaOfHoldingCheckAgentValue data for agent IN UI ...");
            log.warn("continue.. enter data");
            log.warn("entering data for eligibleArfeaOfHoldingCheckAgentValue data ...");

            BrowserUtils.sendKeysToWebElement(webDriver, eligibleAreaOfHoldingCheckAgentInput,
                ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT());
            // checking database from what input is
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_AGENT_VALUE,
                ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT(), true, true);
            log.warn("eligibleAreaOfHoldingCheckAgentValueInput "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_AGENT_VALUE));
            log.warn("ENTERED data for eligibleAreaOfHoldingCheckAgentValue data ...");

        }
    }

    private void animalCheckForAgent(String herdno) throws Exception {
        try {
            log.warn("CHECKING animalsOnHoldingAgentCheckDb ...");
            String verifyAnimalsOnHoldingCheck = databaseQueryUtils.verifyAnimalsOnHoldingCheckAhcsViews(herdno);
            // db check TODO: REFACTORING REQUIRED HERE
            TestDataHolder.addTestDataRecord("animalsOnHoldingAgentCheckDb", verifyAnimalsOnHoldingCheck, true, true);
            log.warn("animalsOnHoldingAgentCheckDb" + TestDataHolder.getTestDataRecord("animalsOnHoldingAgentCheckDb"));

            // TODO: exact checks agent-create-col-animal-count-0 CHECKS
            log.warn("GRAB DATA animalsOnHoldingCheckAgentValue FROM UI BPS DATA LOAD ...");
            String animalsOnHoldingCheckAgentValue = BrowserUtils.getText(webDriver, animalCountAgent);
            log.warn("animalsOnHoldingCheckAgentValue " + animalsOnHoldingCheckAgentValue);
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_AGENT_VALUE,
                animalsOnHoldingCheckAgentValue, true, true);
            log.warn("animalsOnHoldingCheckAgentValue "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_AGENT_VALUE));
            assertThat(verifyAnimalsOnHoldingCheck).isNotEmpty();
            log.warn("GOT DATA animalsOnHoldingCheckAgentValue FROM UI BPS DATA MOVING ON ...");
        } catch (AssertionError | org.openqa.selenium.NoSuchElementException | org.openqa.selenium.TimeoutException e) {
            log.warn("no animal data for agent ...");
            log.warn("continue.. enter data");
            BrowserUtils.pause(15);
            // enter data
            BrowserUtils.waitAndClickElement(webDriver, selectAnimalTypeAgent);
            BrowserUtils.waitAndClickElement(webDriver, selectAnimalTypeCowAgent);
            BrowserUtils.waitAndClickElement(webDriver, enterAnimalCountAgent);
            BrowserUtils.sendKeysToWebElement(webDriver, enterAnimalCountAgent, ConstantsProvider.getANIMALCOUNT());
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_AGENT_VALUE,
                ConstantsProvider.getANIMALCOUNT(),
                true,
                true);
            log.warn(
                "animalsOnHoldingCheckValue "
                    + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_AGENT_VALUE));
            BrowserUtils.waitAndClickElement(webDriver, addAnimalButtonAgent);

        }
        BrowserUtils.pause(3);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
    }

    // testing this
    private void enterValidUserInputForAgent(String herdno) throws Exception {
        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        animalCheckForAgent(herdno);
        eligibleAreaOfHoldingForAgent(herdno);
        eligibleAreaOfGrasslandForAgent(herdno);
        storagePeroidDropdownForAgent();
        estimatedNitrogenSpreadForAgent();
        biodiversityMeasuresCheckBoxForAgent();
        trainingRadioButtonsForAgent();
        termsAndConditionsCheckboxForAgent();
    }

    @Override
    public void clickCreateApplicationNoUserInputAndClickSaveAsDraft() {
        BrowserUtils.pause(3);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
        BrowserUtils.waitAndClickElement(webDriver, agentNextButton);
        termsAndConditionsCheckboxForAgent();

        // TODO: REFACTOR LATER
        // databaseQueryPage = PageFactory.initElements(webDriver,
        // DatabaseQueryPage.class);
        // ArrayList<String> beforesubmit = databaseQueryPage
        // .verifyApplicationIsDraftStatus(HERD_UNDER_TEST);

        BrowserUtils.waitUntilWebElementClickable(webDriver, saveAsDraftButtonAgent);
        BrowserUtils.waitAndClickElement(webDriver, saveAsDraftButtonAgent);
        BrowserUtils.waitUntilWebElementClickable(webDriver, applicationConfirmButtonAgent);
        BrowserUtils.waitAndClickElement(webDriver, applicationConfirmButtonAgent);

        // TODO: REFACTOR LATER
        // BrowserUtils.waitAndClickElement(webDriver, cancelApplicationButton);
        // TestDataHolder.addTestDataRecord(TestDataHolder.BEFOREARRAY, beforesubmit,
        // true, false);
        // testDataHolder.fileOutWrite(beforesubmit);
        // return beforesubmit;

    }

    @Override
    public void createApplicationAndClickCancel(String herdno) throws Exception {
        enterValidUserInputForAgent(herdno);
        BrowserUtils.waitAndClickElement(webDriver, cancelApplicationButtonAgent);
    }

    @Override
    public void createApplicationEnterValidUserInputAndClickSaveAsDraft(String herdno) throws Exception {
        enterValidUserInputForAgent(herdno);
        BrowserUtils.waitAndClickElement(webDriver, saveAsDraftButtonAgent);
        BrowserUtils.waitAndClickElement(webDriver, applicationConfirmButtonAgent);
        // Need to click cancel/back button to get to application view
        BrowserUtils.waitAndClickElement(webDriver, documentManagerCancelButtonAgent);
    }

    @Override
    public void createApplicationEnterValidUserInputForSubmit(String herdno) throws Exception {
        enterValidUserInputForAgent(herdno);
        BrowserUtils.waitAndClickElement(webDriver, saveAsSubmitButtonAgent);
        BrowserUtils.waitAndClickElement(webDriver, applicationCancelButtonAgent);
    }

    @Override
    public void createApplicationWithNoDataEnterValidUserInputAndClickSaveAsDraft(String herdno) {
        throw new NotImplementedException();
    }

    @Override
    public void createApplicationWithNoDataEnterValidUserInputForSubmit(String herdno) {
        throw new NotImplementedException();
    }

    @Override
    public void createApplicationEnterIncorrectUserInputForSubmit(String herdno) {
        throw new NotImplementedException();
    }

    @Override
    public void getCustomerDetails() {
        BrowserUtils.waitVisibility(webDriver, agentNextButton);
        TestDataHolder.addRecord(TestDataHolder.CUSTOMER_BUSINESS_ID_AGENT_VALUE,
                customerBusinessIdLabel.getText());
        log.warn("TestDataHolder.CUSTOMER_BUSINESS_ID_AGENT_VALUE = "
                + TestDataHolder.getTestDataRecord(TestDataHolder.CUSTOMER_BUSINESS_ID_AGENT_VALUE));
        TestDataHolder.addRecord(TestDataHolder.CUSTOMER_START_DATE_AGENT_VALUE,
                customerStartDateLabel.getText());
        log.warn("TestDataHolder.CUSTOMER_START_DATE_AGENT_VALUE = "
                + TestDataHolder.getTestDataRecord(TestDataHolder.CUSTOMER_START_DATE_AGENT_VALUE));
    }

}
