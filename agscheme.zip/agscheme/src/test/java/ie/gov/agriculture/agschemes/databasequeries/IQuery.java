package ie.gov.agriculture.agschemes.databasequeries;

import java.sql.SQLException;

public interface IQuery {

    void buildQuery();

    String runQuery() throws SQLException;

}