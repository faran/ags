package ie.gov.agriculture.agschemes.browserpages.nitrates;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.commons.lang.NotImplementedException;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.databasequeries.StartupDatabaseQueries;
import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class NitratesApplicationFormPageStaff implements INitratesApplicationFormPage {
    private StartupDatabaseQueries databaseQueryUtils;

    TestDataHolder testDataHolder;

    private final WebDriver webDriver;

    @FindBy(id = "staff-create-button-next")
    private WebElement staffNextButton;

    @FindBy(id = "staff-create-checkbox-terms-agreement")
    private WebElement termsAndCondtionsCheckboxStaff;

    @FindBy(id = "staff-create-button-cancel")
    private WebElement cancelApplicationButtonStaff;

    @FindBy(id = "staff-create-button-submit")
    private WebElement saveAsSubmitButtonStaff;

    @FindBy(id = "staff-create-button-draft")
    private WebElement saveAsDraftButtonStaff;

    @FindBy(id = "staff-create-select-storage-period")
    private WebElement storagePeroidDropdownStaff;

    @FindBy(id = "staff-create-option-16-weeks")
    private WebElement storagePeroidDropdownFirstOptionStaff;

    @FindBy(id = "staff-create-input-manure")
    private WebElement estimatedNitrogenSpreadStaff;

    @FindBy(id = "staff-create-checkbox-biodiversity-0")
    private WebElement biodiversityMeasuresCheckBoxOptionOneStaff;

    @FindBy(id = "staff-create-input-eligible-manual-value")
    private WebElement eligibleAreaOfHoldingCheckStaffInput;

    @FindBy(id = "staff-create-input-eligible-holding-value")
    private WebElement eligibleAreaOfHoldingCheckStaffValue;

    @FindBy(id = "staff-create-input-grassland-value")
    private WebElement eigibleAreaofGrasslandStaffValue;

    @FindBy(id = "staff-create-input-grassland-value-enter")
    private WebElement eigibleAreaofGrasslandStaffInput;

    @FindBy(id = "staff-create-grassland-percent")
    private WebElement eigibleAreaofGrasslandPercentageStaff;

    @FindBy(id = "staff-create-col-animal-count-0")
    private WebElement animalCountStaff;

    @FindBy(id = "staff-create-select-animal-holding-name-0")
    private WebElement selectAnimalTypeStaff;

    @FindBy(id = "staff-create-option-animal-holding-name-0COW")
    private WebElement selectAnimalTypeCowStaff;

    @FindBy(id = "staff-create-input-livestock-count-value-0")
    private WebElement enterAnimalCountStaff;

    @FindBy(id = "staff-create-icon-add-button-0")
    private WebElement addAnimalButtonStaff;

    @FindBy(id = "staff-create-button-remove-row-1")
    private WebElement removeAnimalButtonStaff;

    @FindBy(id = "staff-create-radio-yes-grassland-trainings")
    private WebElement yesGrasslandTrainingRadioButtonStaff;

    @FindBy(id = "staff-create-radio-no-environmental-trainings")
    private WebElement noEnvironmentalRadioButtonStaff;

    @FindBy(id = "customer-displayName")
    protected WebElement customerDisplayNameStaffLabel;

    @FindBy(xpath = "//agsch-view-internal-application-form/descendant::div[@id='customer-businessId']/dl/dd")
    protected WebElement customerBusinessIdStaffLabel;

    @FindBy(id = "customer-address")
    protected WebElement customerAddressStaffLabel;

    @FindBy(xpath = "//agsch-view-internal-application-form/descendant::div[@id='customer-startDate']/dl/dd")
    protected WebElement customerStartDateStaffLabel;

    @FindBy(id = "customer-email")
    protected WebElement customerEmailStaffLabel;

    @FindBy(xpath = "//simple-snack-bar/span[text()='Application Saved Successfully']")
    protected WebElement appSavedSuccText;

    @FindBy(xpath = "//simple-snack-bar/span[text()='Application Successfully Submitted']")
    protected WebElement appSuccSubmittedText;

    @FindBy(xpath = "//span[@class='mat-button-wrapper'][text()='Close']")
    protected WebElement appSavedSuccCloseButton;

    private void noDataGivenEnterValidUserInputForStaff(){
        enterAnimalDataWhereNoDataIsGivenForStaff();
        enterEligibleAreaOfHoldingAndEligibleAreaOfGrasslandWhereNoDataIsGivenForStaff();
        enterStoragePeroidDropdownForStaff();
        enterEstimatedNitrogenSpreadForStaff();
        biodiversityMeasuresCheckBoxForStaff();
        trainingRadioButtonsForStaff();
        termsAndCondtionsCheckboxForStaff();
    }

    private void enterValidUserInputForStaff(String herdno) throws Exception {
        animalCheckForStaff(herdno);
        eligibleAreaOfHoldingForStaff(herdno);
        eligibleAreaOfGrasslandForStaff(herdno);
        enterStoragePeroidDropdownForStaff();
        enterEstimatedNitrogenSpreadForStaff();
        biodiversityMeasuresCheckBoxForStaff();
        trainingRadioButtonsForStaff();
        termsAndCondtionsCheckboxForStaff();
    }

    private void enterIncorrectAnimalDataForStaff(String herdno) throws Exception {
        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);
        // allow the application to load so that each tab loads fine
        BrowserUtils.pause(3);

        try {
            String verifyAnimalsOnHoldingCheck = databaseQueryUtils.verifyAnimalsOnHoldingCheckAhcsViews(herdno);
            // db check
            TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_DB,
                    verifyAnimalsOnHoldingCheck, true, true);
            log.warn("animalsOnHoldingCheck" + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_DB));
            assertThat(verifyAnimalsOnHoldingCheck).isNotEmpty();
        } catch (AssertionError e) {
            log.warn("continue.. enter data");
            // enter data

        }
        BrowserUtils.pause(3);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void eligibleAreaOfGrasslandForStaff(String herdno) throws Exception {
        try {
            String verifyEligibleAreaOfGrasslandCheck = databaseQueryUtils.verifyEligibleAreaOfGrassland(herdno);
            //
            TestDataHolder.addTestDataRecord(TestDataHolder.VERIFY_ELIGIBLE_AREA_OF_GRASSLAND_DB, verifyEligibleAreaOfGrasslandCheck,
                true, true);
            log.warn("verifyEligibleAreaOfGrasslandDb"
                + TestDataHolder.getTestDataRecord(TestDataHolder.VERIFY_ELIGIBLE_AREA_OF_GRASSLAND_DB));

            assertThat(verifyEligibleAreaOfGrasslandCheck).isNotEmpty();

            log.warn("GRAB DATA eligibleAreaOfGrasslandCheckValue FROM UI BPS DATA LOAD ...");

            // staff-create-input-grassland-value-enter - get value from ui
            String eligibleAreaOfGrasslandCheckValue = BrowserUtils.getValueFromInputBox(webDriver,
                eigibleAreaofGrasslandStaffValue);
            log.warn(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE + eligibleAreaOfGrasslandCheckValue);
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE,
                eligibleAreaOfGrasslandCheckValue, true, true);
            log.warn("eligibleAreaOfGrasslandCheckValue "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE));

            log.warn("GOT DATA eligibleAreaOfGrasslandCheckValue FROM UI BPS DATA LOAD ...");

        } catch (AssertionError e) {
            log.warn("continue.. enter data");
            BrowserUtils.sendKeysToWebElement(webDriver, eigibleAreaofGrasslandStaffInput,
                ConstantsProvider.getELIGIBLEAREAOFGRASSLANDSTAFFINPUT());
            // Set key for checking database from what input is
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE,
                ConstantsProvider.getELIGIBLEAREAOFGRASSLANDSTAFFINPUT(), true, true);
            log.warn("eigibleAreaofGrasslandStaffValueInput "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE));
        }

        String eligiblePercentage = BrowserUtils.getValueFromInputBox(webDriver,
            eigibleAreaofGrasslandPercentageStaff);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = " + eligiblePercentage);
        // Set key for checking database for
        // comparing with ui
        TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE,
            eligiblePercentage, true, true);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));

        assertThat(eligiblePercentage).isNotEmpty();
        log.warn("GOT DATA TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE FROM UI BPS DATA MOVING ON ...");

        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void eligibleAreaOfHoldingForStaff(String herdno) throws Exception {
        try {
            String verifyEligibleAreaOfHoldingCheck = databaseQueryUtils.verifyEligibleAreaOfHolding(herdno);
            // db check need to remove later
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECKDB,
                    verifyEligibleAreaOfHoldingCheck, true, true);
            log.warn("EligibleAreaOfHoldingCheckDb" + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECKDB));

            assertThat(verifyEligibleAreaOfHoldingCheck).isNotEmpty();

            log.warn("GRAB DATA eligibleAreaOfHoldingCheckValue FROM UI BPS DATA LOAD ...");
            // Thread.sleep(30000);
            // TODO: staff-create-input-eligible-manual-value - get value from ui
            String eligibleAreaOfHoldingCheckValue = BrowserUtils.getValueFromInputBox(webDriver,
                eligibleAreaOfHoldingCheckStaffValue);
            log.warn("eligibleAreaOfHoldingCheckValue " + eligibleAreaOfHoldingCheckValue);
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_VALUE,
                eligibleAreaOfHoldingCheckValue, true, true);
            log.warn("got DATA eligibleAreaOfHoldingCheckValue FROM UI BPS DATA LOAD ...");

        } catch (AssertionError e) {
            log.warn("continue.. enter data");
            BrowserUtils.sendKeysToWebElement(webDriver, eligibleAreaOfHoldingCheckStaffInput,
                ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT());
            // Set key for checking database from what input is
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_VALUE,
                ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT(), true, true);
            log.warn("eligibleAreaOfHoldingCheckValueInput "
                + ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT());

        }
    }

    private void enterIncorrectStoragePeroidDropdownDataForStaff() {
        BrowserUtils.waitAndClickElement(webDriver, storagePeroidDropdownStaff);
        BrowserUtils.waitAndClickElement(webDriver, storagePeroidDropdownFirstOptionStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
        BrowserUtils.sendKeysToWebElement(webDriver, estimatedNitrogenSpreadStaff,
            ConstantsProvider.getINVALIDESTIMATEDNITROGENSPREAD());
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterIncorrectEligibleAreaOfGrasslandDataForStaff(String herdno)
        throws Exception {
        try {
            String verifyEligibleAreaOfGrasslandCheck = databaseQueryUtils.verifyEligibleAreaOfGrassland(herdno);
            TestDataHolder.addTestDataRecord(TestDataHolder.VERIFY_ELIGIBLE_AREA_OF_GRASSLAND,
                verifyEligibleAreaOfGrasslandCheck, true, true);
            log.warn("verifyEligibleAreaOfGrassland"
                + TestDataHolder.getTestDataRecord(TestDataHolder.VERIFY_ELIGIBLE_AREA_OF_GRASSLAND));
            assertThat(verifyEligibleAreaOfGrasslandCheck).isNotEmpty();
        } catch (AssertionError e) {
            log.warn("continue.. enter data");
            BrowserUtils.sendKeysToWebElement(webDriver, eigibleAreaofGrasslandStaffInput,
                ConstantsProvider.getINVALIDELIGIBLEAREAOFGRASSLANDSTAFFINPUT());

        }

        // eigibleAreaofGrasslandPercentageValue

        String eligiblePercentage = BrowserUtils.getValueFromInputBox(webDriver,
            eigibleAreaofGrasslandPercentageStaff);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = " + eligiblePercentage);
        // Set key for checking database for
        // comparing with ui
        TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE,
            eligiblePercentage, true, true);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));
        log.warn("GOT DATA TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE FROM UI BPS DATA MOVING ON ...");

        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterIncorrectEligibleAreaOfHoldingDataForStaff(String herdno) throws Exception {
        try {
            String verifyEligibleAreaOfHoldingCheck = databaseQueryUtils.verifyEligibleAreaOfHolding(herdno);
            TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK,
                verifyEligibleAreaOfHoldingCheck, true, true);
            log.warn("EligibleAreaOfHoldingCheck"
                + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK));
            assertThat(verifyEligibleAreaOfHoldingCheck).isNotEmpty();
        } catch (AssertionError e) {
            log.warn("continue.. enter data");
            BrowserUtils.sendKeysToWebElement(webDriver, eligibleAreaOfHoldingCheckStaffInput,
                ConstantsProvider.getINVALIDELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT());

        }
    }

    private void animalCheckForStaff(String herdno) throws Exception {
        databaseQueryUtils = PageFactory.initElements(webDriver, StartupDatabaseQueries.class);

        try {
            String verifyAnimalsOnHoldingCheck = databaseQueryUtils.verifyAnimalsOnHoldingCheckAhcsViews(herdno);

            // db check
            TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_COWDB,
                    verifyAnimalsOnHoldingCheck, true, true);
            log.warn("animalsOnHoldingCheckCowDb"
                + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_COWDB));

            // TODO: staff-create-col-animal-count-0 - get value from ui
            String animalsOnHoldingCheckValue = BrowserUtils.getText(webDriver, animalCountStaff);
            log.warn("animalsOnHoldingCheckValue " + animalsOnHoldingCheckValue);
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE,
                    animalsOnHoldingCheckValue, true, true);
            log.warn("animalsOnHoldingCheckValue "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE));

            // TODO: ADD more animal checks at some point
            assertThat(verifyAnimalsOnHoldingCheck).isNotEmpty();
        } catch (AssertionError e) {
            // TODO NEED TO MOVE AT SOME POINT
            log.warn("continue.. enter data");
            // enter data
            BrowserUtils.waitAndClickElement(webDriver, selectAnimalTypeStaff);
            BrowserUtils.waitAndClickElement(webDriver, selectAnimalTypeCowStaff);
            BrowserUtils.waitAndClickElement(webDriver, enterAnimalCountStaff);
            BrowserUtils.sendKeysToWebElement(webDriver, enterAnimalCountStaff, ConstantsProvider.getANIMALCOUNT());
            // Set key for checking database for comparing with ui
            TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE,
                ConstantsProvider.getANIMALCOUNT(), true, true);
            log.warn("animalsOnHoldingCheckValue "
                + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE));
            BrowserUtils.waitAndClickElement(webDriver, addAnimalButtonStaff);
            BrowserUtils.waitAndClickElement(webDriver, removeAnimalButtonStaff);

        }
        BrowserUtils.pause(3);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void termsAndCondtionsCheckboxForStaff() {
        BrowserUtils.waitAndClickElement(webDriver, termsAndCondtionsCheckboxStaff);
    }

    private void trainingRadioButtonsForStaff() {
        BrowserUtils.waitAndClickElement(webDriver, yesGrasslandTrainingRadioButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, noEnvironmentalRadioButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void biodiversityMeasuresCheckBoxForStaff() {
        BrowserUtils.waitAndClickElement(webDriver, biodiversityMeasuresCheckBoxOptionOneStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterEstimatedNitrogenSpreadForStaff() {
        BrowserUtils.sendKeysToWebElement(webDriver, estimatedNitrogenSpreadStaff,
            ConstantsProvider.getESTIMATEDNITROGENSPREAD());
        // TODO: staff-create-input-manure
        // Set key for checking database for comparing with ui
        TestDataHolder.addTestDataRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD,
            ConstantsProvider.getESTIMATEDNITROGENSPREAD(), true, true);
        log.warn(
            "estimatedNitrogenSpread " + TestDataHolder.getTestDataRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD));

        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterStoragePeroidDropdownForStaff() {
        BrowserUtils.waitAndClickElement(webDriver, storagePeroidDropdownStaff);
        String dropdownFirstOption = BrowserUtils.getText(webDriver,
            storagePeroidDropdownFirstOptionStaff);
        // Set key for checking database for comparing with ui
        TestDataHolder.addRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION,
            dropdownFirstOption);
        log.warn("TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.STORAGE_PERIOD_DROPDOWN_FIRST_OPTION));
        BrowserUtils.waitAndClickElement(webDriver, storagePeroidDropdownFirstOptionStaff);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterEligibleAreaOfHoldingAndEligibleAreaOfGrasslandWhereNoDataIsGivenForStaff() {
        log.warn("continue.. enter data");
        BrowserUtils.sendKeysToWebElement(webDriver, eligibleAreaOfHoldingCheckStaffInput,
            ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT());
        // Set key for checking database from what input is
        TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_VALUE,
            ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT(), true, true);
        log.debug("eligibleAreaOfHoldingCheckValueInput "
            + ConstantsProvider.getELIGIBLEAREAOFHOLDINGCHECKSTAFFINPUT());

        // TODO delete later
        // BrowserUtils.waitAndClickElement(webDriver, staffNextButton);

        log.warn("continue.. enter data");
        BrowserUtils.sendKeysToWebElement(webDriver, eigibleAreaofGrasslandStaffInput,
            ConstantsProvider.getELIGIBLEAREAOFGRASSLANDSTAFFINPUT());
        // Set key for checking database from what input is
        TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE,
            ConstantsProvider.getELIGIBLEAREAOFGRASSLANDSTAFFINPUT(), true, true);
        log.warn("eigibleAreaofGrasslandStaffValueInput "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE));

        String eligiblePercentage = BrowserUtils.getValueFromInputBox(webDriver,
            eigibleAreaofGrasslandPercentageStaff);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = " + eligiblePercentage);
        // Set key for checking database for
        // comparing with ui
        TestDataHolder.addTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE,
            eligiblePercentage, true, true);
        log.warn("TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE = "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));
        assertThat(eligiblePercentage).isNotEmpty();
        log.warn("GOT DATA TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE FROM UI BPS DATA MOVING ON ...");
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterAnimalDataWhereNoDataIsGivenForStaff() {
        log.warn("continue.. enter data");
        // enter data
        BrowserUtils.waitAndClickElement(webDriver, selectAnimalTypeStaff);
        BrowserUtils.waitAndClickElement(webDriver, selectAnimalTypeCowStaff);
        BrowserUtils.waitAndClickElement(webDriver, enterAnimalCountStaff);
        BrowserUtils.sendKeysToWebElement(webDriver, enterAnimalCountStaff, ConstantsProvider.getANIMALCOUNT());
        // Set key for checking database for comparing with ui
        TestDataHolder.addTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE,
            ConstantsProvider.getANIMALCOUNT(), true, true);
        log.warn("animalsOnHoldingCheckValue "
            + TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE));
        BrowserUtils.waitAndClickElement(webDriver, addAnimalButtonStaff);
        BrowserUtils.waitAndClickElement(webDriver, removeAnimalButtonStaff);
        BrowserUtils.pause(3);
        BrowserUtils.waitAndClickElement(webDriver, staffNextButton);
    }

    private void enterIncorrectUserInputForStaff(String herdno) throws Exception {
        enterIncorrectAnimalDataForStaff(herdno);
        enterIncorrectEligibleAreaOfHoldingDataForStaff(herdno);
        enterIncorrectEligibleAreaOfGrasslandDataForStaff(herdno);
        enterIncorrectStoragePeroidDropdownDataForStaff();
        biodiversityMeasuresCheckBoxForStaff();
        trainingRadioButtonsForStaff();
        termsAndCondtionsCheckboxForStaff();
    }

    @Override
    public void createApplicationAndClickCancel(String herdno) throws Exception {
        enterValidUserInputForStaff(herdno);
        BrowserUtils.waitAndClickElement(webDriver, cancelApplicationButtonStaff);
    }

    @Override
    public void createApplicationEnterValidUserInputAndClickSaveAsDraft(String herdno) throws Exception {
        enterValidUserInputForStaff(herdno);
        BrowserUtils.waitAndClickElement(webDriver, saveAsDraftButtonStaff);
        BrowserUtils.waitVisibility(webDriver, appSavedSuccText);
        BrowserUtils.waitAndClickElement(webDriver, appSavedSuccCloseButton);

    }

    @Override
    public void createApplicationWithNoDataEnterValidUserInputAndClickSaveAsDraft(String herdno) {
        noDataGivenEnterValidUserInputForStaff();
        BrowserUtils.waitAndClickElement(webDriver, saveAsDraftButtonStaff);
        BrowserUtils.waitVisibility(webDriver, appSavedSuccText);
        BrowserUtils.waitAndClickElement(webDriver, appSavedSuccCloseButton);
    }

    @Override
    public void createApplicationEnterValidUserInputForSubmit(String herdno) throws Exception {
        enterValidUserInputForStaff(herdno);
        BrowserUtils.waitAndClickElement(webDriver, saveAsSubmitButtonStaff);
        BrowserUtils.waitVisibility(webDriver, appSuccSubmittedText);
        BrowserUtils.waitAndClickElement(webDriver, appSavedSuccCloseButton);
    }

    @Override
    public void createApplicationEnterIncorrectUserInputForSubmit(String herdno) throws Exception {
        enterIncorrectUserInputForStaff(herdno);
        BrowserUtils.waitAndClickElement(webDriver, saveAsSubmitButtonStaff);
    }

    @Override
    public void createApplicationWithNoDataEnterValidUserInputForSubmit(String herdno) {
        noDataGivenEnterValidUserInputForStaff();
        BrowserUtils.waitAndClickElement(webDriver, saveAsSubmitButtonStaff);
        BrowserUtils.waitVisibility(webDriver, appSuccSubmittedText);
        BrowserUtils.waitAndClickElement(webDriver, appSavedSuccCloseButton);
    }

    @Override
    public void clickCreateApplicationNoUserInputAndClickSaveAsDraft() {
        throw new NotImplementedException();
    }

    @Override
    public void getCustomerDetails() {
        TestDataHolder.addRecord(TestDataHolder.CUSTOMER_BUSINESS_ID_STAFF_VALUE,
                customerBusinessIdStaffLabel.getText());
        log.warn("TestDataHolder.CUSTOMER_BUSINESS_ID_STAFF_VALUE = "
                + TestDataHolder.getTestDataRecord(TestDataHolder.CUSTOMER_BUSINESS_ID_STAFF_VALUE));

        TestDataHolder.addRecord(TestDataHolder.CUSTOMER_START_DATE_STAFF_VALUE,
                customerStartDateStaffLabel.getText());
        log.warn("TestDataHolder.CUSTOMER_START_DATE_STAFF_VALUE = "
                + TestDataHolder.getTestDataRecord(TestDataHolder.CUSTOMER_START_DATE_STAFF_VALUE));

    }

}
