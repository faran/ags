package ie.gov.agriculture.agschemes.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.ibatis.datasource.pooled.PooledDataSource;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.jdbc.SQL;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.joda.time.LocalDate;
import org.json.JSONArray;
import org.junit.AssumptionViolatedException;

import com.google.common.base.Strings;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
//import ie.gov.agriculture.sso.stepdefinitions.StoredProcedureSteps;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;
import oracle.jdbc.OracleTypes;
import oracle.sql.CLOB;

@Log4j2
public class DatabaseUtils {

    @NonNull
    private final String environment;

    public DatabaseUtils(String environment) {
        this.environment = environment;
    }

    public ResultSet executeQueryInDb(String Stmt) throws Exception {
        log.debug("Executing Statement in database: " + Stmt);
        Statement statement = getSessionFactory().openSession(true).getConnection().createStatement();
        return statement.executeQuery(Stmt);
    }

    public SqlSessionFactory getSessionFactory() {
        SqlSessionFactory sqlSessionFactory;
        try (InputStream configsIs = Resources
                .getResourceAsStream(ConstantsProvider.getMYBATIS_CONFIG_FILE_PATH())) {
            sqlSessionFactory = new SqlSessionFactoryBuilder().build(configsIs, environment);
        } catch (IOException ioe) {
            throw new AssumptionViolatedException("can't read the Mybatis config file");
        }
        log.debug("Getting SqlSessionFactor for the environment: " + environment);
        return sqlSessionFactory;
    }

    public String executeQueryReturningString(String query) throws SQLException {
        log.debug("Executing Statement in database: " + query);
        String result = "";

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true);
             Connection connection = sqlSession.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            if (rs.next()) {
                result = rs.getString(1);
            }
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return result;
    }

    public boolean executeQueryCheckIfTableExists(String query) throws SQLException {
        log.debug("Executing Statement in database: " + query);
        boolean result = false;

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true);
             Connection connection = sqlSession.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            if (rs.next()) {
                result = true;
            }
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return result;
    }

    public void executeQueryAndCloseConnection(String query) throws SQLException {
        log.debug("Executing Statement in database: " + query);
        Connection connection = null;
        Statement statement = null;
        ResultSet rs = null;
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            connection = sqlSession.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(query);
        } finally {
            rs.close();
            statement.close();
            connection.close();
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return;
    }

    public ResultSet executeQueryOnOpenConnection(Statement statement, String query) throws SQLException {
        log.debug("Executing Statement in database: " + query);
        ResultSet rs = null;
        try {
            rs = statement.executeQuery(query);
        } finally {
        }
        return rs;
    }

    public BigDecimal getNextValFromSequence(String sequenceName) throws Exception {
        ResultSet rs = null;
        BigDecimal result = null;
        String query = "select " + sequenceName + ".nextval from dual";
        SqlSessionFactory sqlSessionFactory = this.getSessionFactory();
        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            try (Statement stmt = sqlSession.getConnection().createStatement()) {
                rs = stmt.executeQuery(query);
                rs.next();
                result = rs.getBigDecimal(1);
                log.debug("Next value from sequence " + sequenceName + ":" + result);
            } catch (SQLException se) {
                log.fatal("error while getting next value from sequence " + sequenceName);
                se.printStackTrace();
            } finally {
                if (rs != null && !rs.isClosed()) {
                    rs.close();
                }
            }
            return result;
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
    }

    public int getCountOfOpenDatabaseSessions() throws Exception {
        ResultSet rs = null;
        List<String> result = new ArrayList<>();

        InetAddress addr;
        addr = InetAddress.getLocalHost();
        String query = "select sid,serial#,inst_id from  gv$session where machine like '"
            + addr.getHostName()
            + "' and program NOT LIKE 'SQL Developer'";

        SqlSessionFactory sqlSessionFactory = this.getSessionFactory();
        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            try (Statement stmt = sqlSession.getConnection().createStatement()) {

                rs = stmt.executeQuery(query);
                while (rs.next()) {
                    BigDecimal sid = rs.getBigDecimal("sid");
                    BigDecimal serialNumber = rs.getBigDecimal("serial#");
                    BigDecimal instID = rs.getBigDecimal("inst_id");
                    result.add(sid + "|" + serialNumber + "|" + instID);
                }
            } catch (SQLException se) {
                log.fatal("error while getting count of open sessions");
                se.printStackTrace();
            } finally {
                if (rs != null && !rs.isClosed()) {
                    rs.close();
                }
            }

        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        if (result.size() > 14) {
            log.info("result.size() = " + result.size());
        }
        return result.size() + 1;
    }

    /**
     * calls a database function with a single int parameter and return the result
     *
     * @param functionName
     *            the fully qualified name of the function
     * @param inputParamToFunction
     *            int parameter to the function as String
     * @param oracleType
     *            as in {@link oracle.jdbc.OracleTypes} for the return value
     * @return ResultSet in the form of List of Maps
     */
    public List<Map<String, Object>> callDbFunctionWithSingleIntParam(String functionName,
        String inputParamToFunction, int oracleType) throws SQLException, IOException {
        List<Map<String, Object>> rows = null;
        String functionCall = "{?=call " + functionName + "(?)}";

        ResultSet rs = null;
        CallableStatement statement = null;
        Connection connection = null;
        SqlSessionFactory sqlSessionFactory = this.getSessionFactory();
        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            connection = this.getSessionFactory().openSession(true).getConnection();
            statement = connection.prepareCall(functionCall);
            statement.registerOutParameter(1, oracleType);
            statement.setInt(2, Integer.parseInt(inputParamToFunction));
            statement.execute();
            rs = (ResultSet) statement.getObject(1);
            rows = convertResultSetToListOfMaps(rs);
        } finally {
            rs.close();
            statement.close();
            connection.close();
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return rows;
    }

    public static List<Map<String, Object>> convertResultSetToListOfMaps(ResultSet resultSet)
        throws SQLException, IOException {
        ResultSetMetaData resMetaData = resultSet.getMetaData();
        int numColumns = resMetaData.getColumnCount();
        List<Map<String, Object>> rows = new ArrayList<>();
        while (resultSet.next()) {
            Map<String, Object> row = new HashMap<>(numColumns);
            for (int i = 1; i <= numColumns; ++i) {
                String columnName = resMetaData.getColumnName(i);
                log.debug("copy column " + columnName + " from ResultSet");
                if (columnName.equals("SPF_FEATURE_ATTRIBUTES")) {
                    Object jsonAsObject = resultSet.getObject(i);
                    String jsonAsString = getStringFromClobAsObject(jsonAsObject);
                    row.put(columnName, jsonAsString);
                } else {
                    row.put(columnName, resultSet.getObject(i));
                }
            }
            rows.add(row);
        }
        return rows;
    }

    private static String getStringFromClobAsObject(Object clobAsObject)
        throws SQLException, IOException {
        Clob clob = (Clob) clobAsObject;
        InputStream in = clob.getAsciiStream();
        StringWriter stringWriter = new StringWriter();
        IOUtils.copy(in, stringWriter);
        return stringWriter.toString();
    }

    public <T> T callDbFunctionWithSingleIntParam(String functionName, String inputParamToFunction,
        int oracleType, Class<T> returnTypeClass) throws Exception {
        String functionCall = "{?=call " + functionName + "(?)}";
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        // try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {

        try (CallableStatement ctmt = sqlSessionFactory.openSession(true).getConnection()
            .prepareCall(functionCall)) {
            ctmt.registerOutParameter(1, oracleType);
            ctmt.setInt(2, Integer.parseInt(inputParamToFunction));
            ctmt.execute();
            return returnTypeClass.cast(ctmt.getObject(1));
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource())
                .forceCloseAll();
        }

    }

    public byte[] callDbFunctionWithoutParams(String functionName) throws Exception {
        CallableStatement statement = null;
        Connection connection = null;
        String functionCall = "{?=call " + functionName + "()}";
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();
        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            connection = sqlSession.getConnection();
            statement = connection.prepareCall(functionCall);
            statement.registerOutParameter(1, OracleTypes.BLOB);
            statement.execute();
            return statement.getBytes(1);
        } finally {
            statement.close();
            connection.close();
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
    }

    /**
     * @return parcel label or feature label related to this hashcode
     */
    public String getFeatureLabelFromHashCode(String hashCode) throws Exception {
        String parcelLabel = "";
        String query = "select pklp_bps_inet.GetHashCodeVal('" + hashCode + "','L') from dual";
        parcelLabel = executeQueryReturningString(query);
        log.debug("parcel label related to hashcode is: " + parcelLabel);
        return parcelLabel;
    }

    public String queryDbForHerdNumberForParcel(BigDecimal parcelId) throws Exception {
        String herdNumber;
        herdNumber = "";
        log.debug(
            "trying query the VWDP_BPS_CLAIMS for the herd number of parcel " + parcelId.toString());
        String query = "select SPH_HERD_NO from VWDP_BPS_CLAIMS WHERE LNU=" + parcelId.toString();
        List<Map<String, Object>> herdNumListOfMaps;

        Connection connection = null;
        Statement statement = null;
        ResultSet rs = null;

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            connection = sqlSession.getConnection();
            statement = connection.createStatement();
            rs = statement.executeQuery(query);
            herdNumListOfMaps = resultSetToListOfMaps(rs);
        } finally {
            rs.close();
            statement.close();
            connection.close();
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        if (!herdNumListOfMaps.isEmpty()) {
            herdNumber = herdNumListOfMaps.get(0).get("SPH_HERD_NO").toString();
        }
        if (Strings.isNullOrEmpty(herdNumber)) {
            int holdingId = getParcelHoldingId(parcelId);
            if (holdingId != 0) {
                herdNumber = getHerdNumberFromHoldingId(holdingId);
            }
        }
        log.debug("Herd Number for parcel id " + parcelId.toString() + " SPH_HERD_NO= " + herdNumber);
        return herdNumber;
    }

    /**
     * Convert the ResultSet to a List of Maps, where each Map represents a row with columnNames and columValues
     */
    List<Map<String, Object>> resultSetToListOfMaps(ResultSet rs) throws SQLException {
        try {
            ResultSetMetaData md = rs.getMetaData();
            int columns = md.getColumnCount();
            List<Map<String, Object>> rows = new ArrayList<>();
            while (!rs.isClosed() && rs.next()) {
                Map<String, Object> row = new HashMap<>(columns);
                for (int i = 1; i <= columns; ++i) {
                    row.put(md.getColumnName(i), rs.getObject(i));
                }
                rows.add(row);
            }
            return rows;
        } finally {
            if (rs != null) {
                if (!rs.isClosed()) {
                    rs.close();
                }
            }
        }
    }

    public int getParcelHoldingId(BigDecimal parcelId) throws Exception {
        List<Map<String, Object>> jsonForParcelInfoAsListOfMap = getParcelInfoAsListOfClobMaps(
            parcelId);
        int holdingId = 0;
        JSONArray parcelInfoAsJsonArray;
        if (!jsonForParcelInfoAsListOfMap.isEmpty()) {
            CLOB clob = (CLOB) jsonForParcelInfoAsListOfMap.get(0).values().iterator().next();
            if (clob == null || clob.stringValue().equals(null)) {
                return holdingId;
            }
            parcelInfoAsJsonArray = new JSONArray(clob.stringValue());
            if (parcelInfoAsJsonArray.length() != 0) {
                holdingId = parcelInfoAsJsonArray.getJSONObject(0).getInt("slu_holding_id");
                log.debug("holding id= " + holdingId);
            }
        }
        return holdingId;
    }

    private String getHerdNumberFromHoldingId(int holdingId) throws Exception {
        String herdNumber = "";
        String query = new SQL().SELECT("get_herd(" + holdingId + ")").FROM("dual").toString();

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true);
             Connection connection = sqlSession.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            if (rs.next()) {
                herdNumber = rs.getString(1);
            }
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return herdNumber;
    }

    private List<Map<String, Object>> getParcelInfoAsListOfClobMaps(BigDecimal parcelId)
        throws Exception {
        log.debug("getting parcel info from BPS..");
        int year = LocalDate.now().year().get();
        String query = new SQL().SELECT(
            "PKDP_LPISINET_INTEGRATION.FN_CALCSCHEMELANDUNITJSON(" + parcelId + ",'" + year + "')")
            .FROM("dual").toString();
        log.debug(query);
        List<Map<String, Object>> jsonForParcelInfoAsListOfMap;

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true);
             Connection connection = sqlSession.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(query)) {
            jsonForParcelInfoAsListOfMap = resultSetToListOfMaps(rs);
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }

        return jsonForParcelInfoAsListOfMap;
    }

    public int executeUpdateInDb(String Stmt) throws Exception {
        Connection connection = null;
        Statement statement = null;
        int numberOfUpdatedRows;

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            connection = sqlSession.getConnection();
            statement = connection.createStatement();
            log.debug("Executing Statement in database: " + Stmt);
            numberOfUpdatedRows = statement.executeUpdate(Stmt);
            log.debug("number of rows updated: " + numberOfUpdatedRows);
            sqlSession.commit(true);
        } finally {
            assert statement != null;
            statement.close();
            connection.close();
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return numberOfUpdatedRows;
    }

    public void executeDeleteInDb(String Stmt) throws Exception {
        ResultSet rs = null;
        int numberOfUpdatedRows = 0;

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true);
             Connection connection = sqlSession.getConnection();
             Statement statement = connection.createStatement()) {
            log.debug("Executing Statement in database: " + Stmt);
            numberOfUpdatedRows = statement.executeUpdate(Stmt);
            log.debug("number of rows updated: " + numberOfUpdatedRows);
            log.info("SQL query deleted tables");
            sqlSession.commit();
        } finally {
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
    }

    public ArrayList<String> getFirstRowList(String query) throws IOException, SQLException {

        String result = "";

        Connection connection = null;
        Statement statement = null;
        ResultSet rs = null;
        ArrayList<String> allResults = new ArrayList<>();

        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(
            TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT))
                .getSessionFactory();

        try (SqlSession sqlSession = sqlSessionFactory.openSession(true)) {
            connection = sqlSession.getConnection();
            statement = connection.createStatement();
            // allResults.add(result.getString("Enter the columnname here");
            rs = statement.executeQuery(query);
            // get column size
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            if (rs.next()) {
                for (int i = 1; i < columnsNumber; i++) {
                    log.warn("all results current value: " + rs.getString(i).toString());
                    allResults.add(result = rs.getString(i).toString());
                    log.info("allresults " + allResults.get(i - 1));
                    log.info("allresults count " + i);
                    // allResults.add(result = rs.getString(2).toString());
                }

            }

        } finally {
            rs.close();
            statement.close();
            connection.close();
            ((PooledDataSource) sqlSessionFactory.getConfiguration().getEnvironment().getDataSource()).forceCloseAll();
        }
        return allResults;
    }

}
