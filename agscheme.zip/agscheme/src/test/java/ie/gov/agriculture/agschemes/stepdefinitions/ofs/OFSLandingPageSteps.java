package ie.gov.agriculture.agschemes.stepdefinitions.ofs;

import org.apache.commons.lang.NotImplementedException;

import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class OFSLandingPageSteps extends DriverFactory {

    public OFSLandingPageSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @And("user closes popup menu")
    public void userClosesPopupMenu() {
        ofsLandingPage.clickCloseButton();
    }

    @And("user is at ofs landing page")
    public boolean userIsAtOfsLandingPage() {
        // TODO: Implement me
        return false;
        // return ofsLandingPage.IsAt();
    }

    @And("user clicks menu")
    public void userClicksMenu() {
        ofsLandingPage.clickMenuButton();
    }

    @And("user clicks reports")
    public void userClicksReports() {
        ofsLandingPage.clickReportButton();
    }

    @And("^user selects scheme (.*)$")
    public void userSelectsAScheme(String scheme) {
        ofsLandingPage.selectScheme(scheme);
    }

    @And("^user inputs herd no (.*)$")
    public void userInputsHerdNo(String herdNo) {
        ofsLandingPage.selectHerdNoSearch(herdNo);
    }

    @And("user clicks search")
    public void userClicksSearch() {
        ofsLandingPage.clickSearchButton();
    }

    @And("^user selects reportGroup (.*)")
    public void userSelectsReportGroup(String group) {
        ofsLandingPage.selectReportGroup(group);
    }

    @And("^user selects report (.*)")
    public void userSelectsReport(String report) {
        ofsLandingPage.selectReport(report);
    }

    @And("^user selects second scheme option (.*)")
    public void userSelectSchemeAgain(String scheme) {
        ofsLandingPage.selectSchemeAgain(scheme);
    }

    @And("^user selects application type (.*)")
    public void userSelectsApplicationType(String type) {
        ofsLandingPage.selectApplicationType(type);
    }

    @And("^user selects schemeYear (.*)")
    public void userSelectsSchemeYear(String year) {
        ofsLandingPage.selectSchemeYear(year);
    }

    @And("^user selects application status (.*)")
    public void userSelectsApplicationStatus(String status) {
        ofsLandingPage.selectApplicationStatus(status);
    }

    @And("user clicks validate button")
    public void userClicksValidateButton() {
        ofsLandingPage.clickValidateButton();
    }

    @Then("user clicks show report")
    public void userClicksShowReport() {
        ofsLandingPage.clickShowReportButton();
    }

    @And("^assert file is downloaded$")
    public void assertFileIsDownloaded() throws Throwable {
        // TODO: Add an assertion to check that the file existed and was deleted
        ofsLandingPage.fileExist();
        throw new NotImplementedException("Add an assertion to check that the file existed and was deleted");
    }

    @And("^user selects a scheme (.*)")
    public void userSelectsAOFSScheme(String scheme) {
        ofsLandingPage.selectDropDown(scheme);
    }

    @And("user clicks new application button")
    public void userClicksNewApplicationButton() {
        ofsLandingPage.clickNewApplicationButton();
    }

    @And("user clicks confirm scheme button")
    public void userClicksConfirmSchemeButton() {
        ofsLandingPage.clickConfirmSchemeButton();
    }

}
