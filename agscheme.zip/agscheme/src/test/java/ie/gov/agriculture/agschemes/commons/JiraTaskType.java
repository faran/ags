package ie.gov.agriculture.agschemes.commons;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Allowed Jira task types for digitization tasks
 */
public final class JiraTaskType {

  public static Map<String, List<String>> getMapOfTaskTypesAndSubtaskTypes() {
    Map<String, List<String>> taskTypesAndSubTaskTypes = new HashMap<>();
    taskTypesAndSubTaskTypes
        .put(BpsParcelTask.MAIN_TASK_NAME, BpsParcelTask.getAllSubTasksAsList());
    taskTypesAndSubTaskTypes
        .put(RemoteSensingTask.MAIN_TASK_NAME, RemoteSensingTask.getAllSubTasksAsList());
    taskTypesAndSubTaskTypes
        .put(IforisDigitizingTask.MAIN_TASK_NAME, IforisDigitizingTask.getAllSubTasksAsList());
    taskTypesAndSubTaskTypes
        .put(BpsInspectionTask.MAIN_TASK_NAME, BpsInspectionTask.getAllSubTasksAsList());
    return taskTypesAndSubTaskTypes;
  }

  public static class BpsParcelTask {

    public static final String MAIN_TASK_NAME = "BPS - Parcel Task";
    public static final String INET_APPLICATION_SUBTASK = "iNet Application";
    public static final String ERROR_RESPONSE = "Error Response";
    public static final String TEMPORARY_SUBDIVISON = "Temporary Subdivision";
    public static final String LPIS_REVIEW_2019 = "2019 LPIS Review";
    public static final String LPIS_QA_FIELD_VISIT = "LPIS QA Field Visit";
    public static final String LPIS_QA = "LPIS QA";
    public static final String EFA_DIGITIZING = "EFA Digitizing";

    public static final List<String> getAllSubTasksAsList() {
      List<String> subTasks = new ArrayList<>();
      subTasks.add(INET_APPLICATION_SUBTASK);
      subTasks.add(ERROR_RESPONSE);
      subTasks.add(TEMPORARY_SUBDIVISON);
      subTasks.add(LPIS_REVIEW_2019);
      subTasks.add(LPIS_QA_FIELD_VISIT);
      subTasks.add(LPIS_QA);
      subTasks.add(EFA_DIGITIZING);
      return subTasks;
    }
  }

  public static class RemoteSensingTask {

    public static final String MAIN_TASK_NAME = "Remote Sensing Task";
    public static final String BV1_TASK = "BV1 Task";
    public static final String BV2_TASK = "BV2 Task";
    public static final String QC_TASK = "QC Task";

    public static final List<String> getAllSubTasksAsList() {
      List<String> subTasks = new ArrayList<>();
      subTasks.add(BV1_TASK);
      subTasks.add(BV2_TASK);
      subTasks.add(QC_TASK);
      return subTasks;
    }
  }

  public static final class IforisDigitizingTask {

    public static final String MAIN_TASK_NAME = "IFORIS - Digitizing Task";
    public static final String ADHOC_ADMIN_REQUEST = "Adhoc / Admin Request";
    public static final String REVISED_MAP = "Revised Map";
    public static final String NEW_CONTRACT = "New Contract";

    public static List<String> getAllSubTasksAsList() {
      List<String> subTasks = new ArrayList<>();
      subTasks.add(ADHOC_ADMIN_REQUEST);
      subTasks.add(REVISED_MAP);
      subTasks.add(NEW_CONTRACT);
      return subTasks;
    }
  }

  public static final class BpsInspectionTask {

    public static final String MAIN_TASK_NAME = "BPS - Inspection Task";
    public static final String GROUND_ELIGIBILITY = "Ground Eligibility";
    public static final String GLAS_1_INSPECTION = "GLAS 1 Inspection";
    public static final String GLAS_2_INSPECTION = "GLAS 2 Inspection";
    public static final String GLAS_3_INSPECTION = "GLAS 3 Inspection";
    public static final String OFS_INSPECTION = "OFS Inspection";
    public static final String ARTICLE_32__INSPECTION = "Article 32 Inspection";
    public static final String AEOS_INSPECTION = "AEOS Inspection";
    public static final String FIELD_VISIT = "Field Visit";
    public static final String EFA_INSPECTION = "EFA Inspection";

    public static List<String> getAllSubTasksAsList() {
      List<String> subTasks = new ArrayList<>();
      subTasks.add(GROUND_ELIGIBILITY);
      subTasks.add(GLAS_1_INSPECTION);
      subTasks.add(GLAS_2_INSPECTION);
      subTasks.add(GLAS_3_INSPECTION);
      subTasks.add(OFS_INSPECTION);
      subTasks.add(ARTICLE_32__INSPECTION);
      subTasks.add(AEOS_INSPECTION);
      subTasks.add(FIELD_VISIT);
      subTasks.add(EFA_INSPECTION);
      return subTasks;
    }
  }

}
