package ie.gov.agriculture.agschemes.utils;

import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.google.common.base.Strings;
import com.paulhammant.ngwebdriver.NgWebDriver;

import lombok.extern.log4j.Log4j2;

/** Browser utils. all methods require the iSmart to be displayed beforehand */
@Log4j2
public class BrowserUtils {

    private JavascriptExecutor javascriptExecutor;
    private WebDriver webDriver;
    private WebDriverWait wait;
    private static NgWebDriver ngwebDriver;

    public BrowserUtils(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.wait = new WebDriverWait(webDriver, 15);
        webDriver.manage().timeouts().setScriptTimeout(5, TimeUnit.SECONDS);
        webDriver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
        if (webDriver instanceof JavascriptExecutor) {
            javascriptExecutor = (JavascriptExecutor) webDriver;
        } else {
            throw new IllegalArgumentException("provided webdriver can't execute " + "js commands");
        }
        ngwebDriver = new NgWebDriver(javascriptExecutor);
    }

    /**********************************************************************************
     ** ACTION METHODS
     **********************************************************************************/

    public static void keyPress(WebDriver driver, Keys keys){
        Actions ob = new Actions(driver);
        try {
            ob.sendKeys(keys).build().perform();
            System.out.println(keys.toString() + "pressed");
        }

        catch (Exception e) {
            System.out.println(keys.toString() + "pressed");
        }
    }

    /**********************************************************************************
     ** CLICK METHODS /
     ***********************************************************************************/


    public static <T> void waitAndClickElement(WebDriver webDriver, T elementAttr) {
        log.debug("Waiting Clickable: " + elementAttr);
        FluentWait<WebDriver> wait = new FluentWait<>(webDriver)
                .withTimeout(Duration.ofSeconds(30))
                .pollingEvery(Duration.ofSeconds(2))
                .ignoring(NoSuchElementException.class);
        try {
            if (elementAttr.getClass().getName().contains("By")) {
                wait.until(ExpectedConditions.elementToBeClickable((By) elementAttr)).click();
            } else {
                wait.until(ExpectedConditions.elementToBeClickable((WebElement) elementAttr)).click();
            }
        } catch (NoSuchElementException e) {
            log.error("This Element is not visible: " + e.getMessage());
            throw (e);
        } catch (WebDriverException e) {
            log.error("WebDriver couldn't locate this element: " + e.getMessage());
            throw (e);
        }
    }

    public static void clickElement(WebDriver driver, WebElement element) {
        try {
            new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(element));
            element.click();
            System.out.println("Successfully clicked on the WebElement: " + "<" + element.toString() + ">");
            log.debug("Successfully clicked on the WebElement: " + "<" + element.toString() + ">");
        } catch (Exception e) {
            System.out.println("Unable to click on WebElement, Exception: " + e.getMessage());
            Assert.fail("Unable to click on the WebElement, using locator: " + "<" + element.toString() + ">");
        }

    }

    /**********************************************************************************
     ** SEND KEYS METHODS /
     **********************************************************************************/
    public static void sendKeysToWebElement(WebDriver driver, WebElement element, String textToSend) {
        try {
            waitUntilWebElementIsVisible(driver, element);
            element.clear();
            element.sendKeys(textToSend);
            log.debug("Successfully Sent the following keys: '" + textToSend + "' to element: " + "<"
                + element.toString() + ">");
            System.out.println("Successfully Sent the following keys: '" + textToSend + "' to element: " + "<"
                + element.toString() + ">");
        } catch (Exception e) {
            System.out.println("Unable to locate WebElement: " + "<" + element.toString()
                + "> and send the following keys: " + textToSend);
            // Assert.fail("Unable to send keys to WebElement, Exception: " +
            // e.getMessage());
        }
    }

    /**********************************************************************************
     ** WAIT METHODS
     **********************************************************************************/

    public static boolean waitUntilWebElementIsVisible(WebDriver driver, WebElement element) {
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOf(element));
            log.debug("WebElement is visible using locator: " + "<" + element.toString() + ">");
            System.out.println("WebElement is visible using locator: " + "<" + element.toString() + ">");
            return true;
        } catch (Exception e) {
            System.out.println("WebElement is NOT visible, using locator: " + "<" + element.toString() + ">");
            // Assert.fail("WebElement is NOT visible, Exception: " + e.getMessage());
            return false;
        }
    }
    
    public static boolean waitUntilWebElementIsVisibleUsingByLocator(WebDriver driver, By by) {
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOfElementLocated(by));
            log.debug("Element is visible using By locator: " + "<" + by.toString() + ">");
            System.out.println("Element is visible using By locator: " + "<" + by.toString() + ">");
            return true;
        } catch (Exception e) {
            System.out.println("WebElement is NOT visible, using By locator: " + "<" + by.toString() + ">");
            // Assert.fail("WebElement is NOT visible, Exception: " + e.getMessage());
            return false;
        }
    }

    public static boolean waitUntilWebElementClickable(WebDriver driver, WebElement element) {
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.elementToBeClickable(element));
            log.debug("WebElement is clickable using locator: " + "<" + element.toString() + ">");
            System.out.println("WebElement is clickable using locator: " + "<" + element.toString() + ">");
            return true;
        } catch (Exception e) {
            System.out.println("WebElement is NOT clickable using locator: " + "<" + element.toString() + ">");
            return false;
        }
    }

    public static boolean waitUntilWebElementClickableUsingByLocator(WebDriver driver, By by) {
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.elementToBeClickable(by));
            log.debug("WebElement is clickable using locator: " + "<" + by.toString() + ">");
            System.out.println("WebElement is clickable using locator: " + "<" + by.toString() + ">");
            return true;
        } catch (Exception e) {
            System.out.println("WebElement is NOT clickable using locator: " + "<" + by.toString() + ">");
            return false;
        }
    }

    public static boolean waitUntilWebElementsAreVisible(WebDriver driver, List<WebElement> elements) {
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOfAllElements(elements));
            log.debug("WebElement is clickable using locator: " + "<" + elements.toString() + ">");
            System.out.println("WebElement is clickable using locator: " + "<" + elements.toString() + ">");
            return true;
        } catch (Exception e) {
            System.out.println("WebElement is NOT clickable using locator: " + "<" + elements.toString() + ">");
            return false;
        }
    }

    public static void pause(Integer milliseconds) {
        try {
            TimeUnit.SECONDS.sleep(milliseconds);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
        
    public static <T> void waitUntilWebElementIsInvisible(WebDriver driver, T elementAttr) {
        try {
        	if(elementAttr.getClass().getName().contains("By")) {
                new WebDriverWait(driver, 30).until(ExpectedConditions.invisibilityOfElementLocated((By) elementAttr));
            }else {
        		new WebDriverWait(driver, 30).until(ExpectedConditions.invisibilityOf((WebElement) elementAttr));
            }
            log.debug("WebElement is visible using locator: " + "<" + elementAttr.toString() + ">");
        } catch (Exception e) {
            System.out.println("WebElement is NOT visible: " + "<" + elementAttr.toString() + ">");
        }
    }

    public static <T> void waitVisibility(WebDriver driver, T elementAttr) {
        try {
            if(elementAttr.getClass().getName().contains("By")) {
                new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOfElementLocated((By) elementAttr));
            }else {
                new WebDriverWait(driver, 30).until(ExpectedConditions.visibilityOf((WebElement) elementAttr));
            }
            log.debug("WebElement is visible using locator: " + "<" + elementAttr.toString() + ">");
        } catch (Exception e) {
            System.out.println("WebElement is NOT visible: " + "<" + elementAttr.toString() + ">");
        }
    }



    /**********************************************************************************
     ** GETTING ATTRIBUTE VALUE FROM ELEMENTS
     **********************************************************************************/
    public static String getText(WebDriver driver, WebElement element) {
        String strText = null;
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOf(element));
            strText = element.getText().trim();
            log.debug("Text with in the Element: " + "<" + strText + ">");
            System.out.println("Text with in the Element: " + "<" + strText + ">");
            return strText;
        } catch (NullPointerException e) {
            System.out.println(
                "unable to get the text from the WebElement using locator: " + "<" + element.toString() + ">");
        }
        return strText;
    }

    public static String getValueFromInputBox(WebDriver driver, WebElement element) {
        String strText = null;
        try {
            new WebDriverWait(driver, 15).until(ExpectedConditions.visibilityOf(element));
            strText = element.getAttribute("value").trim();
            log.debug("value with in the Element: " + "<" + strText + ">");
            System.out.println("value with in the Element: " + "<" + strText + ">");
            return strText;
        } catch (NullPointerException e) {
            System.out.println(
                "unable to get the value from the WebElement using locator: " + "<" + element.toString() + ">");
        }
        return strText;
    }

    /**********************************************************************************
     ** NGWEBDRIVER METHODS
     *
     * @return
     **********************************************************************************/

    public static void waitForAngularToLoad(WebDriver driver) {
        JavascriptExecutor javascriptExecutor;
        javascriptExecutor = (JavascriptExecutor) driver;
        ngwebDriver = new NgWebDriver(javascriptExecutor);
        ngwebDriver.waitForAngularRequestsToFinish();

    }

    /**********************************************************************************
     ** METHODS FOR ANGULAR APPLICATIONS
     **********************************************************************************/

    /**********************************************************************************
     ** METHODS FOR "YES(0)" OR "NO(1)" RADIO BUTTON FROM RADIO GROUP
     **********************************************************************************/

    public static void clickYesRadioButtonFromRadioGroup(WebDriver driver, WebElement element, By radioButtonLocator)
        throws InterruptedException, IOException {
        try {
            waitUntilWebElementIsVisible(driver, element);
            List<WebElement> radioButtons = element.findElements(radioButtonLocator);
            clickElement(driver, radioButtons.get(0));

        } catch (Exception e) {
            System.out.println("Unable to click on the radio button, Exception: " + e.getMessage());
        }

    }

    public static void clickNoRadioButtonFromRadioGroup(WebDriver driver, WebElement element, By radioButtonLocator)
        throws InterruptedException, IOException {
        try {
            waitUntilWebElementIsVisible(driver, element);
            List<WebElement> radioButtons = element.findElements(radioButtonLocator);
            clickElement(driver, radioButtons.get(1));
        } catch (Exception e) {
            System.out.println("Unable to click on the radio button, Exception: " + e.getMessage());
        }

    }

    public static void selectDataFromMultiSelect(WebDriver driver) {
        By matOptionsLocator = By.xpath("//mat-option[@role='option']");
        waitUntilWebElementClickableUsingByLocator(driver, matOptionsLocator);
        List<WebElement> matOptions = driver.findElements(matOptionsLocator);
        waitUntilWebElementsAreVisible(driver, matOptions);
        for (int i = 0; i < matOptions.size(); i++) {
            waitUntilWebElementClickable(driver, matOptions.get(i));
            WebElement matText = matOptions.get(i).findElement(By.xpath("//span[@class='mat-option-text']"));
            if (matText.getText() != "Other") {
                clickElement(driver, matOptions.get(i));
                log.debug("Option" + matText.getText() + "is selected");
                if (i == 1) {
                    break;
                }
            }
        }
        keyPress(driver, Keys.TAB);
    }

    public static void selectUnCheckedDataFromMultiSelect(WebDriver driver) {
        By matOptionsLocator = By.xpath("//mat-option[@role='option'][@aria-selected='false']");
        waitUntilWebElementClickableUsingByLocator(driver, matOptionsLocator);
        List<WebElement> matOptions = driver.findElements(matOptionsLocator);
        waitUntilWebElementsAreVisible(driver, matOptions);
        for (int i = 0; i < matOptions.size(); i++) {
            waitUntilWebElementClickable(driver, matOptions.get(i));
            WebElement matTextElement = driver.findElement(By
                .xpath("//mat-option[@role='option'][@aria-selected='false'][1]//span[@class='mat-option-text']"));
            String matText = matTextElement.getText().trim();
            System.out.println(matText);
            if (!matText.equals("Other")) {
                clickElement(driver, matTextElement);
                log.debug("Option" + matText + "is selected");
                if (i == 1) {
                    break;
                }
            }
        }
        keyPress(driver, Keys.TAB);
    }

    /**********************************************************************************
     ** GETTING ROW BY CELL TEXT IN A TABLE
     **********************************************************************************/

    public static int getRowbyCellText(WebDriver driver, String tableLocator, String compareString) {
        String strCellVal = null;
        int row = 0;
        try {
            WebElement table = driver.findElement(By.xpath(tableLocator));
            waitUntilWebElementIsVisible(driver, table);
            List<WebElement> rows = table.findElements(By.tagName("tr"));
            for (int i = 1; i <= rows.size(); i++) {
                row = i;
                List<WebElement> col = table.findElements(By.xpath(tableLocator + "/tr[" + row + "]/td"));
                for (int j = 1; j <= col.size(); j++) {
                    strCellVal = driver.findElement(By.xpath(tableLocator + "/tr[" + row + "]/td[" + j + "]"))
                        .getText();
                    if (strCellVal != null && strCellVal != "") {
                        if (strCellVal.contains(compareString)) {
                            break;
                        }
                    }
                }
                if (strCellVal != null && strCellVal != "") {

                    if (strCellVal.contains(compareString)) {
                        break;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return row;

    }

    /**********************************************************************************
     ** GETTING ROW COUNT FROM A TABLE
     **********************************************************************************/
    public static int tableRowCount(WebDriver driver, By byTableLocator) {
        int rowcount = 0;
        try {
            WebElement table = driver.findElement(byTableLocator);
            List<WebElement> rows = table.findElements(By.tagName("tr"));
            log.debug("No of rows present in table is " + rows.size());
            rowcount = rows.size();
            return rowcount;
        } catch (Exception e) {
            log.debug(e.getMessage());
        }
        return rowcount;
    }

    /**********************************************************************************
     ** ANGULAR WAITS
     **********************************************************************************/

    public static void waitUntilAngular5Ready(WebDriver driver) {
        try {
            Object angular5Check = ((JavascriptExecutor) driver)
                .executeScript("return getAllAngularRootElements()[0].attributes['ng-version']");
            if (angular5Check != null) {
                Boolean angularPageLoaded = (Boolean) ((JavascriptExecutor) driver)
                    .executeScript("return window.getAllAngularTestabilities().findIndex(x=>!x.isStable()) ===-1");
                if (!angularPageLoaded) {
                    poll(20);
                    waitForAngular5Load(driver);
                    poll(20);
                }
            }
        } catch (WebDriverException ignored) {
        }
    }

    public static void waitForAngular5Load(WebDriver driver) {
        String angularReadyScript = "return window.getAllAngularTestabilities().findIndex(x=>!x.isStable()) === -1";
        angularLoads(angularReadyScript, driver);
    }

    public static void angularLoads(String angularReadyScript, WebDriver driver) {
        try {
            ExpectedCondition<Boolean> angularLoad = Webdriver -> Boolean
                .valueOf(((JavascriptExecutor) driver).executeScript(angularReadyScript).toString());
            boolean angularReady = Boolean.parseBoolean(((JavascriptExecutor) driver).executeScript(angularReadyScript).toString());
            if (!angularReady) {
                new WebDriverWait(driver, 15).until(angularLoad);
            }
        } catch (WebDriverException ignored) {
        }
    }

    public static void poll(long milis) {
        try {
            Thread.sleep(milis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void refreshPage(WebDriver driver){
        driver.navigate().refresh();
    }
}
