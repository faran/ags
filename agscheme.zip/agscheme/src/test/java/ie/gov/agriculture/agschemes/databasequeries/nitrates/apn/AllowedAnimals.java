package ie.gov.agriculture.agschemes.databasequeries.nitrates.apn;

import ie.gov.agriculture.agschemes.commons.EnvironmentHandler;
import lombok.extern.log4j.Log4j2;

/**
 * Environments where tests allowed to run on. Mainly used to facilitate the usage of {@link EnvironmentHandler}
 */
@Log4j2
public class AllowedAnimals {

    public static final String APN_GOATS = "APN_GOATS";
    public static final String APN_DEER = "APN_DEER";
    public static final String APN_PIGS = "APN_PIGS";
    public static final String APN_SHEEP = "APN_SHEEP";
    public static final String APN_CATTLE = "APN_CATTLE";
    public static final String APN_HORSES = "APN_HORSES";
}
