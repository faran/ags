package ie.gov.agriculture.agschemes.commons;

import lombok.NonNull;
import lombok.extern.log4j.Log4j2;

/** Handling environment usage */
@Log4j2
public class EnvironmentHandler {

    public static final String SSO_STAFF_USER_NAME_KEY = "SSO_STAFF_USER_NAME";
    public static final String SSO_AGENT_USER_NAME_KEY = "SSO_AGENT_USER_NAME";
    public static final String SSO_PASSWORD_KEY = "SSO_PASSWORD_KEY";

    /**
     * @param environment
     *            as returned from {@link #getEnvironmentForTest()}
     * @return The base URL need to configure RestAssured and browser testsbased on the test environment.
     */
    public static String getEnvironmentBaseUrl(@NonNull String environment) {
        return getEnvironmentBaseUrl(environment, false);
    }

    /**
     * @param environment
     *            as returned from {@link #getEnvironmentForTest()}
     * @return The base URL need to configure RestAssured and browser testsbased on the test environment.
     */
    public static String getEnvironmentBaseUrl(@NonNull String environment, boolean isForInet) {
        String rest_assured_base_urls_start = ConstantsProvider.getREST_ASSURED_BASE_URLS_START();
        if (isForInet) {
            rest_assured_base_urls_start = ConstantsProvider.getREST_ASSURED_INET_BASE_URLS_START();
        }
        String restAssuredBaseUrl = rest_assured_base_urls_start
            + environment
            + ConstantsProvider.getREST_ASSURED_BASE_URLS_END();
        log.debug("Base url= " + restAssuredBaseUrl);
        return restAssuredBaseUrl;
    }

    /**
     * @return the environment for this test as String. this works by examining the 'env' variable from the system. If
     *         the variable is null or empty this returns the default environment as configured in the properties
     *         constants.properties
     */
    public static String getEnvironmentForTest() {
        String env = System.getProperty("env");
        return AllowedEnvironments.getAllowedEnvironment(env);
    }

}
