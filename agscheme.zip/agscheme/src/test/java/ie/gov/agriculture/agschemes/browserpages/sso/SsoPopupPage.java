package ie.gov.agriculture.agschemes.browserpages.sso;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.paulhammant.ngwebdriver.NgWebDriver;

import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class SsoPopupPage {

    private JavascriptExecutor javascriptExecutor;
    private WebDriver webDriver;
    private WebDriverWait wait;
    private static NgWebDriver ngwebDriver;

    public SsoPopupPage(WebDriver webDriver) {
        this.webDriver = webDriver;
        this.wait = new WebDriverWait(webDriver, 15);
        webDriver.manage().timeouts().setScriptTimeout(5, TimeUnit.SECONDS);
        if (webDriver instanceof JavascriptExecutor) {
            javascriptExecutor = (JavascriptExecutor) webDriver;
        } else {
            throw new IllegalArgumentException("provided webdriver can't execute " + "js commands");
        }
        ngwebDriver = new NgWebDriver(javascriptExecutor);
    }

    @CacheLookup
    @FindBy(id = "broadcast-message-modal-close-button")
    private WebElement broadcastMessageCloseLabel;

    // ask should method contain driver parameter and should it be like this or below is better?
    public void clickClose(WebDriver driver) {
        broadcastMessageCloseLabel.click();
    }

    public void clickPopupClose()  {
        BrowserUtils.waitAndClickElement(webDriver, broadcastMessageCloseLabel);
    }
}
