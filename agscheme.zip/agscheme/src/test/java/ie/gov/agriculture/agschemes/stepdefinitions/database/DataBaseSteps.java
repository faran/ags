package ie.gov.agriculture.agschemes.stepdefinitions.database;

import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.dao.*;
import ie.gov.agriculture.agschemes.utils.DatabaseUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

import java.util.*;

import static ie.gov.agriculture.agschemes.utils.DateUtil.*;

public class DataBaseSteps {

    public static void getTDAS_APPLICATIONSByBusinessId(String businessId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        HashMap<String, String> params = new HashMap<>();
        params.put("APP_CURRENT_BUSINESS_ID", businessId);
        params.put("APP_SCHEME_YEAR", ConstantsProvider.getHERDYEAR());
        List<TDAS_APPLICATIONS> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONSMapper.select_by_business_id", params);
        for (TDAS_APPLICATIONS tdasApplications : list) {
                TestDataHolder.addTestDataRecord("APP_APPLICATION_ID", String.valueOf(tdasApplications.getAPP_APPLICATION_ID()), true, true);
                break;
        }
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void getTDAS_APPLICATIONSByBusinessId(String businessId, String year){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        HashMap<String, String> params = new HashMap<>();
        params.put("APP_CURRENT_BUSINESS_ID", businessId);
        params.put("APP_SCHEME_YEAR", year);
        List<TDAS_APPLICATIONS> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONSMapper.select_by_business_id", params);
        for (TDAS_APPLICATIONS tdasApplications : list) {
            TestDataHolder.addTestDataRecord("APP_APPLICATION_ID", String.valueOf(tdasApplications.getAPP_APPLICATION_ID()), true, true);
            break;
        }
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void getTDAS_APPLICATIONSByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        List<TDAS_APPLICATIONS> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONSMapper.select_by_application_id", appId);
        for (TDAS_APPLICATIONS tdasApplications : list) {
            TestDataHolder.addTestDataRecord("APP_APPLICATION_CODE", String.valueOf(tdasApplications.getAPP_APPLICATION_CODE()), true, true);
            TestDataHolder.addTestDataRecord("APP_CURRENT_BUSINESS_ID", tdasApplications.getAPP_CURRENT_BUSINESS_ID(), true, true);
            TestDataHolder.addTestDataRecord("APP_SCHEME_YEAR", String.valueOf(tdasApplications.getAPP_SCHEME_YEAR()), true, true);
            TestDataHolder.addTestDataRecord("APP_CURRENT_STATUS_CODE", String.valueOf(tdasApplications.getAPP_CURRENT_STATUS_CODE()), true, true);
            TestDataHolder.addTestDataRecord("APP_OWNER_BUSINESS_ID", tdasApplications.getAPP_OWNER_BUSINESS_ID(), true, true);
            TestDataHolder.addTestDataRecord("APP_IS_PARTNERSHIP", String.valueOf(tdasApplications.getAPP_IS_PARTNERSHIP()), true, true);
            TestDataHolder.addTestDataRecord("APP_AUDIT_USER", tdasApplications.getAPP_AUDIT_USER(), true, true);
            break;
        }
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void getTDAS_APPLICATIONS_NITRATESByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        List<TDAS_APPLICATIONS_NITRATES> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONS_NITRATESMapper.select_by_apn_application_id", appId);
        for (TDAS_APPLICATIONS_NITRATES tdasApplicationsNitrates : list) {
            TestDataHolder.addTestDataRecord("APN_APPLICATION_ID", String.valueOf(tdasApplicationsNitrates.getAPN_APPLICATION_ID()), true, true);
            TestDataHolder.addTestDataRecord("APN_CATTLE", String.valueOf(tdasApplicationsNitrates.getAPN_CATTLE()), true, true);
            TestDataHolder.addTestDataRecord("APN_SHEEP", String.valueOf(tdasApplicationsNitrates.getAPN_SHEEP()), true, true);
            TestDataHolder.addTestDataRecord("APN_HORSES", String.valueOf(tdasApplicationsNitrates.getAPN_HORSES()), true, true);
            TestDataHolder.addTestDataRecord("APN_GOATS", String.valueOf(tdasApplicationsNitrates.getAPN_GOATS()), true, true);
            TestDataHolder.addTestDataRecord("APN_DEER", String.valueOf(tdasApplicationsNitrates.getAPN_DEER()), true, true);
            TestDataHolder.addTestDataRecord("APN_NET_GRASSLAND", String.valueOf(tdasApplicationsNitrates.getAPN_NET_GRASSLAND()), true, true);
            TestDataHolder.addTestDataRecord("APN_BPS_MANUAL_RECORDING_IND", String.valueOf(tdasApplicationsNitrates.getAPN_BPS_MANUAL_RECORDING_IND()), true, true);
            TestDataHolder.addTestDataRecord("APN_AHCS_MANUAL_RECORDING_IND", String.valueOf(tdasApplicationsNitrates.getAPN_AHCS_MANUAL_RECORDING_IND()), true, true);
            TestDataHolder.addTestDataRecord("APN_STORAGE_PERIOD", String.valueOf(tdasApplicationsNitrates.getAPN_STORAGE_PERIOD()), true, true);
            TestDataHolder.addTestDataRecord("APN_TERMS_CONDITIONS_IND", String.valueOf(tdasApplicationsNitrates.getAPN_TERMS_CONDITIONS_IND()), true, true);
            TestDataHolder.addTestDataRecord("APN_BDMEASURE_WBTHORN_TRLFT_ID", String.valueOf(tdasApplicationsNitrates.getAPN_BDMEASURE_WBTHORN_TRLFT_ID()), true, true);
            TestDataHolder.addTestDataRecord("APN_AUDIT_USER", tdasApplicationsNitrates.getAPN_AUDIT_USER(), true, true);
            TestDataHolder.addTestDataRecord("APN_TRAINING_GRASSLAND_IND", String.valueOf(tdasApplicationsNitrates.getAPN_TRAINING_GRASSLAND_IND()), true, true);
            TestDataHolder.addTestDataRecord("APN_TRAINING_ENVIRONMENTAL_IND", String.valueOf(tdasApplicationsNitrates.getAPN_TRAINING_ENVIRONMENTAL_IND()), true, true);
            TestDataHolder.addTestDataRecord("APN_GRASS_LAND_PERCENT", String.valueOf(tdasApplicationsNitrates.getAPN_GRASS_LAND_PERCENT()), true, true);
            TestDataHolder.addTestDataRecord("APN_NET_AREA_OF_HOLDING", String.valueOf(tdasApplicationsNitrates.getAPN_NET_AREA_OF_HOLDING()), true, true);
            TestDataHolder.addTestDataRecord("APN_BDMEASURE_CUT_HEDGROW_ID", String.valueOf(tdasApplicationsNitrates.getAPN_BDMEASURE_CUT_HEDGROW_ID()), true, true);
            TestDataHolder.addTestDataRecord("APN_AMOUNT_SLURRY_SPREAD", String.valueOf(tdasApplicationsNitrates.getAPN_AMOUNT_SLURRY_SPREAD()), true, true);
            TestDataHolder.addTestDataRecord("APN_BDMEASURE_MAINTAIN_HROW_ID", String.valueOf(tdasApplicationsNitrates.getAPN_BDMEASURE_MAINTAIN_HROW_ID()), true, true);
            break;
        }
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void getTSAS_STATUSByStatusCode(String statusCode){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        List<TSAS_STATUS> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TSAS_STATUSMapper.select-diff-tables", statusCode);
        for (TSAS_STATUS tsasStatus : list) {
            TestDataHolder.addTestDataRecord("ST_STATUS_CODE", tsasStatus.getST_STATUS_DESCRIPTION(), true, true);
            break;
        }
        sqlSession.close();
    }

    public static boolean getTDAS_APPLICATIONSByBusinessIdAndSchemeYear(String businessId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        HashMap<String, String> params = new HashMap<>();
        params.put("APP_CURRENT_BUSINESS_ID", businessId);
        params.put("APP_SCHEME_YEAR", ConstantsProvider.getHERDYEAR());
        List<TDAS_APPLICATIONS> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONSMapper.select_by_business_id", params);
        sqlSession.clearCache();
        sqlSession.close();
        return list.isEmpty();
    }

    public static List<Long> getTDAG_NITRATESByClientIdAndYear(String clientId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        HashMap<String, String> params = new HashMap<>();
        params.put("NTR_CLIENT_ID", clientId);
        params.put("NTR_NITRATES_YEAR", "2021");
        List<TDAG_NITRATES> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAG_NITRATESMapper.select_by_ntr_client_id", params);
        List<Long> rows = new ArrayList<>();
        for (TDAG_NITRATES tdagNitrates : list) {
            rows.add(tdagNitrates.getNTR_PHOSPHATES());
        }
        sqlSession.close();
        return rows;
    }

    public static void getVWCO_AGSCH_BUSINESS_CUSTOMERSByBusinessIdAndCustomerId(String businessID, String customerId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        HashMap<String, String> params = new HashMap<>();
        params.put("BUSINESS_ID", businessID);
        params.put("CUSTOMER_ID", customerId);
        List<VWCO_AGSCH_BUSINESS_CUSTOMERS> list = sqlSession.selectList(
                "ie.gov.agriculture.agschemes.dao.VWCO_AGSCH_BUSINESS_CUSTOMERSMapper.select_by_cust_id_busin_id", params);
        for (VWCO_AGSCH_BUSINESS_CUSTOMERS vwcoAgschBusinessCustomers : list) {
            TestDataHolder.addTestDataRecord("CUSTOMER_ID",
                    String.valueOf(vwcoAgschBusinessCustomers.getCUSTOMER_ID()), true, true);
            TestDataHolder.addTestDataRecord("BUSINESS_ID",
                    vwcoAgschBusinessCustomers.getBUSINESS_ID(), true, true);
            TestDataHolder.addTestDataRecord("START_DATE",
                    String.valueOf(vwcoAgschBusinessCustomers.getSTART_DATE()), true, true);
            break;
        }
        sqlSession.close();
    }

    public static void getTDAS_APPLICATIONS_UNDER_QUERYByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        List<TDAS_APPLICATIONS_UNDER_QUERY> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONS_UNDER_QUERYMapper.select_by_application_id", appId);
        for (TDAS_APPLICATIONS_UNDER_QUERY tdas_applications_under_query : list) {
            TestDataHolder.addTestDataRecord("APD_DOCUMENT_TYPE", tdas_applications_under_query.getAPD_DOCUMENT_TYPE(), true, true);
            TestDataHolder.addTestDataRecord("APD_DOCUMENT_YEAR", String.valueOf(tdas_applications_under_query.getAPD_DOCUMENT_YEAR()), true, true);
            TestDataHolder.addTestDataRecord("APD_USER_COMMENT", tdas_applications_under_query.getAPD_USER_COMMENT(), true, true);
            TestDataHolder.addTestDataRecord("APD_AUDIT_DATE", String.valueOf(tdas_applications_under_query.getAPD_AUDIT_DATE()), true, true);
            TestDataHolder.addTestDataRecord("APD_APPLICATION_TRACKING_ID", String.valueOf(tdas_applications_under_query.getAPD_APPLICATION_TRACKING_ID()), true, true);
            break;
        }
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static boolean verifyDocId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        List<TDAS_DOCUMENTS> list = sqlSession.selectList("ie.gov.agriculture.agschemes.dao.TDAS_DOCUMENTSMapper.select_by_application_id", appId);
        for (TDAS_DOCUMENTS tdas_documents : list) {
            TestDataHolder.addTestDataRecord("DOC_DOCUMENT_ID", String.valueOf(tdas_documents.getDOC_DOCUMENT_ID()), true, true);
            break;
        }
        sqlSession.clearCache();
        sqlSession.close();
        return list.isEmpty();
    }

    public static void setTSAS_APPLICATIONSTYPE_ByClosingDateAndAppCodeForFiveMinutes(){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        HashMap<String, String> params = new HashMap<>();
        params.put("APPT_APPLICATION_CLOSING_DATE", addFiveMinToTimeStamp());
        params.put("APPT_APPLICATION_CODE", "100001");
        sqlSession.update("ie.gov.agriculture.agschemes.dao.TSAS_APPLICATIONS_TYPEMapper.updateByClosingDate", params);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void setTSAS_APPLICATIONSTYPE_ByClosingDateAndAppCodeNow(){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        HashMap<String, String> params = new HashMap<>();
        params.put("APPT_APPLICATION_CLOSING_DATE", nowTimeStamp());
        params.put("APPT_APPLICATION_CODE", "100001");
        sqlSession.update("ie.gov.agriculture.agschemes.dao.TSAS_APPLICATIONS_TYPEMapper.updateByClosingDate", params);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void deleteFromTDAS_DOCUMENTSByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        sqlSession.delete("ie.gov.agriculture.agschemes.dao.TDAS_DOCUMENTSMapper.delete_by_application_id", appId);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void deleteFromTDAS_APPLICATIONSUNDERQUERYByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        sqlSession.delete("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONS_UNDER_QUERYMapper.delete_by_application_id", appId);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();

    }

    public static void deleteFromTDASAPPLICATIONSTRACKINGByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        sqlSession.delete("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONS_TRACKINGMapper.delete_by_application_id", appId);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void deleteFromTDASAPPLICATIONSNITRATESByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        sqlSession.delete("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONS_NITRATESMapper.delete_by_application_id", appId);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();
    }

    public static void deleteFromTDASAPPLICATIONSByAppId(String appId){
        SqlSessionFactory sqlSessionFactory = new DatabaseUtils(TestDataHolder.getTestDataRecord(TestDataHolder.ENVIRONMENT)).getSessionFactory();
        SqlSession sqlSession = sqlSessionFactory.openSession(true);
        sqlSession.clearCache();
        sqlSession.delete("ie.gov.agriculture.agschemes.dao.TDAS_APPLICATIONSMapper.delete_by_application_id", appId);
        sqlSession.commit();
        sqlSession.clearCache();
        sqlSession.close();
    }

}