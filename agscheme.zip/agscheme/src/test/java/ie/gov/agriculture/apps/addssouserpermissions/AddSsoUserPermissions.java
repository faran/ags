package ie.gov.agriculture.apps.addssouserpermissions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddSsoUserPermissions extends TestBase {

    public static void main(String args[]) throws InterruptedException, IOException {

        String environment = TestConfig.getEnvironment();

        System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")
            + "\\resources\\webdriver\\chrome\\chromedriver.exe");
        driver = new ChromeDriver();

        String ssoUrl;

        String driverExecutablePath = "C:\\Users\\conor.casey\\chromedriver v76\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", driverExecutablePath);

        ssoUrl = TestConfig.setSsoUrl("staff");

        // driver.manage().window().maximize();

        // Enter user credentials as below to create new users.
        // The first parameter is the user Id
        // second paramater (array) is GCPS permissions.
        // third paramater (array) is Rdfs User Permissions
        // fourth paramater (array) is Bps User Permissions
        // fifth paramater (array) is WorkArea.
        // 6th paramater (array) is ag schemes.

        // If the user does not need BPS credentials, just pass an empty array {} as the parameter.

        // System.gc();

        // create user0 -BEAM staff
        // User user0 = new User("agr1116", new String[] { "Exceptional Aid Recorder (Other)" }, new String[] {},
        // new String[] {}, new String[] { "[AES] BALLINA AES" }, new String[] {});
        // user0.speak();

        // create User1 - OFS Recorder -Conor
        // User user1 = new User("AGR5007", new String[] { "OFS Recorder (Other)" },
        // new String[] { "OFS Recorder (Other)" }, new String[] {},
        // new String[] { "[AES] DUNDALK/MONAGHAN AES", "[AES] ENNIS A AES" }, new String[] {});
        // user1.speak();

        // create User2 - OFS Approver - Conor
        // User user2 = new User("AGR2782", new String[] { "OFS Approver (Financial)" },
        // new String[] { "OFS Approver (Financial)" },
        // new String[] { "BPS Comm Evidence User", "BPS Processing 3 User" },
        // new String[] { "[AES] DUNDALK/MONAGHAN AES", "[AES] ENNIS A AES" }, new String[] {});

        // create User3 - OFS Recorder Bandita
        // User user3 = new User("agr5007", new String[] { "OFS Recorder (Other)" },
        // new String[] { "OFS Recorder (Other)" }, new String[] {},
        // new String[] { "[AES] DUNDALK/MONAGHAN AES", "[AES] ENNIS A AES" }, new String[] {});

        // create User4 - OFS Approver - Bandita
        // User user4 = new User("agr0012", new String[] { "OFS Approver (Financial)" },
        // new String[] { "OFS Approver (Financial)" }, new String[] {},
        // new String[] { "[AES] DUNDALK/MONAGHAN AES", "[AES] ENNIS A AES" }, new String[] {});

        // create User5 - KT - Conor
        // User user5 = new User("AGR2321",
        // new String[] { "KT Beef Scheme Approver (Financial)", "KT Dairy Scheme Approver (Financial)",
        // "KT Equine Scheme Approver (Financial)", "KT Poultry Scheme Approver (Financial)",
        // "KT Tillage Scheme Approver (Financial)", "KT Sheep Scheme Approver (Financial)" },
        // new String[] {}, new String[] {}, new String[] { "[AES] DUNDALK/MONAGHAN AES", "[AES] ENNIS A AES" },
        // new String[] {});

        // create User6 - KT - Haider
        User user6 = new User("agr8010", new String[] {}, new String[] {}, new String[] {}, new String[] {},
            new String[] { "NRATEDER HEO" });
        // User user6 = new User("agr8010", new String[] {}, new String[] {}, new String[] {}, new String[] {},
        // new String[] { "NRATEDER DS" });

        // A list of created Users
        User[] userList = { user6 };
        // User[] userList = { user0, user1, user2, user3, user4, user5, user6 };

        System.out.println("Number of users = " + User.count() + "\n");
        System.out.println("List of user Ids: " + User.getUserIdList() + "\n");
        System.out.println("List of user Indexes: " + User.getUserIndexList() + "\n");

        List<String> userIdList = User.getUserIdList();
        ArrayList<Integer> userIndexList = User.getUserIndexList();

        // Declaring PageFactory information
        StaffSsoLogin staffSsoLogin = PageFactory.initElements(driver, StaffSsoLogin.class);
        TestConfig testConfig = PageFactory.initElements(driver, TestConfig.class);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver, 15);

        // ********************************************* SSO
        // *************************************************************************************************************************
        String ssoPassword = TestConfig.setEnvPassWord();

        StaffSsoLoginDevc staffSsoLoginDevc = PageFactory.initElements(driver, StaffSsoLoginDevc.class);
        staffSsoLoginDevc.loginToSsoDevc("AGR0043", TestConfig.setEnvPassWord());
        staffSsoLoginDevc.clickLinkWithText("SSO Administration");

        System.out.println("Staff login is successful");

        // Loop to repeat for all users
        for (int currentUser = 0; currentUser < User.count(); currentUser++) {

            String currentUserId = userIdList.get(currentUser);

            System.out.print("\n \n current user Id: " + currentUserId);

            staffSsoLogin.setAdminUsername(currentUserId);

            staffSsoLogin.clickSearchUser();
            staffSsoLogin.clickSelectUserRadio();
            staffSsoLogin.clickEditUser();

            staffSsoLogin.clickAuthorisations();

            // Select GCPS
            staffSsoLogin.SelectApplication("[GCPS] Generic Claims Processing Systems");

            // remove existing workareas
            staffSsoLogin.clickRemoveAllWorkAreas();

            // if there are no workareas, close the popup box
            try {
                driver.switchTo().alert();
                driver.switchTo().alert().accept();
            } // try
            catch (NoAlertPresentException Ex) {
            } // catch

            // select work areas
            String[] currentUserWorkArea = userList[currentUser].getWorkAreas();

            for (String element : currentUserWorkArea) {
                staffSsoLogin.SelectWorkArea(element);

            }

            // remove existing permissions
            staffSsoLogin.clickRemoveAllPermissions();
            try {
                driver.switchTo().alert();
                driver.switchTo().alert().accept();
            } // try
            catch (NoAlertPresentException Ex) {
            } // catch

            String[] currentUserGcpsPermissions = userList[currentUser].getGcpsPermissions();

            for (String currentUserGcpsPermission : currentUserGcpsPermissions) {
                staffSsoLogin.selectPermission(currentUserGcpsPermission);

            }

            staffSsoLogin.clicksaveAuthorisations();

            /************************************************** REPEAT for BPS **************************/

            String[] currentUserBpsPermissions = userList[currentUser].getBpsPermissions();

            if (currentUserBpsPermissions.length > 0) {
                // Select BPS
                staffSsoLogin.SelectApplication("[BPS] Direct Payments (BPS/Greening/SPS)");

                // remove existing workareas
                staffSsoLogin.clickRemoveAllWorkAreas();

                // if there are no workareas, close the popup box
                try {
                    driver.switchTo().alert();
                    driver.switchTo().alert().accept();
                } // try
                catch (NoAlertPresentException Ex) {
                } // catch

                // select work areas

                for (String element : currentUserWorkArea) {
                    staffSsoLogin.SelectWorkArea(element);
                }

                // remove existing permissions
                staffSsoLogin.clickRemoveAllPermissions();
                try {
                    driver.switchTo().alert();
                    driver.switchTo().alert().accept();
                } // try
                catch (NoAlertPresentException Ex) {
                } // catch

                for (String currentUserBpsPermission : currentUserBpsPermissions) {
                    staffSsoLogin.selectPermission(currentUserBpsPermission);

                }

                staffSsoLogin.clicksaveAuthorisations();
            }

            /************************************************** REPEAT for RDFS **************************/

            String[] currentUserRdfsPermissions = userList[currentUser].getRdfsPermissions();
            if (currentUserRdfsPermissions.length > 0) {
                // Select RDFS

                staffSsoLogin.SelectApplication("[RDFS] Organic Farming System");

                // remove existing workareas
                staffSsoLogin.clickRemoveAllWorkAreas();

                // if there are no workareas, close the popup box
                try {
                    driver.switchTo().alert();
                    driver.switchTo().alert().accept();
                } // try
                catch (NoAlertPresentException Ex) {
                } // catch

                // select work areas

                for (String element : currentUserWorkArea) {
                    staffSsoLogin.SelectWorkArea(element);
                }

                // remove existing permissions
                staffSsoLogin.clickRemoveAllPermissions();
                try {
                    driver.switchTo().alert();
                    driver.switchTo().alert().accept();
                } // try
                catch (NoAlertPresentException Ex) {
                } // catch

                for (String currentUserRdfsPermission : currentUserRdfsPermissions) {
                    staffSsoLogin.selectPermission(currentUserRdfsPermission);
                }
            }

            staffSsoLogin.clicksaveAuthorisations();

            /************************************************** REPEAT for agschemes **************************/

            String[] currentUserAgschemesPermissions = userList[currentUser].getAgschemesPermissions();
            if (currentUserAgschemesPermissions.length > 0) {
                // Select agschemes
                staffSsoLogin.SelectApplication("[AGSCH] Agriculture Schemes - Nitrates");
                // old option
                // staffSsoLogin.SelectApplication("[AGSCH] Agriculture Schemes");
                // staffSsoLogin.SelectApplication("[AGSCH] Agriculture Schemes - Nitrates");
                // staffSsoLogin.SelectApplication("[RDFS] Organic Farming System");
                // [AGSCH] Agriculture Schemes - Nitrates
                // remove existing workareas
                staffSsoLogin.clickRemoveAllWorkAreas();

                // if there are no workareas, close the popup box
                try {
                    driver.switchTo().alert();
                    driver.switchTo().alert().accept();
                } // try
                catch (NoAlertPresentException Ex) {
                } // catch

                // select work areas

                for (String element : currentUserWorkArea) {
                    staffSsoLogin.SelectWorkArea(element);
                }

                // remove existing permissions
                staffSsoLogin.clickRemoveAllPermissions();
                try {
                    driver.switchTo().alert();
                    driver.switchTo().alert().accept();
                } // try
                catch (NoAlertPresentException Ex) {
                } // catch

                for (String currentUserAgschemesPermission : currentUserAgschemesPermissions) {
                    staffSsoLogin.selectPermission(currentUserAgschemesPermission);
                }
            }

            staffSsoLogin.clicksaveAuthorisations();
            Thread.sleep(10000);
            staffSsoLogin.clickSearchLink();

        }

        driver.close();
    }

}
