package ie.gov.agriculture.apps.addssouserpermissions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class User {

    public static List<String> userIdList = new ArrayList<>();
    public static ArrayList<Integer> userIndexList = new ArrayList<>();
    public static int noOfObjects = 0;

    private String userUid = "";
    private String[] userGcpsUserPermissions = {};
    private String[] userRdfsUserPermissions = {};
    private String[] userBpsUserPermissions = {};
    private String[] userWorkArea = {};
    private String[] agSchemes1 = {};

    // constructor
    public User(String userId, String[] gcpsPermissions, String[] rdfsPermissions, String[] bpsPermissions,
        String[] workArea, String[] agSchemes) {
        System.out.println("Constructor running!");

        userUid = userId;
        userGcpsUserPermissions = gcpsPermissions.clone();
        userRdfsUserPermissions = rdfsPermissions.clone();
        userBpsUserPermissions = bpsPermissions.clone();
        userWorkArea = workArea.clone();
        agSchemes1 = agSchemes.clone();

        noOfObjects = noOfObjects + 1;
        userIdList.add(userId);

    }

    public static int count() {
        return noOfObjects;

    }

    public static List<String> getUserIdList() {
        return userIdList;
    }

    public static ArrayList<Integer> getUserIndexList() {
        return userIndexList;
    }

    public void speak() {

        System.out.println("UserId: " + userUid + "\n");
        System.out.println("Work Area: " + Arrays.toString(userWorkArea) + ", length = " + userWorkArea.length + "\n");

        for (String userGcpsUserPermission : userGcpsUserPermissions) {
            System.out.println("user Gcps Permissions: " + userGcpsUserPermission + "\n");
        }

        for (String userRdfsUserPermission : userRdfsUserPermissions) {
            System.out.println("user Rdfs Permissions: " + userRdfsUserPermission + "\n");
        }

        for (String userBpsUserPermission : userBpsUserPermissions) {
            System.out.println("user Bps Permissions: " + userBpsUserPermission + "\n");
        }

        for (String element : agSchemes1) {
            System.out.println("user agschemes Permissions: " + element + "\n");
        }

        System.out.println("\n" + "\n");
    }

    public String getUserId() {
        return userUid;
    }

    public String[] getWorkAreas() {
        return userWorkArea;
    }

    public String[] getGcpsPermissions() {
        return userGcpsUserPermissions;
    }

    public String[] getRdfsPermissions() {
        return userRdfsUserPermissions;
    }

    public String[] getBpsPermissions() {
        return userBpsUserPermissions;
    }

    public String[] getAgschemesPermissions() {
        return agSchemes1;
    }

}
