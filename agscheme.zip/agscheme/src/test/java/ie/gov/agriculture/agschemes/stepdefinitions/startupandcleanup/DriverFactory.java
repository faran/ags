package ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.paulhammant.ngwebdriver.NgWebDriver;

import ie.gov.agriculture.agschemes.browserpages.nitrates.INitratesApplicationFormPage;
import ie.gov.agriculture.agschemes.browserpages.nitrates.INitratesNAndPDetatailsPage;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesApplicationFormPageAgent;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesApplicationFormPageStaff;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesDocumentManagerPage;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesLandingPage;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesLandingPageAgent;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesLandingPageStaff;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesNAndPDetatailsPageAgent;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesNAndPDetatailsPageStaff;
import ie.gov.agriculture.agschemes.browserpages.nitrates.NitratesQueryApplication;
import ie.gov.agriculture.agschemes.browserpages.ofs.OfsLandingPage;
import ie.gov.agriculture.agschemes.browserpages.ofs.OfsReportsLandingPage;
import ie.gov.agriculture.agschemes.browserpages.sso.SsoAgentPinCodePage;
import ie.gov.agriculture.agschemes.browserpages.sso.SsoLandingPage;
import ie.gov.agriculture.agschemes.browserpages.sso.SsoLoginPage;
import ie.gov.agriculture.agschemes.commons.AllowedRoles;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.databasequeries.NitratesDatabaseQueries;
import ie.gov.agriculture.agschemes.databasequeries.StartupDatabaseQueries;

//@RequiredArgsConstructor
@SuppressWarnings("deprecation")
public class DriverFactory {
    public WebDriver driver;
    public NgWebDriver ngwebDriver;
    public JavascriptExecutor js;
    public SsoLoginPage loginPage;
    public SsoLandingPage ssoLandingPage;
    public NitratesLandingPage nitratesLandingPage;
    public INitratesApplicationFormPage nitratesApplicationFormPage;
    public NitratesDatabaseQueries nitratesApplicationFormDatabaseQueries;
    public NitratesDocumentManagerPage nitratesDocumentManagerPage;
    public StartupDatabaseQueries startupDatabaseQueries;
    public INitratesNAndPDetatailsPage nitratesNAndPDetatailsPage;
    public SsoAgentPinCodePage ssoAgentPinCodePageObject;
    public SharedBrowserSteps sharedBrowsersSteps;
    public NitratesQueryApplication nitratesQueryApplication;
    public OfsLandingPage ofsLandingPage;
    public OfsReportsLandingPage ofsReportsLandingPage;

    public DriverFactory(SharedBrowserSteps sharedBrowsersSteps) {
        this.sharedBrowsersSteps = sharedBrowsersSteps;
        driver = returnWebDriver();
        ngwebDriver = returnNgWebDriver();

        loginPage = PageFactory.initElements(driver, SsoLoginPage.class);
        ssoLandingPage = PageFactory.initElements(driver, SsoLandingPage.class);
        ofsLandingPage = PageFactory.initElements(driver, OfsLandingPage.class);
        ofsReportsLandingPage = PageFactory.initElements(driver, OfsReportsLandingPage.class);

        ssoAgentPinCodePageObject = PageFactory.initElements(driver, SsoAgentPinCodePage.class);
        startupDatabaseQueries = PageFactory.initElements(driver, StartupDatabaseQueries.class);
        nitratesApplicationFormDatabaseQueries = PageFactory.initElements(driver,
            NitratesDatabaseQueries.class);
        nitratesDocumentManagerPage = PageFactory.initElements(driver,
            NitratesDocumentManagerPage.class);
        nitratesQueryApplication = PageFactory.initElements(driver,
            NitratesQueryApplication.class);
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesLandingPage = PageFactory.initElements(driver, NitratesLandingPageStaff.class);
            nitratesApplicationFormPage = PageFactory.initElements(driver, NitratesApplicationFormPageStaff.class);
            nitratesNAndPDetatailsPage = PageFactory.initElements(driver, NitratesNAndPDetatailsPageStaff.class);
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            nitratesLandingPage = PageFactory.initElements(driver, NitratesLandingPageAgent.class);
            nitratesApplicationFormPage = PageFactory.initElements(driver, NitratesApplicationFormPageAgent.class);
            nitratesNAndPDetatailsPage = PageFactory.initElements(driver, NitratesNAndPDetatailsPageAgent.class);
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }

    }

    public WebDriver returnWebDriver() {
        driver = sharedBrowsersSteps.getWebDriver();
        return driver;
    }

    public NgWebDriver returnNgWebDriver() {
        ngwebDriver = sharedBrowsersSteps.getNgwebDriver();
        return ngwebDriver;

    }

}
