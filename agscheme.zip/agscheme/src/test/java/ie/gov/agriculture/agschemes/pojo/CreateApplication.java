package ie.gov.agriculture.agschemes.pojo;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@NoArgsConstructor
public class CreateApplication {

    @Getter @Setter private String dataB;
    @Getter @Setter private Integer bpsManualRecordingInd;
    @Getter @Setter private boolean ahcsManualRecordingInd;
    @Getter @Setter private String dataA;
    @Getter @Setter private List<LiveStockDetails> liveStockDetails;
    @Getter @Setter private EligibleArea eligibleArea;
    @Getter @Setter private String storagePeriod;
    @Getter @Setter private String organicManure;
    @Getter @Setter private boolean bdMeasureWbThornTrLftId;
    @Getter @Setter private boolean bdMeasureMaintainHrowId;
    @Getter @Setter private boolean bdMeasureCutHedgrowId;
    @Getter @Setter private String environmentalTraining;
    @Getter @Setter private String grasslandTraining;
    @Getter @Setter private boolean termsConditionsInd;
    @Getter @Setter private String schemeYear;

    public static class LiveStockDetails {
        @Getter @Setter @JsonProperty("ANIMAL_TYPE") private String ANIMAL_TYPE;
        @Getter @Setter @JsonProperty("COUNT") private Integer COUNT;
        @Getter @Setter @JsonProperty("ANIMAL_DESCRIPTION") private String ANIMAL_DESCRIPTION;
    }

    public static class EligibleArea {
        @Getter @Setter private double eligibleGrasslandArea;
        @Getter @Setter private double eligibleHoldingArea;
        @Getter @Setter private Integer grasslandPercent;
        @Getter @Setter private String bpsFlag;
    }

}
