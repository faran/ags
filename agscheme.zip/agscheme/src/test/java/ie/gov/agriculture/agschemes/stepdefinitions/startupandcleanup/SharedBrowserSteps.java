package ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup;

import java.time.Duration;

import io.cucumber.java.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import org.apache.commons.lang.NotImplementedException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Sleeper;

import com.paulhammant.ngwebdriver.NgWebDriver;

import ie.gov.agriculture.agschemes.commons.AllowedEnvironments;
import ie.gov.agriculture.agschemes.commons.AllowedRoles;
import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.utils.SeleniumDriverProvider;
import lombok.Getter;
import lombok.NonNull;
import lombok.extern.log4j.Log4j2;

/**
 * General steps for browser based tests.
 */
@Log4j2
public class SharedBrowserSteps {

    @Getter
    private WebDriver webDriver;

    @Getter
    private NgWebDriver ngwebDriver;

    /**
     * Tagging the scenario with @ui-firefox will cause the firefox browser to start before the scenario starts. Same,
     * If the step 'using browser firefox' is in the scenario firefox will start.
     */
    @BeforeStep("@ui-firefox")
    @Given("^using browser firefox$")
    public void startBrowserFf() throws Exception {
        log.debug("starting browser firefox");
        webDriver = new SeleniumDriverProvider().getWebDriver("firefox", ConstantsProvider.isSELENIUM_GRID_ON(),
            false);
    }

    /**
     * Tagging the scenario with @ui-ie will cause the IE browser to start before the scenario starts. Same, If the step
     * 'using browser IE' is in the scenario IE will start.
     */
    @Before("@ui-ie")
    @Given("^using browser IE$")
    public void startBrowserIe() throws Exception {
        log.debug("starting browser IE");
        webDriver = new SeleniumDriverProvider().getWebDriver("ie", ConstantsProvider.isSELENIUM_GRID_ON(), false);
    }

    /**
     * Tagging the scenario with @ui-chrome will cause the chrome browser to start before the scenario starts. Same, If
     * the step 'using browser chrome' is in the scenario chrome will start.
     */
    @Before("@ui-chrome")
    @Given("^using browser chrome$")
    public void startBrowserChrome() throws Exception {
        log.debug("starting browser chrome");
        webDriver = new SeleniumDriverProvider().getWebDriver("chrome", ConstantsProvider.isSELENIUM_GRID_ON(),
            false);
    }

    /**
     * starts default browser as from constants.properties
     */

    @Before("@ui")
    public void startBrowser() throws Exception {

        log.warn("Got the System.getenv('BROWSER') Value: " + System.getenv("BROWSER"));

        if (System.getenv("BROWSER") == null) {

            // checks for NULL on Junit runs due to ENV variables not being set
            log.warn("Got the config.prperties Browser Value: " + ConstantsProvider.getSELENIUM_WEB_BROWSER_NAME());
            log.warn("starting browser with constants.properties");
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            log.warn("START THE TESTS ON BROWSER LOCALLY  WITH BROWER NAME "
                + ConstantsProvider.getSELENIUM_WEB_BROWSER_NAME());
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            webDriver = new SeleniumDriverProvider().getWebDriver(ConstantsProvider.getSELENIUM_WEB_BROWSER_NAME(),
                ConstantsProvider.isSELENIUM_GRID_ON(), false);
            log.warn("isSELENIUM_GRID_ON() value " + ConstantsProvider.isSELENIUM_GRID_ON());

        } else {
            // Uses the POM - maven surefire plugin EnvironmentVariable
            log.warn("got the POM SystemPropertyVariables BROWSER value:" + System.getenv("BROWSER"));
            log.warn("starting browser with the POM - maven surefire plugin EnvironmentVariable");
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            log.warn("START THE TESTS ON BROWSER REMOTELY ON GRID WITH BROWER NAME " + System.getenv("BROWSER"));
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            log.warn("==================================================================================");
            webDriver = new SeleniumDriverProvider().getWebDriver(System.getenv("BROWSER"),
                System.getenv("GRIDONBAMBOO"), false);
            log.warn("System.getenv('GRIDONBAMBOO') value " + System.getenv("GRIDONBAMBOO"));
        }
    }

    /**
     * starts the default browser with Logs enabled for logs inspection
     */
    @Before("@ui-with-logs")
    public void startBrowserWithLogs() throws Exception {
        log.debug("starting browser with logs");
        webDriver = new SeleniumDriverProvider().getWebDriver("chrome", ConstantsProvider.isSELENIUM_GRID_ON(),
            true);
    }

    /**
     * Takes screenshot after scenario ends regardless of status
     */
    @After(order = 5)
    public void takeScreenshotAfterTest(Scenario scenario) {
        try {
            log.debug("take screenshot after scenario: " + scenario.getName());
            if (null != webDriver) {
                final byte[] screenshot = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.BYTES);
                log.debug("embedding the screenshot");
                scenario.attach(screenshot, "image/jpeg", scenario.getName());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * Quitting the browser after the test
     */
    @After(order = 4)
    public void quitBrowser() {
        log.debug("quit browser if found");
        if (webDriver != null) {
            webDriver.quit();
        }
    }

    @And("^browser page is reloaded$")
    public void reloadPage() throws InterruptedException {
        log.debug("wait 15 seconds before refresh the page");
        Sleeper.SYSTEM_SLEEPER.sleep(Duration.ofSeconds(15));
        log.debug("reload page..");
        webDriver.navigate().refresh();
        log.debug("reload page done!");
        log.debug("wait 10 seconds after refresh the page");
        Sleeper.SYSTEM_SLEEPER.sleep(Duration.ofSeconds(10));
        log.debug("Ready to continue with test!");
    }

    @Then("^Incomplete Test Exception$")
    public void incomplete_test_exception(){
        throw new PendingException("This test script has not been completed");
    }

    void startHeadlessChromeForCookiesRetriev() throws Exception {
        log.debug("starting chrome as headless");
        webDriver = new SeleniumDriverProvider().getWebDriver("chrome-headless",
            ConstantsProvider.isSELENIUM_GRID_ON(), false);
    }

    public static String getPasswordForUiTests(@NonNull String environment) {
        String pwd;
        switch (environment.toLowerCase()) {
        case AllowedEnvironments.ENVIRONMENT_DEV:
            pwd = ConstantsProvider.getSSO_LOGIN_PASSWORD_DEV();
            log.debug("got DEV password: " + pwd);
            break;
        case AllowedEnvironments.ENVIRONMENT_UAT:
            pwd = ConstantsProvider.getSSO_LOGIN_PASSWORD_UAT();
            log.debug("got UAT password: " + pwd);
            break;
        case AllowedEnvironments.ENVIRONMENT_CENTEST:
            pwd = ConstantsProvider.getSSO_LOGIN_PASSWORD_CENTEST();
            log.debug("got CENTEST password: " + pwd);
            break;
        default:
            throw new IllegalArgumentException("Environment '" + environment + "' not found");
        }

        return pwd;
    }

    public static String getUrlForUiTests(@NonNull String environment, String userType) {
        String url;
        switch (environment.toLowerCase()) {
        case AllowedEnvironments.ENVIRONMENT_DEV:
            log.debug("RUNNING IN DEV ENVIRONMENT");

            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_STAFF)) {
                url = ConstantsProvider.getDEVSTAFFURL();
                log.debug("got STAFF DEV URL: " + url);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_AGENT)) {
                url = ConstantsProvider.getDEVAGENTURL();
                log.debug("got AGENT DEV URL: " + url);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_INDIVIDUAL)) {
                url = ConstantsProvider.getDEVINDIVIDUALURL();
                log.debug("got INDIVIDUAL DEV URL: " + url);
                break;
            }
        case AllowedEnvironments.ENVIRONMENT_UAT:
            log.debug("RUNNING IN UAT ENVIRONMENT");
            url = ConstantsProvider.getSSO_LOGIN_PASSWORD_UAT();
            break;
        case AllowedEnvironments.ENVIRONMENT_CENTEST:
            log.debug("RUNNING IN CENTEST ENVIRONMENT");
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_STAFF)) {
                url = ConstantsProvider.getCENTESTSTAFFURL();
                log.debug("got STAFF CENTTEST URL: " + url);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_AGENT)) {
                url = ConstantsProvider.getCENTESTAGENTURL();
                log.debug("got AGENT CENTTEST URL: " + url);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_INDIVIDUAL)) {
                url = ConstantsProvider.getCENTESTINDIVIDUALURL();
                log.debug("got INDIVIDUAL CENTEST URL: " + url);
                break;
            }
        default:
            throw new IllegalArgumentException("Environment '" + environment + "' not found");
        }

        return url;
    }

    public static String getLoginUserNameForUiTests(@NonNull String environment, String userType) {
        String loginusername;
        switch (environment.toLowerCase()) {
        case AllowedEnvironments.ENVIRONMENT_DEV:
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_STAFF)) {
                loginusername = ConstantsProvider.getSSOSTAFFLOGINUSERNAMEDEV();
                //USER_UNDER_TEST
                TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
                log.debug("LOGGING IN AS STAFF IN DEV...");
                log.debug("got STAFF DEV LOGIN USERNAME: " + loginusername);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_AGENT)) {
                loginusername = ConstantsProvider.getSSOAGENTLOGINUSERNAMEDEV();
                TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
                log.debug("LOGGING IN AS AGENT IN DEV...");
                log.debug("got AGENT DEV LOGIN USERNAME: " + loginusername);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_INDIVIDUAL)) {
                loginusername = ConstantsProvider.getSSOINDIVIDUALLOGINUSERNAMEDEV();
                TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
                log.debug("LOGGING IN AS INDIVIDUAL IN DEV...");
                log.debug("got INDIVIDUAL DEV LOGIN USERNAME: " + loginusername);
                break;
            }
        case AllowedEnvironments.ENVIRONMENT_UAT:
            loginusername = ConstantsProvider.getSSO_LOGIN_PASSWORD_UAT();
            TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
            break;
        case AllowedEnvironments.ENVIRONMENT_CENTEST:
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_STAFF)) {
                loginusername = ConstantsProvider.getSSOSTAFFLOGINUSERNAMECENTEST();
                TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
                log.debug("LOGGING IN AS STAFF IN CENTEST...");
                log.debug("got STAFF CENTTEST LOGIN USERNAME: " + loginusername);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_AGENT)) {
                loginusername = ConstantsProvider.getSSOAGENTLOGINUSERNAMECENTEST();
                TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
                log.debug("LOGGING IN AS AGENT IN CENTEST...");
                log.debug("got AGENT CENTTEST LOGIN USERNAME: " + loginusername);
                break;
            }
            if (userType.equalsIgnoreCase(AllowedRoles.ROLE_INDIVIDUAL)) {
                loginusername = ConstantsProvider.getSSOINDIVIDUALLOGINUSERNAMECENTEST();
                TestDataHolder.addRecord(TestDataHolder.USER_UNDER_TEST, loginusername);
                log.debug("LOGGING IN AS INDIVIDUAL IN CENTEST...");
                log.debug("got INDIVIDUAL CENTEST LOGIN USERNAME: " + loginusername);
                break;
            }
        default:
            throw new IllegalArgumentException("Environment '" + environment + "' not found");
        }

        return loginusername;
    }

    @And("^user of type (agent|staff|individual)$")
    public void initialiseTestDataParameters(String userType){

        userType = userType.toLowerCase().trim();
        TestDataHolder.addRecord(TestDataHolder.USERTYPE_UNDER_TEST, userType);
        log.warn("USERTYPE_UNDER_TEST " + TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST));

        switch (userType.toLowerCase().trim()) {
        case AllowedRoles.ROLE_STAFF:
            TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERDNO1STAFF());
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERDNO1AGENT());
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @And("^user with no data of type (agent|staff|individual)$")
    public void initialiseTestDataParametersForUserWithNoData(String userType){

        userType = userType.toLowerCase().trim();
        TestDataHolder.addRecord(TestDataHolder.USERTYPE_UNDER_TEST, userType);
        log.warn("USERTYPE_UNDER_TEST " + TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST));

        switch (userType.toLowerCase().trim()) {
        case AllowedRoles.ROLE_STAFF:
            TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERD_NO_DATA_STAFF());
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERD_NO_DATA_AGENT());
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @And("^user with some data of type (agent|staff|individual)$")
    public void initialiseTestDataParametersForUserWithData(String userType){

        userType = userType.toLowerCase().trim();
        TestDataHolder.addRecord(TestDataHolder.USERTYPE_UNDER_TEST, userType);
        log.warn("USERTYPE_UNDER_TEST " + TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST));

        switch (userType.toLowerCase().trim()) {
        case AllowedRoles.ROLE_STAFF:
            TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERD_WITH_SOME_DATA_STAFF());
            break;
        case AllowedRoles.ROLE_AGENT:
            TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERDNO1AGENT());
            break;
        case AllowedRoles.ROLE_INDIVIDUAL:
            throw new NotImplementedException("userType '" + userType + "' with some data not found");
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @And("^user of type (agent|staff|individual) and herd (.*)$")
    public void initialiseTestDataParameters(String userType, String herd){

        userType = userType.toLowerCase().trim();
        TestDataHolder.addRecord(TestDataHolder.USERTYPE_UNDER_TEST, userType);
        log.info("USERTYPE_UNDER_TEST " + TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST));
        log.info("herd = " + herd);

        switch (userType.toLowerCase().trim()) {
        case AllowedRoles.ROLE_STAFF:
            if (herd.equalsIgnoreCase(AllowedEnvironments.STAFF_HERD_NO_1)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERDNO1STAFF());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.STAFF_HERD_NO_2)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERD_NO_DATA_STAFF());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.STAFF_HERD_NO_3)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST,
                    ConstantsProvider.getHERD_WITH_SOME_DATA_STAFF());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.STAFF_HERD_NO_4)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST,
                    ConstantsProvider.getHERD_WITH_N_AND_P_DETAILS_STAFF());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.STAFF_HERD_NO_5)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST,
                        ConstantsProvider.getHERD_WITH_APPLICATION_APPROVED());
            }
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            if (herd.equalsIgnoreCase(AllowedEnvironments.AGENT_HERD_NO_1)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERDNO1AGENT());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.AGENT_HERD_NO_2)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERD_NO_DATA_AGENT());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.AGENT_HERD_NO_3)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getHERDNO3AGENT());
            }
            if (herd.equalsIgnoreCase(AllowedEnvironments.NON_CLIENT_1)) {
                TestDataHolder.addRecord(TestDataHolder.HERD_UNDER_TEST, ConstantsProvider.getNONCLIENT1());
            }
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

}
