package ie.gov.agriculture.agschemes.browserpages.sso;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;

@Log4j2
@RequiredArgsConstructor
public class SsoApplicationsListPage {

    private final WebDriver driver;

    @FindBy(partialLinkText = "LPIS Internet")
    WebElement agentLpisApplicationLink;

    @FindBy(partialLinkText = "SSO Administration")
    WebElement ssoAdministrationLink;

    @FindBy(linkText = "Direct Payments (BPS/Greening/SPS)")
    WebElement agentBpsApplicationLink;

    @FindBy(partialLinkText = "Land Parcel Information System")
    private WebElement lpisApplicationLink;

    @FindBy(linkText = "IFORIS Internet")
    private WebElement iforisApplicationAgentLink;

    @FindBy(linkText = "IFORIS Mapping System")
    private WebElement iforisApplicationInternalMapingLink;

    public void clickSSOAdministrationUrlAsAgent() {
        log.debug("clicking the SSO administration link as auth user..");
        ssoAdministrationLink.click();
    }

    public void clickBpsUrlAsAgent() {
        log.debug("clicking the BPS link on application list page as agent");
        agentBpsApplicationLink.click();
    }

    public void clickIforisUrlAsAgent() {
        log.debug("clicking the IFORIS Internet application link on the application list page");
        iforisApplicationAgentLink.click();
    }

    public void clickIforisUrlAsInternalUser() {
        log.debug("clicking the IFORIS Mapping System link");
        iforisApplicationInternalMapingLink.click();
    }
}
