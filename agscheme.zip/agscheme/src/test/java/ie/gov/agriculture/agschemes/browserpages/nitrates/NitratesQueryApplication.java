package ie.gov.agriculture.agschemes.browserpages.nitrates;

import ie.gov.agriculture.agschemes.utils.BrowserUtils;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

@RequiredArgsConstructor
@Log4j2
public class NitratesQueryApplication {

    protected final WebDriver webDriver;

    @FindBy(id = "internal-login-query-application-button")
    protected WebElement queryApplication;

    @FindBy(xpath = "//mat-card-title[normalize-space(text()='Query Application')]")
    protected WebElement queryApplicationTitle;

    @FindBy(id = "query-application-query-reasons")
    protected WebElement queryReasonDropDown;

    @FindBy(id = "query-reason-option- -5")
    protected WebElement documentDeletionOption;

    @FindBy(id = "query-reason-option- -6")
    protected WebElement documentEditDelete;

    @FindBy(id = "query-reason-option- -0")
    protected WebElement fertilizerAccountOption;

    @FindBy(id = "query-reason-option- -2")
    protected WebElement soilSampleOption;

    @FindBy(id = "query-application-document-type")
    protected WebElement documentTypeDropDown;

    @FindBy(id = "doc-type-option- -0")
    protected WebElement documentTypeDropDownFA;

    @FindBy(id = "doc-type-option- -2")
    protected WebElement documentTypeDropDownED;

    @FindBy(id = "doc-type-option- -5")
    protected WebElement documentTypeDropDownOther;

    @FindBy(id = "query-application-scheme-year")
    protected WebElement schemeYearDropDown;

    @FindBy(id = "scheme-year-option- -4")
    protected WebElement schemeYearOption;

    @FindBy(id = "confimation-modal-confirm-button")
    protected WebElement confirmButton;

    @FindBy(id = "confimation-modal-success-close-button")
    protected WebElement appSavedSuccCloseButton;

    @FindBy(xpath = "//div[text()=' Application Query successful ']")
    protected WebElement appSavedSuccCloseTitle;


    public void clickQueryApplication() {
        BrowserUtils.waitAndClickElement(webDriver, queryApplication);
        BrowserUtils.waitVisibility(webDriver, queryApplicationTitle);
    }

    public void selectQueryReasonFertlizerAccount() {
        BrowserUtils.waitAndClickElement(webDriver, queryReasonDropDown);
        BrowserUtils.waitAndClickElement(webDriver, fertilizerAccountOption);
    }

    public void selectQueryReasonDocumentDelete() {
        BrowserUtils.waitAndClickElement(webDriver, queryReasonDropDown);
        BrowserUtils.waitAndClickElement(webDriver, documentDeletionOption);
    }

    public void selectQueryReasonEditDocument() {
        BrowserUtils.waitAndClickElement(webDriver, queryReasonDropDown);
        BrowserUtils.waitAndClickElement(webDriver, documentEditDelete);
    }

    public void selectQueryReasonSoilSample() {
        BrowserUtils.waitAndClickElement(webDriver, queryReasonDropDown);
        BrowserUtils.waitAndClickElement(webDriver, soilSampleOption);
    }

    public void selectDocumentType(String type) {
        BrowserUtils.waitAndClickElement(webDriver, documentTypeDropDown);
        if(type.equals("Fertiliser Accounts")) {
            BrowserUtils.waitAndClickElement(webDriver, documentTypeDropDownFA);
        }
        if(type.equals("Soil Sample")) {
            BrowserUtils.waitAndClickElement(webDriver, documentTypeDropDownED);
        }
        if(type.equals("Other")) {
            BrowserUtils.waitAndClickElement(webDriver, documentTypeDropDownOther);
        }
    }

    public void selectSchemeYear() {
        BrowserUtils.waitAndClickElement(webDriver, schemeYearDropDown);
        BrowserUtils.waitAndClickElement(webDriver, schemeYearOption);
    }

    public void clickConfirm(){
        BrowserUtils.waitAndClickElement(webDriver, confirmButton);
        BrowserUtils.waitVisibility(webDriver, appSavedSuccCloseTitle);
        BrowserUtils.waitAndClickElement(webDriver, appSavedSuccCloseButton);
    }
}
