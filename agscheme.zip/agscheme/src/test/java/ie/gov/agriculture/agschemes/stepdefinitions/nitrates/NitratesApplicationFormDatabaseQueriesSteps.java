package ie.gov.agriculture.agschemes.stepdefinitions.nitrates;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Assert;

import ie.gov.agriculture.agschemes.commons.AllowedRoles;
import ie.gov.agriculture.agschemes.commons.ConstantsProvider;
import ie.gov.agriculture.agschemes.commons.TestDataHolder;
import ie.gov.agriculture.agschemes.stepdefinitions.database.DataBaseSteps;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.Then;

import static ie.gov.agriculture.agschemes.stepdefinitions.database.DataBaseSteps.*;
import static org.junit.Assert.*;

public class NitratesApplicationFormDatabaseQueriesSteps extends DriverFactory {

    public NitratesApplicationFormDatabaseQueriesSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @Then("assert application is draft status in database")
    public void assertApplicationIsSavedAsDraftStatusInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForStaff(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Draft");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            // TODO:implement later
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForAgent(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Draft");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert application with some data is draft status in database")
    public void assertApplicationWtihSomeDataIsSavedAsDraftStatusInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForStaff(
                ConstantsProvider.getHERD_WITH_SOME_DATA_STAFF(), ConstantsProvider.getHERDYEAR(),
                "Application Draft");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            // TODO: IMPLEMENT LATER
            // nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForAgent(
            // ConstantsProvider.getHERDNO1AGENT(), ConstantsProvider.getHERDYEAR(),
            // "Application Draft");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert application is draft status in database with no data")
    public void applicationIsDraftStatusInDatabaseWithNodata() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusNoDataIsSavedInDatabaseStaff(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Draft");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusNoDataIsSavedInDatabaseAgent(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Draft");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert application status is not in the database")
    public void assertApplicationStatusIsNotInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationIsNotInDatabase(ConstantsProvider.getHERDNO1STAFF(),
                ConstantsProvider.getHERDYEAR());
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            nitratesApplicationFormDatabaseQueries.assertApplicationIsNotInDatabase(ConstantsProvider.getHERDNO1AGENT(),
                ConstantsProvider.getHERDYEAR());
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert application status is not in the database for newly created application")
    public void assertApplicationStatusIsNotInDatabaseForNewlyCreatedApplication() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationIsNotInDatabase(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR());
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            nitratesApplicationFormDatabaseQueries.assertApplicationIsNotInDatabase(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR());
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("^assert application is deleted status in database$")
    public void assertApplicationIsDeletedStatusInDatabase() throws Throwable {
        nitratesApplicationFormDatabaseQueries.assertApplicationIsDeletedStatus(ConstantsProvider.getHERDNO1AGENT());
    }

    @Then("assert application is in submitted status in database")
    public void assertApplicationIsSubmittedStatusInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForStaff(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Submitted");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForAgent(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Submitted");
            break;
        default:
            throw new IllegalArgumentException("userType not found");
        }
    }

    @Then("assert newly created application is submitted status in database")
    public void assertNewlyCreatedApplicationIsSubmittedStatusInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForStaff(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Submitted");

            // TODO: UNCOMMENT LATER DB UNSTABLE
            // nitratesApplicationFormPage.assertApplicationStatusIsSavedInDatabase(
            // TestDataHolder
            // .getTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result"),
            // ConstantsProvider.getHERDYEAR(), "Application Submitted");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            // Todo: implmement later
            // nitratesApplicationFormPage.assertApplicationStatusIsSavedInDatabase(ConstantsProvider.getHERDNO1AGENT(),
            // ConstantsProvider.getHERDYEAR(), "Application Submitted");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert application with some data is submitted status in database")
    public void assertApplicationWithSomeDataIsSubmittedStatusInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForStaff(
                ConstantsProvider.getHERD_WITH_SOME_DATA_STAFF(), ConstantsProvider.getHERDYEAR(),
                "Application Submitted");

            // TODO: UNCOMMENT LATER DB UNSTABLE
            // nitratesApplicationFormPage.assertApplicationStatusIsSavedInDatabase(
            // TestDataHolder
            // .getTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result"),
            // ConstantsProvider.getHERDYEAR(), "Application Submitted");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            // Todo: implmement later
            // nitratesApplicationFormPage.assertApplicationStatusIsSavedInDatabase(ConstantsProvider.getHERDNO1AGENT(),
            // ConstantsProvider.getHERDYEAR(), "Application Submitted");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert newly created application is draft status in database")
    public void assertNewlyCreatedApplicationIsDraftStatusInDatabase() throws Throwable {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertApplicationStatusIsSavedInDatabaseForStaff(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Draft");

            // TODO: UNCOMMENT LATER DB UNSTABLE
            // nitratesApplicationFormPage.assertApplicationStatusIsSavedInDatabase(
            // TestDataHolder
            // .getTestDataRecord("selectsApplicationWithNoAnimalAndGrasslandAndAreaOfHoldingData_result"),
            // ConstantsProvider.getHERDYEAR(), "Application Submitted");
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            // Todo: implmement later
            // nitratesApplicationFormPage.assertApplicationStatusIsSavedInDatabase(ConstantsProvider.getHERDNO1AGENT(),
            // ConstantsProvider.getHERDYEAR(), "Application Submitted");
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    @Then("assert n and p enquiry details in database is correct")
    public void assertNAndPEnquiryDetailsInDatabaseIsCorrect() throws Throwable {

        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        switch (userType.toLowerCase()) {
        case AllowedRoles.ROLE_STAFF:
            nitratesApplicationFormDatabaseQueries.assertNAndPDetailsForStaff(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getHERDYEAR(),
                "Application Draft", ConstantsProvider.getNTR_NITRATES_YEAR_STAFF());
            break;
        case AllowedRoles.ROLE_AGENT:
        case AllowedRoles.ROLE_INDIVIDUAL:
            // Todo: implmement later
            break;
        default:
            throw new IllegalArgumentException("userType '" + userType + "' not found");
        }
    }

    public static String convertStringDate(String date) {
        String formatRequired = null;
        try {
            SimpleDateFormat incomingDate = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy");
            SimpleDateFormat returnDate = new SimpleDateFormat("dd/MM/yyyy");
            Date date1 = incomingDate.parse(date);
            formatRequired = returnDate.format(date1);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return formatRequired;
    }

    /**Assertions for AGSCHAGL-88*/
    @Then("^assert document is not present in db$")
    public void assertDocumentNotPresent(){
        verifyDocId();
        assertTrue("Document is not deleted! : ", verifyDocId());
    }

    /**Assertions for AGSCHAGL-88*/
    @Then("^assert document is present in db$")
    public void assertDocumentPresent(){
        verifyDocId();
        assertFalse("Document is deleted! : ", verifyDocId());
    }

    /** Assertions for 651 */
    @Then("^assert staff query application$")
    public void assertStaffQueryApplication() {
        getAppApplicationIDStaff();
        getTDAS_APPLICATIONS_UNDER_QUERYByAppId();
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APD_DOCUMENT_TYPE), "Fertiliser Accounts");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APD_DOCUMENT_YEAR), "2020");
        assertNotNull(TestDataHolder.getRecord(TestDataHolder.APD_APPLICATION_TRACKING_ID));
        // TODO :compare with todays date
        // assertEquals(TestDataHolder.getRecord(TestDataHolder.APD_AUDIT_DATE), todays_data);
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100003");
    }

    /** Assertions for 738 */
    @Then("^assert customer frontend details match backend$")
    public void assertCustomerDetails() {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        getBusinessIdAndStartDate();
        if (AllowedRoles.ROLE_STAFF.contentEquals(userType)) {
            assertEquals(TestDataHolder.getRecord(TestDataHolder.CUSTOMER_BUSINESS_ID_STAFF_VALUE),
                    TestDataHolder.getRecord(TestDataHolder.BUSINESS_ID));
            assertEquals(TestDataHolder.getRecord(TestDataHolder.CUSTOMER_START_DATE_STAFF_VALUE),
                    convertStringDate(TestDataHolder.getRecord(TestDataHolder.START_DATE)));
        }
        if (AllowedRoles.ROLE_AGENT.contentEquals(userType)) {
            assertEquals(TestDataHolder.getRecord(TestDataHolder.CUSTOMER_BUSINESS_ID_AGENT_VALUE),
                    TestDataHolder.getRecord(TestDataHolder.BUSINESS_ID));
            assertEquals(TestDataHolder.getRecord(TestDataHolder.CUSTOMER_START_DATE_AGENT_VALUE),
                    convertStringDate(TestDataHolder.getRecord(TestDataHolder.START_DATE)));
        }
    }

    /** Assertions for 512 */
    @Then("^assert n and p enquiry entries are correct$")
    public void assertNandPEnquiryDetails() {
        List<String> listFromUI = new ArrayList<>();
        listFromUI.add(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_ONE_STAFF_VALUE));
        //Code commented as more values become available for year 2021 we can enable the below code accordingly.
//        listFromUI.add(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_TWO_STAFF_VALUE));
//        listFromUI.add(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_THREE_STAFF_VALUE));
//        listFromUI.add(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FOUR_STAFF_VALUE));
//        listFromUI.add(TestDataHolder.getRecord(TestDataHolder.PHOSPHORUS_ROW_FIVE_STAFF_VALUE));

        System.out.println("list from ui "+listFromUI);

        // Adding all items from db query to list
        List<Long> listFromDb = new ArrayList<>(
            DataBaseSteps.getTDAG_NITRATESByClientIdAndYear(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST)));

        // Converting long list items to string for later comparison
        List<String> dbListStr = new ArrayList<>(listFromDb.size());
        for (Long longlist : listFromDb) {
            dbListStr.add(String.valueOf(longlist));
        }
        // Removing all matching items from ui list and see if its empty after matching with
        // this way we dont need to care about sorting
        listFromUI.removeAll(dbListStr);
        System.out.println("list from db");
        System.out.println(listFromDb);
        System.out.println("list after removal");
        System.out.println(listFromUI);
        Assert.assertTrue("Some items from m ui doesnt match with items in db for n & p: ", listFromUI.isEmpty());
    }

    // TODO convert status code in to enums
    /** Assertions for 177 */
    @Then("^assert agent application is in draft status with data$")
    public void assertAgentApplicationInDraftStatusWithData() {
        getApnApplicationIDAgent();
        getAppApplicationIDAgent();

        assertCommonDataAgent();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100001");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "0");
    }

    /** Assertions for 147 */
    @Then("^assert staff application is in submitted status$")
    public void assertStaffApplicationInSubmittedStatus() {
        getApnApplicationIDStaff();
        getAppApplicationIDStaff();

        assertCommonDataStaff();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100002");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "0");
    }

    /** Assertions for 146 */
    @Then("^assert staff application is in draft status$")
    public void assertStaffApplicationInDraftStatus() {
        getApnApplicationIDStaff();
        getAppApplicationIDStaff();

        assertCommonDataStaff();

        assertEquals("APP_CURRENT_STATUS_CODE = '100001'?",
            TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100001");
        assertEquals("APN_BDMEASURE_CUT_HEDGROW_ID = '0'?",
            TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals("APN_BPS_MANUAL_RECORDING_IND = '1'?",
            TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "1");
        assertEquals("APN_AHCS_MANUAL_RECORDING_IND= '0'?",
            TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "0");
    }

    /** Assertions for 145 */
    @Then("^assert staff application should not be database$")
    public void assertStaffApplicationShouldNotBeInDatabase() {
        assertTrue("App is id present when it should not be: ", verifyAppIdIsEmpty());
    }

    /** Assertions for 340 */
    @Then("^assert agent application is in submitted status$")
    public void assertagentApplicationInSubmittedStatus() {
        getApnApplicationIDAgent();
        getAppApplicationIDAgent();

        assertCommonDataAgent();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100002");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "0");
    }

    /** Assertions for 172 176 */
    @Then("^assert agent application is in draft status no data$")
    public void assertAgentApplicationInDraftStatusNoData() {
        getAppApplicationIDAgent();
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100001");
    }

    /** Assertions for 171 */
    @Then("^assert agent application is in delete status$")
    public void assertAgentApplicationInDeleteStatus() {
        getAppApplicationIDAgent();
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100008");
    }

    /** Assertions for 501 */
    @Then("^assert staff save draft application with no AHCS and BPS data$")
    public void assertStaffSaveDraftApplicationWithNoAHCSandBPSData() {
        getApnApplicationIDStaff();
        getAppApplicationIDStaff();

        assertCommonDataStaff();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100001");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "1");
    }

    /** Assertions for 502 */
    @Then("^assert staff save draft application with AHCS and BPS data$")
    public void assertStaffSaveDraftApplicationWithAHCSandBPSData() {
        getApnApplicationIDStaff();
        getAppApplicationIDStaff();

        assertCommonDataStaff();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100001");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "0");
    }

    /** Assertions for 503 */
    @Then("^assert staff new application submitted status with no data$")
    public void assertStaffNewApplicationSubmittedStatusNoData() {
        getApnApplicationIDStaff();
        getAppApplicationIDStaff();

        assertCommonDataStaff();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100002");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "1");
    }

    /** Assertions for 504 */
    @Then("^assert staff new application submitted status with data$")
    public void assertStaffNewApplicationSubmittedStatusAllData() {
        getApnApplicationIDStaff();
        getAppApplicationIDStaff();

        assertCommonDataStaff();

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APP_CURRENT_STATUS_CODE), "100002");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_CUT_HEDGROW_ID), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BPS_MANUAL_RECORDING_IND), "0");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AHCS_MANUAL_RECORDING_IND), "0");

    }

    private void assertCommonDataStaff() {
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AUDIT_USER),
            TestDataHolder.getRecord(TestDataHolder.USER_UNDER_TEST));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_CATTLE),
            TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_VALUE));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_NET_AREA_OF_HOLDING),
            TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_VALUE));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_NET_GRASSLAND),
            TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_VALUE));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AMOUNT_SLURRY_SPREAD),
            TestDataHolder.getRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_GRASS_LAND_PERCENT),
            TestDataHolder.getRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_STORAGE_PERIOD), "16");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_TERMS_CONDITIONS_IND), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_WBTHORN_TRLFT_ID), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_TRAINING_ENVIRONMENTAL_IND), "0");
    }

    private void assertCommonDataAgent() {
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AUDIT_USER),
            TestDataHolder.getRecord(TestDataHolder.USER_UNDER_TEST));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_CATTLE),
            TestDataHolder.getTestDataRecord(TestDataHolder.ANIMALS_ON_HOLDING_CHECK_AGENT_VALUE));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_NET_AREA_OF_HOLDING),
            TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_HOLDING_CHECK_AGENT_VALUE));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_NET_GRASSLAND),
            TestDataHolder.getTestDataRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_CHECK_AGENT_VALUE));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_AMOUNT_SLURRY_SPREAD),
            TestDataHolder.getRecord(TestDataHolder.ESTIMATED_NITROGEN_SPREAD_AGENT));
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_GRASS_LAND_PERCENT),
            TestDataHolder.getRecord(TestDataHolder.ELIGIBLE_AREA_OF_GRASSLAND_PERCENTAGE));

        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_STORAGE_PERIOD), "16");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_TERMS_CONDITIONS_IND), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_BDMEASURE_WBTHORN_TRLFT_ID), "1");
        assertEquals(TestDataHolder.getRecord(TestDataHolder.APN_TRAINING_ENVIRONMENTAL_IND), "0");
    }

    private boolean verifyAppIdIsEmpty() {
        return DataBaseSteps
            .getTDAS_APPLICATIONSByBusinessIdAndSchemeYear(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
    }

    private void getApnApplicationIDStaff() {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        DataBaseSteps.getTDAS_APPLICATIONS_NITRATESByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    private void getAppApplicationIDStaff() {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        DataBaseSteps.getTDAS_APPLICATIONSByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    private void getApnApplicationIDAgent() {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        DataBaseSteps.getTDAS_APPLICATIONS_NITRATESByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    private void getAppApplicationIDAgent() {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        DataBaseSteps.getTDAS_APPLICATIONSByAppId(TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    private void getBusinessIdAndStartDate() {
        String userType = TestDataHolder.getRecord(TestDataHolder.USERTYPE_UNDER_TEST);
        if (AllowedRoles.ROLE_STAFF.contentEquals(userType)) {
            DataBaseSteps.getVWCO_AGSCH_BUSINESS_CUSTOMERSByBusinessIdAndCustomerId(
                    TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getCUSTOMER_ID());
        }
        if (AllowedRoles.ROLE_AGENT.contentEquals(userType)) {
            DataBaseSteps.getVWCO_AGSCH_BUSINESS_CUSTOMERSByBusinessIdAndCustomerId(
                    TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST), ConstantsProvider.getCUSTOMER_ID_AGENT());
        }
    }

    private void getTDAS_APPLICATIONS_UNDER_QUERYByAppId() {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(
            TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        DataBaseSteps.getTDAS_APPLICATIONS_UNDER_QUERYByAppId(
            TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    private boolean verifyDocId() {
        DataBaseSteps.getTDAS_APPLICATIONSByBusinessId(
                TestDataHolder.getRecord(TestDataHolder.HERD_UNDER_TEST));
        return DataBaseSteps.verifyDocId(
                TestDataHolder.getRecord(TestDataHolder.APP_APPLICATION_ID));
    }

    @Then("^open scheme year application for 5 minutes$")
    public void openSchemeYearForFiveMinutes() {
        setTSAS_APPLICATIONSTYPE_ByClosingDateAndAppCodeForFiveMinutes();
    }

    @Then("^close scheme year application$")
    public void closeSchemeYear() {
        setTSAS_APPLICATIONSTYPE_ByClosingDateAndAppCodeNow();
    }
}
