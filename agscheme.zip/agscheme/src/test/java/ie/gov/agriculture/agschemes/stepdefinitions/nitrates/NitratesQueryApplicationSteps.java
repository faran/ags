package ie.gov.agriculture.agschemes.stepdefinitions.nitrates;

import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.DriverFactory;
import ie.gov.agriculture.agschemes.stepdefinitions.startupandcleanup.SharedBrowserSteps;
import io.cucumber.java.en.And;

public class NitratesQueryApplicationSteps extends DriverFactory {


    public NitratesQueryApplicationSteps(SharedBrowserSteps sharedBrowsersSteps) {
        super(sharedBrowsersSteps);
    }

    @And("^query application delete document (Fertiliser Accounts|Other)$")
    public void queryApplicationDD(String doctype) {
        nitratesLandingPage.clickMoreActionsButton();
        nitratesQueryApplication.clickQueryApplication();
        nitratesQueryApplication.selectQueryReasonDocumentDelete();
        nitratesQueryApplication.selectDocumentType(doctype);
        if(doctype.equals("Fertiliser Accounts")){
            nitratesQueryApplication.selectSchemeYear();
        }
        nitratesQueryApplication.clickConfirm();
    }

    @And("^query application edit document (Fertiliser Accounts|Other|Soil Sample)$")
    public void queryApplicationED(String doctype) {
        nitratesLandingPage.clickMoreActionsButton();
        nitratesQueryApplication.clickQueryApplication();
        nitratesQueryApplication.selectQueryReasonEditDocument();
        nitratesQueryApplication.selectDocumentType(doctype);
        if(doctype.equals("Fertiliser Accounts")  || doctype.equals("Soil Sample")){
            nitratesQueryApplication.selectSchemeYear();
        }
        nitratesQueryApplication.clickConfirm();
    }

    @And("^query application fertilizer account$")
    public void queryApplicationFA() {
        nitratesLandingPage.clickMoreActionsButton();
        nitratesQueryApplication.clickQueryApplication();
        nitratesQueryApplication.selectQueryReasonFertlizerAccount();
        nitratesQueryApplication.clickConfirm();
    }

    @And("^query application soil sample$")
    public void queryApplicationSS() {
        nitratesLandingPage.clickMoreActionsButton();
        nitratesQueryApplication.clickQueryApplication();
        nitratesQueryApplication.selectQueryReasonSoilSample();
        nitratesQueryApplication.clickConfirm();
    }
}
